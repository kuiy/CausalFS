
#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
#include <string>
#include <list>

#include "common.hpp"
#include "data.hpp"


#ifndef TETRAD_HPP
#define TETRAD_HPP


struct TetradOutput {
	struct Edge {
		int head;
		int tail;
		bool directed;
	};
	
	std::string dataType;
	int variables;
	int cases;
	std::list<Edge> edges;
};

void writeTetradInput(const DataColumns& data, std::string filename) {
	std::ofstream file(filename.c_str());
	for (int i = 0; i < data.getNumVariables(); ++i) {
		if (i != 0)
			file << "\t";
		file << i;
	}
	file << "\n";
	for (int j = 0; j < data.getNumSamples(); ++j) {
		for (int i = 0; i < data.getNumVariables(); ++i) {
			if (i != 0)
				file << "\t";
			file << (int)(data(i, j));
		}
		file << "\n";
	}
	file.close();
}

TetradOutput readTetradOutput(std::string filename) {
	TetradOutput output;
	std::ifstream file(filename.c_str());
	std::string tmp;
	// skip first line
	getline(file, tmp);
	// read data type
	file >> tmp; assert(tmp == "Data");
	file >> tmp; assert(tmp == "type");
	file >> tmp; assert(tmp == "=");
	file >> output.dataType;
	// read variable count
	file >> tmp; assert(tmp == "#");
	file >> tmp; assert(tmp == "variables");
	file >> tmp; assert(tmp == "=");
	file >> output.variables;
	// read the number of cases
	file >> tmp; assert(tmp == ",");
	file >> tmp; assert(tmp == "#");
	file >> tmp; assert(tmp == "cases");
	file >> tmp; assert(tmp == "=");
	file >> output.cases;

	getline(file, tmp);
	getline(file, tmp);
	getline(file, tmp);	assert(tmp == "Result graph:");

	getline(file, tmp);
	getline(file, tmp); assert(tmp == "Graph Nodes:");
//	for (int i = 0; i < output.nvariables; ++i)
	getline(file, tmp);

	getline(file, tmp);
	getline(file, tmp); assert(tmp == "Graph Edges: ");
	while (true) {
		while (file.peek() == '\n')
			file.get();
		if (file.eof())
			break;
		file >> tmp;
		TetradOutput::Edge edge;
		file >> edge.head;
		file >> tmp;
		if (tmp == "---")
			edge.directed = false;
		else if (tmp == "-->")
			edge.directed = true;
		else
			assert(0);
		file >> edge.tail;
		output.edges.push_back(edge);
	}
	
	file.close();
	return output;
}


std::string tempFilename(std::string prefix) {
	char filename[prefix.length() + 8];
	strcpy(filename, (prefix + ".XXXXXX").c_str());
	int tmp = mkstemp(filename);
	assert(tmp != -1);
	close(tmp);
	return std::string(filename);
}


void tetradGES(const DataColumns& data, double samplePrior, SquareMat<bool>& pdag,
		const std::string& tetradcmdLocation) {
	std::string inFilename(tempFilename("tetradInput.tmp"));
	std::string outFilename(tempFilename("tetradOutput.tmp"));
	
	writeTetradInput(data, inFilename);
	
	//std::string tetradcmdLocation = "/fs/home/tzniinim/tetradcmd-4.3.10-6.jar";
	std::stringstream cmd;
	cmd << "java -jar " << tetradcmdLocation
			<< " -data \"" << inFilename << "\""
			<< " -datatype \"discrete\""
			<< " -algorithm \"ges\""
			<< " -sampleprior " << samplePrior
			<< " -outfile \"" << outFilename << "\""
			<< " 2>/dev/null > /dev/null";
	
	int status = system(cmd.str().c_str());
	if (status != 0) {
		remove(inFilename.c_str());
		remove(outFilename.c_str());
		assert(0);
	}
	
	TetradOutput output = readTetradOutput(outFilename);
	
	remove(inFilename.c_str());
	remove(outFilename.c_str());
	
	assert(pdag.getNumNodes() == output.variables);
	pdag.setAll(false);
	for (std::list<TetradOutput::Edge>::iterator it = output.edges.begin(); it != output.edges.end(); ++it) {
		pdag(it->head, it->tail) = true;
		if (!(it->directed))
			pdag(it->tail, it->head) = true;
	}
}


/*
int main() {
	Data data;
	std::ifstream dataFile("/fs/home/tzniinim/tyo/bns/beand-local/tests/rnet_data_n20_m5_s2_1000.dat");
	data.read(dataFile);
	dataFile.close();
	int nVariables = data.getNumVariables();
	DataColumns dataCols(data);
	SquareMat<bool> pdag(nVariables);
	tetradGES(dataCols, 1.0, pdag);
	for (int i = 0; i < nVariables; ++i) {
		for (int j = 0; j < nVariables; ++j) {
			if (j != 0)
				printf(" ");
			printf("%d", pdag(i,j) ? 1 : 0);
		}
		printf("\n");
	}
//	TetradOutput output = readTetradOutput(std::string("/cs/fs/home/tzniinim/tetradcmd-testoutput.txt"));
//	for (std::list<TetradOutput::Edge>::iterator it = output.edges.begin(); it != output.edges.end(); ++it) {
//		std::cout << it->head << (it->directed ? " -> " : " -- ") << it->tail << "\n";
//	}
	return 0;
}/**/

#endif



