
#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>
#include <vector>
#include <list>
#include <queue>
#include <deque>
//#include <stack>
#include <limits>

#include "common.hpp"
#include "lognum.hpp"
#include "timer.hpp"
#include "data.hpp"
#include "stacksubset.hpp"
#include "scores.hpp"
#include "adtree.hpp"
#include "local.hpp"
#include "logger.hpp"


#ifndef GREEDY_HPP
#define GREEDY_HPP

using std::list;
using std::vector;
using std::queue;
using std::deque;

const double INF = std::numeric_limits<double>::infinity();

bool hasPath(const SquareMat<bool>& adjMat, int i, int j) {
	int n = adjMat.getNumNodes();
	vector<bool> visited(n, false);
	StackSubset s(n);
	s.push(i);
	while (!s.empty()) {	
		i = s.pop();
		for (int k = 0; k < n; ++k)
			if (adjMat(i,k) && !visited[k])
				if (k == j)
					return true;
				else {
					visited[k] = true;
					s.push(k);
				}
	}
	return false;
}

void computePathMatrix(const SquareMat<bool>& adjMat, SquareMat<bool>& pathMat) {
	int n = adjMat.getNumNodes();
	pathMat.setAll(false);
	for (int k = 0; k < n; ++k)
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				pathMat(i,j) |= adjMat(i,j) | (pathMat(i,k) & pathMat(k,j));
}

enum StepType {
	NONE = 0,
	ADD,
	DEL,
	REV
};

struct Step {
	StepType type;
	int i;
	int j;
	double scoreDiff;
};

void applyStep(Step step, SquareMat<bool>& adjMat) {
	assert(step.type != NONE);
	switch (step.type) {
		case ADD:
			adjMat(step.i,step.j) = true;
			break;
		case DEL:
			adjMat(step.i,step.j) = false;
			break;
		case REV:
			adjMat(step.i,step.j) = true;
			adjMat(step.j,step.i) = false;
			break;
	}
}

void revertStep(Step step, SquareMat<bool>& adjMat) {
	assert(step.type != NONE);
	switch (step.type) {
		case ADD:
			adjMat(step.i,step.j) = false;
			break;
		case DEL:
			adjMat(step.i,step.j) = true;
			break;
		case REV:
			adjMat(step.i,step.j) = false;
			adjMat(step.j,step.i) = true;
			break;
	}
}

bool duplicateFound(int n, const deque<Step>& lastSteps) {
	SquareMat<bool> diffMat(n);
	diffMat.setAll(false);
	int diff = 0;
	for (int k = lastSteps.size() - 1; k >= 0; --k) {
		int i = lastSteps[k].i;
		int j = lastSteps[k].j;
		switch (lastSteps[k].type) {
			case ADD:
			case DEL:
				diffMat(i,j) = !diffMat(i,j);
				diff += (diffMat(i,j) ? +1 : -1);
				break;
			case REV:
				diffMat(i,j) = !diffMat(i,j);
				diffMat(j,i) = !diffMat(j,i);
				diff += (diffMat(i,j) ? +1 : -1);
				diff += (diffMat(j,i) ? +1 : -1);
				break;
		}
		if (diff == 0)
			return true;
	}
	return false;
}

void updateNeighScores(const DataView& dataView, const ScoreFun* scoreFun, const SquareMat<bool>& adjMat, int j, SquareMat<double>& neighScores) {
	int n = adjMat.getNumNodes();
	StackSubset pa(n);
	for (int i = 0; i < n; ++i) {
		if (i == j)
			continue;
		pa.clear();
		for (int k = 0; k < n; ++k)
			if (adjMat(k,j) ^ (k==i))
				pa.push(k);
		neighScores(i,j) = computeScore(&dataView, pa, j, scoreFun);
	}
}

Step findBestStep(SquareMat<bool>& adjMat, const SquareMat<bool>& pathMat, const SquareMat<bool>& allowedMat, const vector<double>& scores, const SquareMat<double>& neighScores, deque<Step>& lastSteps) {

    int n = adjMat.getNumNodes();
	Step bestStep;
	bestStep.type = NONE;
	bestStep.scoreDiff = -INF;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			if (i == j)
				continue;
			Step step;
			step.i = i;
			step.j = j;
			step.type = NONE;
			step.scoreDiff = -INF;
			if (adjMat(i,j)) {
				step.type = DEL;
				step.scoreDiff = neighScores(i,j) - scores[j];
			} else {
				if (!adjMat(j,i)) {
					if (!pathMat(j,i) && allowedMat(i,j)) {
						step.type = ADD;
						step.scoreDiff = neighScores(i,j) - scores[j];
					}
				} else {
					adjMat(j,i) = false;
					if (!hasPath(adjMat, j, i)) {
						step.type = REV;
						step.scoreDiff = neighScores(i,j) - scores[j] + neighScores(j,i) - scores[i];
					}
					adjMat(j,i) = true;
				}
			}
			if (step.type == NONE)
				continue;
			applyStep(step, adjMat);
			lastSteps.push_back(step);
			bool dupFound = duplicateFound(n, lastSteps);
			lastSteps.pop_back();
			revertStep(step, adjMat);
//			logger.printf(1, "  * %s  %d -> %d  (%+g)  %s\n",
//					step.type == ADD ? "ADD" : step.type == DEL ? "DEL" : step.type == REV ? "REV" : "UNKNOWN",
//					step.i, step.j, step.scoreDiff, dupFound ? "dup!" : "");
			if (!dupFound && bestStep.scoreDiff < step.scoreDiff)
				bestStep = step;
		}
	}
	return bestStep;
}


void greedyBestDAG(const DataView& dataView, const SquareMat<bool>& allowedMat, const ScoreFun* scoreFun, int maxHistoryLength, int maxBadSteps, SquareMat<bool>& adjMat) {
	int n = dataView.getNumVariables();

	SquareMat<bool> pathMat(n);
	SquareMat<double> neighScores(n);
	vector<double> scores(n);
	
	double currScore = 0;
	StackSubset pa(n);
	for (int i = 0; i < n; ++i) {
		scores[i] = computeScore(&dataView, pa, i, scoreFun);
		currScore += scores[i];
		pa.push(i);
		for (int j = 0; j < n; ++j) {
			if (i != j)
				neighScores(i,j) = computeScore(&dataView, pa, j, scoreFun);
			else
				neighScores(i,j) = -INF;
		}
		pa.pop();
	}

	// tabu list
	deque<Step> lastSteps;
	
	double bestScore = -INF;
	int nBadSteps = 0;

	int t = 0;
	while (true) {
		computePathMatrix(adjMat, pathMat);

		Step bestStep = findBestStep(adjMat, pathMat, allowedMat, scores, neighScores, lastSteps);

		double newScore = currScore + bestStep.scoreDiff;
		if ( newScore <= bestScore && nBadSteps >= maxBadSteps) {
			while (nBadSteps--) {
				Step step = lastSteps.back();
				lastSteps.pop_back();
				revertStep(step, adjMat);
				currScore -= step.scoreDiff;
			}
			return;
		} else {
			applyStep(bestStep, adjMat);
			scores[bestStep.j] = neighScores(bestStep.i, bestStep.j);
			updateNeighScores(dataView, scoreFun, adjMat, bestStep.j, neighScores);
			if (bestStep.type == REV) {
				scores[bestStep.i] = neighScores(bestStep.j, bestStep.i);
				updateNeighScores(dataView, scoreFun, adjMat, bestStep.i, neighScores);
			}
			if (lastSteps.size() >= maxHistoryLength)
				lastSteps.pop_front();
			lastSteps.push_back(bestStep);
			currScore = newScore;
			if (currScore > bestScore) {
				bestScore = currScore;
				nBadSteps = 0;
			} else
				++nBadSteps;
		}
		++t;
	}
}


#endif



