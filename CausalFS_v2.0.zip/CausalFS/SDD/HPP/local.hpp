
//#include <cstdio>
#include <vector>
#include <list>
#include <string>

#include "common.hpp"
#include "lognum.hpp"
#include "timer.hpp"
#include "data.hpp"
#include "scores.hpp"
#include "adtree.hpp"
#include "bestdagdp.hpp"
#include "tetrad.hpp"

#ifndef LOCAL_HPP
#define LOCAL_HPP

using std::list;
using std::vector;


struct SubnetFinder {
	int adTreeMinCount;
	int adTreeMaxDepth;
	double equivalentSampleSize;
	int maxNodesDP;
	int maxParents;
	const ScoreFun* scoreFun;
	std::string tetradcmdLocation;

	int maxNumADNodes;
	
	void reset() {
		maxNumADNodes = 0;
	}

	void findBestSubnet(const Data& data, const list<int>& nodes, SquareMat<bool>& pdag) {
		DataColumns dataColumns(data, vector<int>(nodes.begin(), nodes.end()));
		if (nodes.size() <= maxNodesDP) {
			if (adTreeMaxDepth == 0) {
				findBestDAG(dataColumns, maxParents, scoreFun, pdag);
			} else {
		//		printf("  build ADTree\n");
				ADTree adTree(dataColumns, adTreeMinCount, adTreeMaxDepth, maxParents + 1);
				maxNumADNodes = max(maxNumADNodes, adTree.getNumADNodes());
				findBestDAG(adTree, maxParents, scoreFun, pdag);
			}
		} else {
			tetradGES(dataColumns, equivalentSampleSize, pdag, tetradcmdLocation);
		}
	}
};



int maxNeighSize = 0;
void findPotentialNeighbors(const Data& data, int node, SubnetFinder& subnetFinder, list<int>& neighs, list<int>& nonNeighs) {
	list<int> pending;
	for (int i = 0; i < data.nVariables; ++i)
		if (i != node)
			pending.push_back(i);
	neighs.clear();
	nonNeighs.clear();
	neighs.push_back(node);
	while (!pending.empty()) {
		int v = pending.front();
		pending.pop_front();
		neighs.push_back(v);
		int n = neighs.size();
		if (n > maxNeighSize)
			maxNeighSize = n;
		SquareMat<bool> pdag(n);
		subnetFinder.findBestSubnet(data, neighs, pdag);
		list<int>::iterator it = neighs.begin();
		++it;
		for (int i = 1; i < n; ++i) {
			if (!pdag(0, i) && !pdag(i, 0)) {
				nonNeighs.push_back(*it);
				it = neighs.erase(it);
			} else
				++it;
		}
	}
	neighs.erase(neighs.begin());
}
void findPotentialNeighbors2(const Data& data, int node, SubnetFinder& subnetFinder, list<int>& neighs, list<int>& nonNeighs, int & ScorePCTest) {
//    int ScorePCTest=0;

    list<int> pending;
    for (int i = 0; i < data.nVariables; ++i)
        if (i != node)
            pending.push_back(i);
    neighs.clear();
    nonNeighs.clear();
    neighs.push_back(node);
    while (!pending.empty()) {
        int v = pending.front();
        pending.pop_front();
        neighs.push_back(v);
        int n = neighs.size();
        if (n > maxNeighSize)
            maxNeighSize = n;
        SquareMat<bool> pdag(n);

        ScorePCTest=ScorePCTest+1;
        subnetFinder.findBestSubnet(data, neighs, pdag);            //get best DAG

        //---------------------------------------------------get PC  (remove false positives from entire set)
        list<int>::iterator it = neighs.begin();
        ++it;
        for (int i = 1; i < n; ++i) {
            if (!pdag(0, i) && !pdag(i, 0)) {
                nonNeighs.push_back(*it);
                it = neighs.erase(it);                      //remove false
            } else
                ++it;
        }
        //---------------------------------------------------get PC  end
    }
    neighs.erase(neighs.begin());                   //remove target

//    std::cout<<"ScorePCTest<<"<<ScorePCTest<<std::endl;
}

/*void findNeighbors(const Data& data, int node, SubnetFinder& subnetFinder, list<int>& neighs) {
	findPotentialNeighbors(data, node, subnetFinder, neighs);
	for (list<int>::iterator it = neighs.begin(); it != neighs.end(); ) {
		list<int> neighs2;
		findPotentialNeighbors(data, *it, subnetFinder, neighs2);
		bool hasNodeAsNeigh = false;
		for (list<int>::iterator it2 = neighs2.begin(); it2 != neighs2.end(); ++it2)
			if (*it2 == node)
				hasNodeAsNeigh = true;
		if (hasNodeAsNeigh)
			++it;
		else
			it = neighs.erase(it);
	}
}/**/


struct Family {
	int spouse;
	list<int> children;
	Family(int s, const list<int>& ch) { spouse = s; children = ch; }
};

int maxMBSize = 0;
int maxCanNeighSize = 0;
void findPotentialFamilies(const Data& data, int node, SubnetFinder& subnetFinder, const list<int>& neighs, list<int> pending, list<Family>& families) {
	int nNeighs = neighs.size();
	list<int> spouses;
	families.clear();
	while (!pending.empty()) {
		int v = pending.back();
		pending.pop_back();
		spouses.push_back(v);
//fprintf(stderr, "add %d\n", v);
		int nSpouses = spouses.size();
		list<int> subnet;
		subnet.insert(subnet.end(), node);
		subnet.insert(subnet.end(), neighs.begin(), neighs.end());
		subnet.insert(subnet.end(), spouses.begin(), spouses.end());
		int n = subnet.size();
		if (n > maxMBSize)
			maxMBSize = n;
		SquareMat<bool> pdag(n);
		subnetFinder.findBestSubnet(data, subnet, pdag);
		list<int>::iterator sit = spouses.begin();
		//list<list<int> >::iterator cit = children.begin();
		//children.clear();
		families.clear();
		for (int i = 0; i < nSpouses; ++i) {
			list<int> commonChildren;
			list<int>::const_iterator nit = neighs.begin();
			for (int j = 0; j < nNeighs; ++j) {
				//if (dag(0, 1+j) && dag(1+nNeighs+i, 1+j)) {
//				if (pdag(0, 1+j) && !pdag(1+j, 0) && pdag(1+nNeighs+i, 1+j) && !pdag(1+j, 1+nNeighs+i)) {
				if (pdag(0, 1+j) && !pdag(1+j, 0) && pdag(1+nNeighs+i, 1+j) && !pdag(1+j, 1+nNeighs+i) &&
						!pdag(0, 1+nNeighs+i) && !pdag(1+nNeighs+i, 0) ) {
					commonChildren.push_back(*nit);
				}
				++nit;
			}
			if (commonChildren.empty()) {
//fprintf(stderr, "remove %d\n", *sit);
				sit = spouses.erase(sit);
			} else {
				families.push_back(Family(*sit, commonChildren));
				//children.push_back(commonChildren);
				++sit;
			}
		}
	}
}/**/
void findPotentialFamilies2(const Data& data, int node, SubnetFinder& subnetFinder, list<int>& neighs, list<int> pending, list<Family>& families, int & ScoreSPTest)
{
//    int ScoreSPTest=0;

    int nNeighs = neighs.size();
    list<int> spouses;
    families.clear();
    while (!pending.empty()) {
        int v = pending.back();
        pending.pop_back();
        spouses.push_back(v);
//fprintf(stderr, "add %d\n", v);
        int nSpouses = spouses.size();
        list<int> subnet;
        subnet.insert(subnet.end(), node);
        subnet.insert(subnet.end(), neighs.begin(), neighs.end());
        subnet.insert(subnet.end(), spouses.begin(), spouses.end());
        int n = subnet.size();
        if (n > maxMBSize)
            maxMBSize = n;
        SquareMat<bool> pdag(n);

        ScoreSPTest=ScoreSPTest+1;
        subnetFinder.findBestSubnet(data, subnet, pdag);

        //---------------------------------------   add LING 0618 for remove false PC

        int nneigh = neighs.size();
        if (nneigh > maxCanNeighSize)
            maxCanNeighSize = nneigh;
        list<int>::iterator it = neighs.begin();
//        ++it;
        for (int w = 0; w < nneigh; ++w) {
            if (!pdag(0, 1+w) && !pdag(1+w, 0)) {
//				nonNeighs.push_back(*it);
                it = neighs.erase(it);
            } else
                ++it;
        }

        //---------------------------------------

        list<int>::iterator sit = spouses.begin();

//        std::cout<<"F_CanSP"<<*sit<<std::endl;
        //list<list<int> >::iterator cit = children.begin();
        //children.clear();
        families.clear();
        for (int i = 0; i < nSpouses; ++i) {
            list<int> commonChildren;
            list<int>::iterator nit = neighs.begin();
            for (int j = 0; j < nNeighs; ++j) {
                //if (dag(0, 1+j) && dag(1+nNeighs+i, 1+j)) {
//				if (pdag(0, 1+j) && !pdag(1+j, 0) && pdag(1+nNeighs+i, 1+j) && !pdag(1+j, 1+nNeighs+i)) {
                if (pdag(0, 1+j) && !pdag(1+j, 0) && pdag(1+nNeighs+i, 1+j) && !pdag(1+j, 1+nNeighs+i) &&
                        !pdag(0, 1+nNeighs+i) && !pdag(1+nNeighs+i, 0) ) {
                    commonChildren.push_back(*nit);
                }
                ++nit;
            }
            if (commonChildren.empty()) {
//fprintf(stderr, "remove %d\n", *sit);
                sit = spouses.erase(sit);
            } else {
                families.push_back(Family(*sit, commonChildren));
                //children.push_back(commonChildren);
                ++sit;
            }
        }
    }

//    std::cout<<"ScoreSPTest<<"<<ScoreSPTest<<std::endl;

}/**/
#endif

