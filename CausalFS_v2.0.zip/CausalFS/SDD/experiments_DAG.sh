#!/bin/bash
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt SLL-CSL ""
mv ./indicator2/indicator.out ./indicator2/child_SLL-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt SLL-CSL ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt SLL-CSL ""
mv ./indicator2/indicator.out ./indicator2/child_SLL-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt S2TMB-CSL ""
mv ./indicator2/indicator.out ./indicator2/child_S2TMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt S2TMB-CSL ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt S2TMB-CSL ""
mv ./indicator2/indicator.out ./indicator2/child_S2TMB-CSL_5000.out
sleep 3s


./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt SLL-SSL ""
mv ./indicator2/indicator.out ./indicator2/child_SLL-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt SLL-SSL ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt SLL-SSL ""
mv ./indicator2/indicator.out ./indicator2/child_SLL-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt S2TMB-SSL ""
mv ./indicator2/indicator.out ./indicator2/child_S2TMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt S2TMB-SSL ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt S2TMB-SSL ""
mv ./indicator2/indicator.out ./indicator2/child_S2TMB-SSL_5000.out
sleep 3s










./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_SLL-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt SLL-CSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_SLL-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_S2TMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB-CSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_S2TMB-CSL_5000.out
sleep 3s



./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_SLL-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt SLL-SSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_SLL-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_S2TMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB-SSL ""
mv ./indicator2/indicator.out ./indicator2/alarm_S2TMB-SSL_5000.out
sleep 3s









./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt SLL-CSL ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt SLL-CSL ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt SLL-CSL ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt SLL-CSL ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt SLL-CSL ""
mv ./indicator2/indicator.out ./indicator2/gene_SLL-CSL_500.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt S2TMB-CSL ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt S2TMB-CSL ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt S2TMB-CSL ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt S2TMB-CSL ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt S2TMB-CSL ""
mv ./indicator2/indicator.out ./indicator2/gene_S2TMB-CSL_500.out
sleep 3s



./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt SLL-SSL ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt SLL-SSL ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt SLL-SSL ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt SLL-SSL ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt SLL-SSL ""
mv ./indicator2/indicator.out ./indicator2/gene_SLL-SSL_500.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt S2TMB-SSL ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt S2TMB-SSL ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt S2TMB-SSL ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt S2TMB-SSL ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt S2TMB-SSL ""
mv ./indicator2/indicator.out ./indicator2/gene_S2TMB-SSL_500.out
sleep 3s
