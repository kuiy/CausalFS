#!/bin/bash
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_MMMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_MMMB-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_MMMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_MMMB-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_PCMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_PCMB-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_PCMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_PCMB-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_HITON_MB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_HITON_MB-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_HITON_MB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_HITON_MB-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_Semi_HITON_MB-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_Semi_HITON_MB-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.01_MBOR-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.01_MBOR-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.05_MBOR-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.05_MBOR-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_IPC_MB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_IPC_MB-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_IPC_MB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_IPC_MB-CSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_STMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_STMB-CSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_STMB-CSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_STMB-CSL_5000.out
sleep 3s





./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_MMMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_MMMB-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_MMMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_MMMB-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_PCMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_PCMB-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_PCMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_PCMB-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_HITON_MB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_HITON_MB-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_HITON_MB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_HITON_MB-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_Semi_HITON_MB-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_Semi_HITON_MB-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.01_MBOR-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.01_MBOR-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.05_MBOR-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/child_0.05_MBOR-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_IPC_MB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_IPC_MB-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_IPC_MB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_IPC_MB-SSL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_STMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.01_STMB-SSL_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_STMB-SSL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/child_0.05_STMB-SSL_5000.out
sleep 3s


















./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MMMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MMMB-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MMMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MMMB-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_PCMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_PCMB-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_PCMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_PCMB-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_HITON_MB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_HITON_MB-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_HITON_MB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_HITON_MB-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_Semi_HITON_MB-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_Semi_HITON_MB-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MBOR-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MBOR-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MBOR-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MBOR-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_IPC_MB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_IPC_MB-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_IPC_MB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_IPC_MB-CSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_STMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_STMB-CSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_STMB-CSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_STMB-CSL_5000.out
sleep 3s





./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MMMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MMMB-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MMMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MMMB-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_PCMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_PCMB-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_PCMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_PCMB-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_HITON_MB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_HITON_MB-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_HITON_MB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_HITON_MB-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_Semi_HITON_MB-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_Semi_HITON_MB-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MBOR-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_MBOR-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MBOR-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_MBOR-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_IPC_MB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_IPC_MB-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_IPC_MB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_IPC_MB-SSL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_STMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.01_STMB-SSL_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_STMB-SSL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/alarm_0.05_STMB-SSL_5000.out
sleep 3s


















./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MMMB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MMMB-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MMMB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MMMB-CSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_PCMB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_PCMB-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_PCMB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_PCMB-CSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_HITON_MB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_HITON_MB-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_HITON_MB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_HITON_MB-CSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_Semi_HITON_MB-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_Semi_HITON_MB-CSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MBOR-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MBOR-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MBOR-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MBOR-CSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_IPC_MB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_IPC_MB-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_IPC_MB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_IPC_MB-CSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_STMB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_STMB-CSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_STMB-CSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_STMB-CSL_5000.out
sleep 3s





./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MMMB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MMMB-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MMMB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MMMB-SSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_PCMB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_PCMB-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_PCMB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_PCMB-SSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_HITON_MB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_HITON_MB-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_HITON_MB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_HITON_MB-SSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_Semi_HITON_MB-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_Semi_HITON_MB-SSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MBOR-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_MBOR-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MBOR-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_MBOR-SSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_IPC_MB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_IPC_MB-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_IPC_MB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_IPC_MB-SSL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_STMB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.01_STMB-SSL_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_STMB-SSL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/pigs_0.05_STMB-SSL_5000.out
sleep 3s



















./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MMMB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MMMB-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MMMB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MMMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MMMB-CSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_PCMB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_PCMB-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_PCMB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 PCMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_PCMB-CSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_HITON_MB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_HITON_MB-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_HITON_MB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_HITON_MB-CSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_Semi_HITON_MB-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_Semi_HITON_MB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_Semi_HITON_MB-CSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MBOR-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MBOR-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MBOR-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MBOR-CSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MBOR-CSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_IPC_MB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_IPC_MB-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_IPC_MB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_IPC_MB-CSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_STMB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_STMB-CSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_STMB-CSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 STMB-CSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_STMB-CSL_5000.out
sleep 3s





./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MMMB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MMMB-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MMMB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MMMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MMMB-SSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_PCMB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_PCMB-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_PCMB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 PCMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_PCMB-SSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_HITON_MB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_HITON_MB-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_HITON_MB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_HITON_MB-SSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_Semi_HITON_MB-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_Semi_HITON_MB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_Semi_HITON_MB-SSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MBOR-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.01_MBOR-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MBOR-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MBOR-SSL "" "" ""
mv ./indicator2/indicator.out ./indicator2/gene_0.05_MBOR-SSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_IPC_MB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_IPC_MB-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_IPC_MB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_IPC_MB-SSL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_STMB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.01_STMB-SSL_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_STMB-SSL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 STMB-SSL "" "" 3
mv ./indicator2/indicator.out ./indicator2/gene_0.05_STMB-SSL_5000.out
sleep 3s
