#ifndef CHISQ_H
#define CHISQ_H

double gammq(double a, double x);

#endif // CHISQ_H
