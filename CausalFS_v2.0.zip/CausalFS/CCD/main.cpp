//Xianjie Guo, Kui Yu
//10/10/2019
///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////includes///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <math.h>
#include <time.h>
#include <assert.h>

#include <iostream>
#include <fstream>
#include <string>

#include <vector>
#include <list>
#include <queue>
#include <algorithm>

#include "linalg.h"
#include "normdist.h"
#include "local.hpp"
#include "common.hpp"
#include "data.hpp"
#include "adtree.hpp"
#include "scores.hpp"
#include "stacksubset.hpp"
#include "greedy.hpp"

using std::list;
using std::queue;
using std::vector;

///////////////////////////////////////////////////////////////////////////////
//////////////////////////////////defines//////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#define MAX_LINE_LENGTH 1000000
#define MAX_STATE_LENGTH 100

///////////////////////////////////////////////////////////////////////////////
////////////////////////////////global definitions/////////////////////////////
///////////////////////////////////////////////////////////////////////////////

int n_cases, n_vars; //number of network nodes and sample cases

int max_max_cond_size, k_conditon; //K_conditon is the maximum test set for conditional independence tests

double k_tradeoff, alpha, average_perform_time, average_n_Fisher_z; //average_n_Fisher_z is the average number of conditional independence tests each node takes

double average_Precision, average_Recall, average_F1, average_Distance; //average value of four indicators of all nodes in the network (under one sample)

double SHD, undirected, reverse, miss, extra; //five indicators of structural learning in network (under one sample)

clock_t clock_init;

const char *data_file_path, *net_file_path, *mb_write_in_file_path, *pc_write_in_file_path, *DAG_write_in_file_path;

int **net;

double **sigma, **data_Continuous;

vector<vector<int> > pc_cache; //During structure learning, the PC results are cached
int ***sep_cache;             //During structure learning, the cut set of nodes independent of the target node is recorded
bool *pc_iscomputed;          //When learning the structure, record which nodes of the PC have been calculated.
bool isLearnDAG;              //Whether to carry out structural learning algorithm

struct Arc
{
    int head;
    int tail;
    Arc(int h, int t)
    {
        head = h;
        tail = t;
    }
};

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////functions' prototypes///////////////////////////
///////////////////////////////////////////////////////////////////////////////

//Divide-and-conquer MB learning approaches
void MMMB(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void Semi_Hiton_MB(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void Hiton_MB(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void PCMB(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void MBOR(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void IPC_MB(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void STMB(int target, vector<list<Family> > &families, vector<list<int> > &neighs);
void CCMB(int target);
void CCMB_all();

//Simultaneous MB learning approaches
void GSMB(int target);
void IAMB(int target);
void Inter_IAMB(int target);
void LRH(int target);
void BAMB(int target);
void EEMB(int target);
void FBED(int target);

//Learning MBs without assuming faithfulness or causal sufficiency
void KIAMB(int target);
void TIE_MB(int target);

//PC learning algorithms
void PC_simple(int target, vector<list<int> > &neighs);
void MMPC(int target, vector<list<int> > &neighs);
void Hiton_PC(int target, vector<list<int> > &neighs);
void Semi_Hiton_PC(int target, vector<list<int> > &neighs);
void Get_PC(int target, vector<list<int> > &neighs);
void MBTOPC(int target, vector<list<int> > &neighs);

///////////////////////////////////////////////////////////////////////////////

void parse_data(void);
void covariance(double **sigma);
void hiton_pc_set(int target, int *pc, int **sep);
void semi_hiton_pc_set(int target, int *pc, int **sep);
void pc_set(int target, int *pc, int **sep);
void pc_superset(int target, int *pc, int **sep);
void pc_superset2(int target, int *pc, int **sep);
void PCSuperSet(int target, int *pcs, int **sep);
void MBSuperSet(int target, int *mbs, int *pcs, int **sep);
void MBtoPC(int target, int *D, int *pc, int *mb, int **sep);
void TIE_MB_induc_alg_X(int target, vector<int> &_mb, const vector<int> &illegal_var);
bool criterion_Z(int target, const vector<int> &mb_old, const vector<int> &mb_new);
int isSubset(vector<int> v1, vector<int> v2);
void set_plus(vector<int> v1, list<vector<int> > &v2, vector<int> v3);
void recognize_pc(int target, int *CanADJ, int *pc, int **sep);
double min_dep(int var, int target, int compulsory, int *pc, int *sep);
int next_cond_index(int n_pc, int cond_size, int *cond_index);
double compute_dep(int var, int target, int *cond);
double statistic(int var, int target, int *cond);
double inverse(double **a, int n, int x, int y);
bool choldc(double **a, int n, double p[]);
int k_greedy(double *dep);
void report_mb(int target, int *mb);
void report_pc(int target, int *pc);
void report_DAG(SquareMat<bool> &adjMat);
void buildSkeletonDAG(const vector<list<int> > &neighs, SquareMat<bool> &adjMat);
void directArc(int i, int j, SquareMat<bool> &adjMat, SquareMat<bool> &pathMat, queue<Arc> &directed);
void Constrain_DAG(const vector<list<int> > &neighs, const vector<list<Family> > &families, SquareMat<bool> &adjMat);
void Score_DAG(const vector<list<int> > &neighs, const Data &data, SquareMat<bool> &adjMat, const ScoreFun *scoreFun);

///////////////////////////////////////////////////////////////////////////////
////////////////////////////////functions' body////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////

int main(int argc, char *argv[])
{
    int i, j;
    char *algorithm;
    vector<int> targets;
    std::fstream _file;

    if (argc != 8)
    {
        std::cout << "Please enter eight parameters！" << std::endl;
        exit(0);
    }

    data_file_path = argv[1];
    net_file_path = argv[2];
    alpha = atof(argv[3]);
    algorithm = argv[4];

    Data data;
    std::istream inStream(0);
    std::ifstream inFile;
    inFile.open(data_file_path);
    inStream.rdbuf(inFile.rdbuf());
    data.read(inStream);
    if (inFile.is_open())
        inFile.close();

    n_vars = data.nVariables;
    n_cases = data.nSamples;

    std::cout << "algorithm:" << algorithm << "  "
              << "alpha:" << alpha << "  "
              << "n_cases:" << n_cases << "  "
              << "n_vars:" << n_vars << std::endl;
    vector<list<Family> > families(n_vars);
    vector<list<int> > neighs(n_vars);
    SquareMat<bool> adjMat(n_vars);
    pc_cache.resize(n_vars);
    pc_iscomputed = new bool[n_vars];
    for (i = 0; i < n_vars; ++i)
    {
        pc_iscomputed[i] = false;
        pc_cache[i].clear();
    }

    ScoreFun *scoreFun = new BDeuScore((double)1.0);

    if (!strcmp(argv[5], "all") || !strcmp(argv[5], ""))
    {
        for (int var = 0; var < n_vars; ++var)
        {
            targets.push_back(var);
        }
    }
    else
    {
        const char *sep = ",";
        char *p;
        p = strtok(argv[5], sep);
        while (p)
        {
            targets.push_back(atoi(p));
            p = strtok(NULL, sep);
        }
    }

    k_conditon = atoi(argv[7]);

    srand((unsigned)time(NULL));

    //data_file_path = "data/alarm_data/Alarm1_s5000_v1.txt";
    //net_file_path = "data/alarm_data/Alarm1_graph.txt";
    mb_write_in_file_path = "mb/mb.out";
    pc_write_in_file_path = "pc/pc.out";
    DAG_write_in_file_path = "DAG/DAG.out";

    average_Precision = (double)0.0;
    average_Recall = (double)0.0;
    average_F1 = (double)0.0;
    average_Distance = (double)0.0;
    average_perform_time = (double)0.0;
    average_n_Fisher_z = (double)0.0;

    k_tradeoff = 1.0;

    data_Continuous = new double *[n_cases];
    for (i = 0; i < n_cases; i++)
        data_Continuous[i] = new double[n_vars];

    net = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
        net[i] = new int[n_vars];

    parse_data();

    sep_cache = new int **[n_vars];
    for (i = 0; i < n_vars; ++i)
    {
        sep_cache[i] = new int *[n_vars];
        for (j = 0; j < n_vars; ++j)
        {
            sep_cache[i][j] = new int[max_max_cond_size];
        }
    }

    if (algorithm[strlen(algorithm) - 1] == 'L')
    {
        isLearnDAG = true;
    }
    else
    {
        isLearnDAG = false;
    }

    //select algorithm
    if (!strcmp(algorithm, "PC_simple"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            PC_simple(targets[j], neighs);
        }
    }
    else if (!strcmp(algorithm, "MMPC"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            MMPC(targets[j], neighs);
        }
    }
    else if (!strcmp(algorithm, "HITON_PC"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            Hiton_PC(targets[j], neighs);
        }
    }
    else if (!strcmp(algorithm, "Semi_HITON_PC"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            Semi_Hiton_PC(targets[j], neighs);
        }
    }
    else if (!strcmp(algorithm, "GetPC"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            Get_PC(targets[j], neighs);
            for (int var = 0; var < n_vars; ++var)
            {
                pc_iscomputed[var] = false;
                pc_cache[var].clear();
            }
        }
    }
    else if (!strcmp(algorithm, "MBtoPC"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            MBTOPC(targets[j], neighs);
        }
    }
    else if (!strcmp(algorithm, "GSMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            GSMB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "IAMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            IAMB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "KIAMB"))
    {
        k_tradeoff = atof(argv[6]);
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            IAMB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "TIE*"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            TIE_MB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "Inter_IAMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            Inter_IAMB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "LRH"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            LRH(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "BAMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            BAMB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "EEMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            EEMB(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "FBED"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            FBED(targets[j]);
        }
    }
    else if (!strcmp(algorithm, "MMMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            MMMB(targets[j], families, neighs);
        }
    }
    else if (!strcmp(algorithm, "MMMB-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            MMMB(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "MMMB-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            MMPC(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "PCMB"))
    {

        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            PCMB(targets[j], families, neighs);
            for (int var = 0; var < n_vars; ++var)
            {
                pc_iscomputed[var] = false;
                pc_cache[var].clear();
            }
        }
    }
    else if (!strcmp(algorithm, "PCMB-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            PCMB(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "PCMB-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            Get_PC(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "HITON_MB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            Hiton_MB(targets[j], families, neighs);
        }
    }
    else if (!strcmp(algorithm, "HITON_MB-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            Hiton_MB(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "HITON_MB-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            Hiton_PC(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "Semi_HITON_MB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            Semi_Hiton_MB(targets[j], families, neighs);
        }
    }
    else if (!strcmp(algorithm, "Semi_HITON_MB-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            Semi_Hiton_MB(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "Semi_HITON_MB-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            Semi_Hiton_PC(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "MBOR"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            MBOR(targets[j], families, neighs);
        }
    }
    else if (!strcmp(algorithm, "MBOR-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            MBOR(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "MBOR-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            MBTOPC(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "IPC_MB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            IPC_MB(targets[j], families, neighs);
        }
    }
    else if (!strcmp(algorithm, "IPC_MB-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            IPC_MB(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "IPC_MB-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            PC_simple(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "STMB"))
    {
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            clock_init = clock();
            STMB(targets[j], families, neighs);
        }
    }
    else if (!strcmp(algorithm, "STMB-CSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            STMB(targets[j], families, neighs);
        }
        Constrain_DAG(neighs, families, adjMat);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "STMB-SSL"))
    {
        clock_init = clock();
        for (unsigned long j = 0; j < targets.size(); ++j)
        {
            PC_simple(targets[j], neighs);
        }
        Score_DAG(neighs, data, adjMat, scoreFun);
        report_DAG(adjMat);
    }
    else if (!strcmp(algorithm, "CCMB"))
    {
        if (targets.size() == n_vars)
        {
            clock_init = clock();
            CCMB_all();
        }
        else
        {
            for (unsigned long j = 0; j < targets.size(); ++j)
            {
                clock_init = clock();
                CCMB(targets[j]);
            }
        }
    }
    else
    {
        std::cout << "Error: invalid algorithm name" << std::endl;
        fflush(stdout);
        exit(0);
    }

    if (algorithm[strlen(algorithm) - 1] != 'L')
    {
        if ((unsigned long)n_vars != targets.size())
        {
            average_perform_time = average_perform_time / (double)targets.size();

            average_Precision = average_Precision / (double)targets.size();
            average_Recall = average_Recall / (double)targets.size();
            average_F1 = average_F1 / (double)targets.size();
            average_Distance = average_Distance / (double)targets.size();
        }
        else
        {
            average_perform_time = average_perform_time / (double)n_vars;

            average_Precision = average_Precision / (double)n_vars;
            average_Recall = average_Recall / (double)n_vars;
            average_F1 = average_F1 / (double)n_vars;
            average_Distance = average_Distance / (double)n_vars;
        }
    }
    if ((unsigned long)n_vars != targets.size())
    {
        average_n_Fisher_z = average_n_Fisher_z / (double)targets.size();
    }
    else
    {
        average_n_Fisher_z = average_n_Fisher_z / (double)n_vars;
    }

    if (algorithm[strlen(algorithm) - 1] == 'L')
    {
        _file.open("indicator2/indicator.out", std::ios::out | std::ios::app); //read from memory into disk and open file in append mode
    }
    else
    {
        _file.open("indicator1/indicator.out", std::ios::out | std::ios::app); //read from memory into disk and open file in append mode
    }
    if (!_file)
    {
        std::cout << "error" << std::endl;
        return 0;
    }
    if (algorithm[strlen(algorithm) - 1] == 'L')
    {
        _file << "SHD:" << SHD << std::endl;
        _file << "undirected:" << undirected << std::endl;
        _file << "reverse:" << reverse << std::endl;
        _file << "miss:" << miss << std::endl;
        _file << "extra:" << extra << std::endl;
    }
    else
    {
        _file << "Precision:" << average_Precision << std::endl;
        _file << "Recall:" << average_Recall << std::endl;
        _file << "F1:" << average_F1 << std::endl;
        _file << "Distance:" << average_Distance << std::endl;
    }
    _file << "time:" << average_perform_time << std::endl;
    _file << "G2:" << average_n_Fisher_z << std::endl;
    _file << std::endl;
    _file.close();

    targets.clear();
    return 0;
}

/////////////////////////////////////

void parse_data(void)
{
    int i, j, k;
    char aux;
    int *cache;
    float auxf;
    FILE *f_in;
    std::ifstream fileStream;

    sigma = new double *[n_vars];
    for (i = 0; i < n_vars; i++)
        sigma[i] = new double[n_vars];

    //read the network adjacency matrix text data to **net
    fileStream.open(net_file_path, std::ios::in); //ios::in indicates that the file is read read-only
    cache = new int[n_vars * n_vars];

    if (fileStream.fail()) //file open failed
    {
        std::cout << "network adjacency matrix data text failed to open" << std::endl;
        exit(0);
    }
    else //file exists
    {
        i = 0;
        while (fileStream.get(aux))
        {
            if (aux == '0' || aux == '1')
            {
                cache[i] = atoi(&aux);
                i++;
                if (i > n_vars * n_vars - 1)
                {
                    break;
                }
            }
        }
        if (i != n_vars * n_vars)
        {
            std::cout << "The adjacency matrix text data is incorrect!";
            exit(0);
        }
        k = 0;
        for (i = 0; i < n_vars; i++)
        {
            for (j = 0; j < n_vars; j++)
            {
                net[i][j] = cache[k];
                k++;
            }
        }
        fileStream.close();
    }

    f_in = fopen(data_file_path, "r");
    for (i = 0; i < n_cases; i++)
        for (j = 0; j < n_vars; j++)
        {
            fscanf(f_in, "%f", &auxf);
            data_Continuous[i][j] = (double)auxf;
        }

    fclose(f_in);

    covariance(sigma);

    max_max_cond_size = n_vars - 2; //if the condition set of the independence test exceeds max_max_cond_size, the test result is no longer reliable.
}

/////////////////////////////////////

void covariance(double **sigma)
//I use the ML estimate though it is biased.
//The Fisher's z and t tests involve this estimate.
{
    int i, j, k;

    double *mean;

    mean = new double[n_vars];

    for (j = 0; j < n_vars; j++)
    {
        mean[j] = (double)0;

        for (i = 0; i < n_cases; i++)
            mean[j] += data_Continuous[i][j];

        mean[j] /= (double)n_cases;
    }

    for (j = 0; j < n_vars; j++)
        for (k = j; k < n_vars; k++)
        {
            sigma[j][k] = (double)0;

            for (i = 0; i < n_cases; i++)
                sigma[j][k] += ((data_Continuous[i][j] - mean[j]) * (data_Continuous[i][k] - mean[k]));

            sigma[j][k] /= (double)n_cases;

            sigma[k][j] = sigma[j][k];
        }

    delete[] mean;
}

/////////////////////////////////////

void MMMB(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, in_cond, n_conds;
    int *pc, *pc2, *mb, *cond;
    int **sep, **sep2;

    pc = new int[n_vars];
    pc2 = new int[n_vars];
    mb = new int[n_vars];

    cond = new int[max_max_cond_size];

    sep = new int *[n_vars];
    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
        sep2[i] = new int[max_max_cond_size];
    }

    pc_superset(target, pc, sep);

    for (i = 0; i < n_vars; i++)
        mb[i] = pc[i];

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1)
        {
            pc_superset(i, pc2, sep2);

            for (j = 0; j < n_vars; j++)
                //if (pc2[j] == 1 && pc[j] == 0 && j != target && mb[j] == 0)
                if (pc2[j] == 1 && pc[j] == 0 && j != target && (mb[j] == 0 || isLearnDAG))
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        bool _tag = false;
                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            mb[j] = 1;

                            list<Family>::iterator sfit;
                            for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                            {
                                if (sfit->spouse == j)
                                {
                                    sfit->children.push_back(i);
                                    _tag = true;
                                }
                            }
                            if (_tag == false)
                            {
                                list<int> commonChildren;
                                commonChildren.push_back(i);
                                families[target].push_back(Family(j, commonChildren));
                            }
                        }
                    }
                }
        }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }

    delete[] pc;
    delete[] pc2;
    delete[] mb;
    delete[] cond;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] sep2[i];
    }
    delete[] sep;
    delete[] sep2;
}

/////////////////////////////////////

void Semi_Hiton_MB(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, in_cond, n_conds;
    int *pc, *pc2, *mb, *cond;
    int **sep, **sep2;

    pc = new int[n_vars];
    pc2 = new int[n_vars];
    mb = new int[n_vars];

    cond = new int[max_max_cond_size];

    sep = new int *[n_vars];
    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
        sep2[i] = new int[max_max_cond_size];
    }

    semi_hiton_pc_set(target, pc, sep);

    for (i = 0; i < n_vars; i++)
        mb[i] = pc[i];

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1)
        {
            semi_hiton_pc_set(i, pc2, sep2);

            for (j = 0; j < n_vars; j++)
                if (pc2[j] == 1 && pc[j] == 0 && j != target && (mb[j] == 0 || isLearnDAG))
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        bool _tag = false;
                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            mb[j] = 1;

                            list<Family>::iterator sfit;
                            for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                            {
                                if (sfit->spouse == j)
                                {
                                    sfit->children.push_back(i);
                                    _tag = true;
                                }
                            }
                            if (_tag == false)
                            {
                                list<int> commonChildren;
                                commonChildren.push_back(i);
                                families[target].push_back(Family(j, commonChildren));
                            }
                        }
                    }
                }
        }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }

    delete[] pc;
    delete[] pc2;
    delete[] mb;
    delete[] cond;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] sep2[i];
    }
    delete[] sep;
    delete[] sep2;
}

/////////////////////////////////////

void Hiton_MB(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, in_cond, n_conds;
    int *pc, *pc2, *mb, *cond;
    int **sep, **sep2;

    pc = new int[n_vars];
    pc2 = new int[n_vars];
    mb = new int[n_vars];

    cond = new int[max_max_cond_size];

    sep = new int *[n_vars];
    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
        sep2[i] = new int[max_max_cond_size];
    }

    hiton_pc_set(target, pc, sep);

    for (i = 0; i < n_vars; i++)
        mb[i] = pc[i];

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1)
        {
            hiton_pc_set(i, pc2, sep2);

            for (j = 0; j < n_vars; j++)
                if (pc2[j] == 1 && pc[j] == 0 && j != target && (mb[j] == 0 || isLearnDAG))
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        bool _tag = false;
                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            mb[j] = 1;

                            list<Family>::iterator sfit;
                            for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                            {
                                if (sfit->spouse == j)
                                {
                                    sfit->children.push_back(i);
                                    _tag = true;
                                }
                            }
                            if (_tag == false)
                            {
                                list<int> commonChildren;
                                commonChildren.push_back(i);
                                families[target].push_back(Family(j, commonChildren));
                            }
                        }
                    }
                }
        }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }

    delete[] pc;
    delete[] pc2;
    delete[] mb;
    delete[] cond;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] sep2[i];
    }
    delete[] sep;
    delete[] sep2;
}

/////////////////////////////////////

void PCMB(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, in_cond, n_conds;
    int *pc, *pc2, *mb, *cond;
    int **sep, **sep2;

    pc = new int[n_vars];
    pc2 = new int[n_vars];
    mb = new int[n_vars];

    cond = new int[max_max_cond_size];

    sep = new int *[n_vars];
    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
        sep2[i] = new int[max_max_cond_size];
    }

    pc_set(target, pc, sep);

    for (i = 0; i < n_vars; i++)
        mb[i] = pc[i];

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1)
        {
            pc_set(i, pc2, sep2);

            for (j = 0; j < n_vars; j++)
                if (pc2[j] == 1 && pc[j] == 0 && j != target && (mb[j] == 0 || isLearnDAG))
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        bool _tag = false;
                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            mb[j] = 1;

                            list<Family>::iterator sfit;
                            for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                            {
                                if (sfit->spouse == j)
                                {
                                    sfit->children.push_back(i);
                                    _tag = true;
                                }
                            }
                            if (_tag == false)
                            {
                                list<int> commonChildren;
                                commonChildren.push_back(i);
                                families[target].push_back(Family(j, commonChildren));
                            }
                        }
                    }
                }
        }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }

    delete[] pc;
    delete[] pc2;
    delete[] mb;
    delete[] cond;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] sep2[i];
    }
    delete[] sep;
    delete[] sep2;
}

/////////////////////////////////////

void IAMB(int target)
{
    int i, j, k, stop, n_conds, aux;
    int *mb, *cond;
    double *dep;

    mb = new int[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    dep = new double[n_vars];

    do
    {
        stop = 1;
        if (n_conds < max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                        stop = 0;
                }
            }
        }

        if (stop == 0)
        {
            aux = k_greedy(dep);
            mb[aux] = 1;
            cond[n_conds] = aux;
            n_conds++;
        }
    } while (stop == 0);
    //the end of growth.

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_vars; i++)
    {
        if (mb[i] == 1)
        {
            for (j = 0; j < n_conds; j++)
                if (cond[j] == i)
                {
                    for (k = j; k < n_conds - 1; k++)
                        cond[k] = cond[k + 1];
                    cond[n_conds - 1] = -1;

                    j = n_conds; //end loop
                }

            dep[i] = compute_dep(i, target, cond);

            //cond[n_conds - 1] = i;

            if (dep[i] <= (double)(-1.0))
            {
                n_conds--;
                mb[i] = 0;
            }
            else
            {
                cond[n_conds - 1] = i;
            }
        }
    }

    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
    }
    report_mb(target, mb);

    delete[] mb;
    delete[] cond;
    delete[] dep;
}

/////////////////////////////////////

void Inter_IAMB(int target)
{
    int i, j, k, stop, n_conds, aux;
    int *mb, *cond, *removals;
    double *dep;

    mb = new int[n_vars];
    removals = new int[n_vars];

    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
        removals[i] = 0;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    dep = new double[n_vars];

    do
    {
        stop = 1;

        if (n_conds < max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                    {
                        stop = 0;
                    }
                }
            }
        }

        if (stop == 0)
        {
            aux = k_greedy(dep);
            mb[aux] = 1;
            cond[n_conds] = aux;
            n_conds++;
            //the end of growth.

            //Start to cut, if there is no node to join in the growth phase, there is no need to make a cut.
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 1 && removals[i] < 10)
                {
                    for (j = 0; j < n_conds; j++)
                        if (cond[j] == i)
                        {
                            for (k = j; k < n_conds - 1; k++)
                                cond[k] = cond[k + 1];
                            cond[n_conds - 1] = -1;

                            j = n_conds; //end loop
                        }

                    dep[i] = compute_dep(i, target, cond);

                    //cond[n_conds - 1] = i;

                    if (dep[i] <= (double)(-1.0))
                    {
                        n_conds--;
                        mb[i] = 0;
                        removals[i]++; //To avoid endless loop.
                    }
                    else
                    {
                        cond[n_conds - 1] = i;
                    }
                }
            }
        }

    } while (stop == 0);

    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
    }
    report_mb(target, mb);

    delete[] mb;
    delete[] cond;
    delete[] dep;
}

/////////////////////////////////////

void KIAMB(int target)
{
    int i, j, k, stop, n_conds, aux, n_CanMBs, n_CanMB2s;
    int *mb, *cond, *CanMB;
    double *dep, maxdep, K;

    mb = new int[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
    }
    mb[target] = -1;

    n_conds = 0;

    n_CanMB2s = 0;
    aux = 0;
    maxdep = (double)0.0;
    K = (double)0.0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    dep = new double[n_vars];

    do
    {
        stop = 1;
        if (n_conds < max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;
            n_CanMBs = 0;
            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                    {
                        stop = 0;
                        n_CanMBs++;
                    }
                }
            }
        }
        if (stop == 0)
        {
            CanMB = new int[n_CanMBs];
            j = 0;
            for (i = 0; i < n_vars; i++)
            {
                if (dep[i] >= (double)1.0)
                {
                    CanMB[j] = i;
                    j++;
                }
            }
            K = (double)rand() / RAND_MAX;
            n_CanMB2s = (int)(K * n_CanMBs) > 1 ? (int)(K * n_CanMBs) : 1;
            aux = rand() % n_CanMBs;

            j = -1;
            for (i = 0; i < n_CanMB2s; i++)
            {
                if (j == -1)
                {
                    j = CanMB[aux];
                    maxdep = dep[j];
                }
                else
                {
                    if (dep[CanMB[aux]] > maxdep)
                    {
                        j = CanMB[aux];
                        maxdep = dep[j];
                    }
                }
                aux++;
                if (aux == n_CanMBs)
                {
                    aux = 0;
                }
            }
            mb[j] = 1;
            cond[n_conds] = j;
            n_conds++;
            delete[] CanMB;
        }
    } while (stop == 0);
    //the end of growth.

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_vars; i++)
    {
        if (mb[i] == 1)
        {
            for (j = 0; j < n_conds; j++)
                if (cond[j] == i)
                {
                    for (k = j; k < n_conds - 1; k++)
                        cond[k] = cond[k + 1];
                    cond[n_conds - 1] = -1;

                    j = n_conds; //end loop
                }

            dep[i] = compute_dep(i, target, cond);

            //cond[n_conds - 1] = i;

            if (dep[i] <= (double)(-1.0))
            {
                n_conds--;
                mb[i] = 0;
            }
            else
            {
                cond[n_conds - 1] = i;
            }
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
    }
    report_mb(target, mb);

    delete[] mb;
    delete[] cond;
    delete[] dep;
}

/////////////////////////////////////

void TIE_MB(int target)
{
    int *altimate_mb;
    vector<int> mb;
    vector<int> MB_last;
    bool tag_update;
    list<vector<int> > MB; //record the generated MB_new
    list<vector<int> > Possible_subsets_G;
    list<vector<int> > G_set;  //record Gi
    list<vector<int> > _G_set; //record G*i
    int G_set_length = 0;

    G_set.clear();
    _G_set.clear();
    Possible_subsets_G.clear();
    MB.clear();

    altimate_mb = new int[n_vars];
    for (int var = 0; var < n_vars; ++var)
    {
        altimate_mb[var] = 0;
    }

    bool tag1 = false;
    do
    {
        if (Possible_subsets_G.size() == 0)
        {
            //start generating Possible_subsets_G
            if (G_set.size() == 0)
            {
                //first GeneratesPossible_subsets_G
                //run TIE_MB_induc_alg_X once to find G1 and M1
                vector<int> aux;
                mb.clear();
                aux.clear();
                TIE_MB_induc_alg_X(target, mb, aux);
                G_set.push_back(aux); //G1
                MB.push_back(mb);     //MB1
            }

            //find Possible_subsets_G from Gi and Mi
            for (list<vector<int> >::iterator iter_G = G_set.begin(), iter_MB = MB.begin(); iter_G != G_set.end(); iter_G++, iter_MB++)
            {
                if ((*iter_G).size() == G_set_length)
                {
                    set_plus(*iter_G, Possible_subsets_G, *iter_MB);
                }
            }

            //Possible_subsets_G deduplication
            for (list<vector<int> >::iterator iter = Possible_subsets_G.begin(); iter != Possible_subsets_G.end(); iter++)
            {
                sort((*iter).begin(), (*iter).end());
            }
            Possible_subsets_G.sort();
            Possible_subsets_G.erase(unique(Possible_subsets_G.begin(), Possible_subsets_G.end()), Possible_subsets_G.end());

            //there can be no set in Possible_subsets_G containing _G_set
            //list<vector<int> >::iterator iter2;
            bool delete_tag;
            for (list<vector<int> >::iterator iter = Possible_subsets_G.begin(); iter != Possible_subsets_G.end();)
            {
                delete_tag = false;
                for (list<vector<int> >::iterator iter3 = _G_set.begin(); iter3 != _G_set.end(); iter3++)
                {
                    if (isSubset((*iter), (*iter3)))
                    {
                        Possible_subsets_G.erase(iter++);
                        delete_tag = true;
                        break;
                    }
                }
                if (!delete_tag)
                {
                    iter++;
                }
            }
            G_set_length++;
            //std::cout<<G_set_length<<std::endl;

            if (Possible_subsets_G.size() == 0)
            {
                tag1 = true;
            }
        }
        else
        {
            //Each set in Possible_subsets_G is traversed until it is empty, and after it is empty, a new set of length +1 is generated.
            mb.clear();
            list<vector<int> >::iterator iter = Possible_subsets_G.begin();
            TIE_MB_induc_alg_X(target, mb, *iter);

            //determine if MB_new is better
            MB_last.clear();
            MB_last = MB.back();
            tag_update = criterion_Z(target, MB_last, mb);
            if (tag_update)
            {
                //update G_set and MB
                G_set.push_back(*iter);
                MB.push_back(mb);
            }
            else
            {
                //update _G_set
                _G_set.push_back(*iter);
            }
            Possible_subsets_G.erase(iter);
        }
    } while (!tag1);

    MB_last.clear();
    MB_last = MB.back();
    for (vector<int>::iterator iter = MB_last.begin(); iter < MB_last.end(); iter++)
    {
        altimate_mb[*iter] = 1;
    }

    report_mb(target, altimate_mb);

    delete[] altimate_mb;
}

/////////////////////////////////////

void LRH(int target)
{
    int i, j, k, stop, stop2, stop3, n_conds, K, belongtoM2, maxdep_index;
    int *pc, *mb, *cond, *M1, *M2;
    double *dep;
    double maxdep;

    pc = new int[n_vars];
    mb = new int[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        pc[i] = 0;
        mb[i] = 0;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    dep = new double[n_vars];
    M1 = new int[n_vars];
    M2 = new int[n_vars];

    //stop3 variable action: When M2 is empty, stop3 is always 1, if stop3 is 0, it means M2 is not empty.
    do
    {
        stop = 1;
        stop3 = 1;
        K = 3;
        if (n_conds < max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
            {
                M1[i] = -1;
                M2[i] = -1;
            }
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                    {
                        stop = 0;
                        M1[i] = 1;
                    }
                }
            }
        }

        if (stop == 0)
        {
            for (i = 0; i < n_vars; i++)
            {
                if (M1[i] == 1)
                {
                    belongtoM2 = 1;
                    for (j = 0; j < n_vars; j++)
                    {
                        if (M1[j] == 1 && j != i)
                        {
                            if (compute_dep(i, j, cond) >= (double)1.0)
                            {
                                cond[n_conds] = j;
                                if (compute_dep(i, target, cond) <= (double)-1.0)
                                { //As long as there is a cond so that i and T do not depend on the following operations
                                    belongtoM2 = 0;
                                    j = n_vars;
                                }
                                cond[n_conds] = -1;
                            }
                        }
                    }
                    if (belongtoM2 == 1)
                    {
                        M2[i] = 1;
                    }
                }
            }

            do //Add the node with the top K position of dependency in M2 to the MB.
            {
                stop2 = 1;
                maxdep = (double)0.0;
                maxdep_index = -1;
                for (i = 0; i < n_vars; i++)
                {
                    if (M2[i] == 1)
                    {
                        if (dep[i] > maxdep)
                        {
                            maxdep = dep[i];
                            maxdep_index = i;
                            stop2 = 0;
                        }
                    }
                }
                if (stop2 == 0)
                {
                    stop3 = 0;
                    if (n_conds < max_max_cond_size)
                    {
                        M2[maxdep_index] = -1;
                        mb[maxdep_index] = 1;
                        cond[n_conds] = maxdep_index;
                        n_conds++;
                    }
                    K--;
                }
                if (stop3 == 1)
                //Explain that M2 is empty, according to the algorithm idea, at this time,
                //the node with the largest dependence on M1 and T (under the condition of MB) is added to the MB.
                {
                    maxdep = (double)0.0;
                    maxdep_index = -1;
                    for (i = 0; i < n_vars; i++)
                    {
                        if (M1[i] == 1)
                        {
                            if (dep[i] > maxdep)
                            {
                                maxdep = dep[i];
                                maxdep_index = i;
                            }
                        }
                    }

                    if (n_conds < max_max_cond_size)
                    {
                        mb[maxdep_index] = 1;
                        cond[n_conds] = maxdep_index;
                        n_conds++;
                    }
                }
            } while (K > 0 && stop2 == 0);
        }
    } while (stop == 0);
    //the end of growth.

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_vars; i++)
    {
        if (mb[i] == 1)
        {
            for (j = 0; j < n_conds; j++)
                if (cond[j] == i)
                {
                    for (k = j; k < n_conds - 1; k++)
                        cond[k] = cond[k + 1];
                    cond[n_conds - 1] = -1;

                    j = n_conds; //end loop
                }

            dep[i] = compute_dep(i, target, cond);

            //cond[n_conds - 1] = i;

            if (dep[i] <= (double)(-1.0))
            {
                n_conds--;
                mb[i] = 0;
            }
            else
            {
                cond[n_conds - 1] = i;
            }
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
    }
    report_mb(target, mb);

    delete[] pc;
    delete[] mb;
    delete[] cond;
    delete[] dep;
    delete[] M1;
    delete[] M2;
}

/////////////////////////////////////

void BAMB(int target)
{
    int i, j, k, m, n, in_cond, n_conds, last_added, n_ranks, n_codes, cond_size, stop;
    int *rank, *pc, *mb, *sep2, *cond, *sep_tag, *code, *cond_index; //sep_tag is used to record whether the cut set of each node has been initialized
    int **sep;
    double *dep;
    std::vector<vector<int> > sp_dep_rank(n_vars), spouse(n_vars);
    //sp_dep_rank stores T about the sposee set of a node, and these spose nodes are sorted by dependency -- CSP.
    //spouse --SP
    std::vector<int> Z;
    std::vector<int> pre_sps;     //store the original sorted sps
    std::vector<int> pc_dep_rank; //store CPC in order of dependency size

    dep = new double[n_vars];
    pc = new int[n_vars];
    mb = new int[n_vars];
    sep2 = new int[max_max_cond_size];
    cond = new int[max_max_cond_size];
    sep_tag = new int[n_vars];

    sep = new int *[n_vars];
    for (i = 0; i < n_vars; ++i)
    {
        sep[i] = new int[max_max_cond_size];
    }

    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
    }
    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
            sep[i][j] = -1;

    for (i = 0; i < n_vars; i++)
        pc[i] = 0;

    pc[target] = -1;

    for (i = 0; i < n_vars; i++)
    {
        dep[i] = (double)0.0;
        sep_tag[i] = 0;
        sp_dep_rank[i].clear();
        spouse[i].clear();
    }

    last_added = -1;
    n_ranks = 0;
    pc_dep_rank.clear();

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 0)
        {
            dep[i] = min_dep(i, target, -1, pc, sep2);

            if (dep[i] <= (double)-1.0)
            {
                pc[i] = -1;
                sep_tag[i] = 1;
                for (j = 0; j < max_max_cond_size; j++)
                    sep[i][j] = sep2[j];
            }
            if (dep[i] >= (double)1.0)
            {
                n_ranks++;
            }
        }
    rank = new int[n_ranks];

    //under the empty set condition, the nodes with the T dependency greater than 0 are sorted and loaded into the rank array.
    j = 0;
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 0 && j < n_ranks)
        {
            rank[j] = i;
            for (k = j; k > 0; k--)
            {
                if (dep[rank[k]] > dep[rank[k - 1]])
                {
                    rank[k] = rank[k] + rank[k - 1];
                    rank[k - 1] = rank[k] - rank[k - 1];
                    rank[k] = rank[k] - rank[k - 1];
                }
            }
            j++;
        }
    }

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_ranks; i++) //n_ranks is the length of cpc in the BAMB algorithm.
    {
        pc[rank[i]] = 1;
        last_added = rank[i];
        //crop

        //the node that is added from the rank after cutting, because the dependency of the node behind the rank is smaller, it will be cropped.
        pc[last_added] = 0;
        if (min_dep(last_added, target, -1, pc, sep2) <= (double)(-1.0))
        {
            for (k = 0; k < max_max_cond_size; k++)
                sep[last_added][k] = sep2[k];
            pc[last_added] = -1;
            continue; //if the node just added from rank is directly cropped, the subsequent for loop will not be done because there is no new node.
            //in the case of joining, the current pc is already cropped.
        }
        else
        {
            pc[last_added] = 1;
            pc_dep_rank.push_back(last_added);
        }

        for (j = 0; j < n_vars; j++)
        {
            if (pc[j] == 1 && j != last_added)
            {
                pc[j] = 0;

                dep[j] = min_dep(j, target, last_added, pc, sep2);

                pc[j] = 1;

                if (dep[j] <= (double)(-1.0)) //find the pc node with less than 0 dependency and delete it immediately, which is different from the cutting phase of Get_PC and MMPC.
                {
                    for (k = 0; k < max_max_cond_size; k++)
                        sep[j][k] = sep2[k];
                    pc[j] = -1;
                    for (vector<int>::iterator it2 = pc_dep_rank.begin(); it2 < pc_dep_rank.end();)
                    {
                        if (*it2 == j)
                        {
                            it2 = pc_dep_rank.erase(it2);
                        }
                        else
                        {
                            it2++;
                        }
                    }
                }
            }
        }

        //for a node that is newly added to the PC, immediately find its spouse.

        //spY
        for (j = 0; j < n_vars; j++)
            dep[j] = (double)0.0;
        for (j = 0; j < n_vars; ++j)
        {
            if (j != target && pc[j] != 1)
            { //superset spouse --- sps
                in_cond = 0;
                n_conds = 0;
                for (k = 0; k < max_max_cond_size; k++)
                {
                    cond[k] = sep[j][k];

                    if (cond[k] == last_added)
                        in_cond = 1;

                    if (cond[k] != -1)
                        n_conds++;
                }
                if (in_cond == 0 && n_conds < max_max_cond_size)
                {
                    cond[n_conds] = last_added;

                    dep[j] = compute_dep(j, target, cond);

                    if (dep[j] <= (double)(-1.0))
                    {
                        if (sep_tag[j] == 0)
                        {
                            for (k = 0; k < max_max_cond_size; ++k)
                            {
                                sep[j][k] = cond[k];
                            }
                        }
                    }
                }
            }
        }

        pre_sps.clear();
        double max_dep;
        int max_dep_index;
        for (j = 0; j < n_vars; ++j)
        {
            max_dep = 0.0;
            max_dep_index = -1;
            for (k = 0; k < n_vars; ++k)
            {
                if (dep[k] > max_dep)
                {
                    max_dep_index = k;
                    max_dep = dep[k];
                }
            }
            if (max_dep_index == -1)
            {
                break;
            }
            else
            {
                pre_sps.push_back(max_dep_index);
                dep[max_dep_index] = (double)0.0;
            }
        }

        //1pc+1spouse or 1pc+0spouse delete spouse
        for (vector<int>::iterator it = pre_sps.begin(); it < pre_sps.end(); ++it)
        {
            sp_dep_rank[last_added].push_back(*it);
        }

        int sps_length, sp_length;
        sps_length = sp_dep_rank[last_added].size();
        for (j = 0; j < sps_length; ++j)
        {
            vector<int>::iterator it = sp_dep_rank[last_added].begin();
            spouse[last_added].push_back(*it);
            sp_dep_rank[last_added].erase(it); //add the most dependent spouse from the CSP to the SP

            sp_length = spouse[last_added].size();
            for (k = sp_length - 1; k >= 0; k--)
            {
                if (k == sp_length - 1)
                {
                    //First detect the spose node added later
                    int tag = 0;
                    for (m = 0; m < k; ++m)
                    {
                        tag = 1;
                        n_conds = 0;
                        for (n = 0; n < max_max_cond_size; ++n)
                        {
                            cond[n] = -1;
                        }
                        cond[n_conds] = spouse[last_added][m];
                        n_conds++;
                        if (n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = last_added;
                            n_conds++;
                        }
                        if (compute_dep(spouse[last_added][k], target, cond) <= (double)(-1.0))
                        {
                            vector<int>::iterator it2 = spouse[last_added].end() - 1;

                            if (sep_tag[*it2] == 0)
                            {
                                for (n = 0; n < max_max_cond_size; ++n)
                                {
                                    sep[*it2][n] = cond[n];
                                }
                            }
                            spouse[last_added].erase(it2);

                            k = -1;
                            break;
                        }
                    }
                    if (tag == 0)
                    { //SP(T){Y}\{X} is empty
                        n_conds = 0;
                        for (n = 0; n < max_max_cond_size; ++n)
                        {
                            cond[n] = -1;
                        }
                        cond[n_conds] = last_added;
                        n_conds++;

                        if (compute_dep(spouse[last_added][k], target, cond) <= (double)(-1.0))
                        {
                            vector<int>::iterator it2 = spouse[last_added].end() - 1;

                            if (sep_tag[*it2] == 0)
                            {
                                for (n = 0; n < max_max_cond_size; ++n)
                                {
                                    sep[*it2][n] = cond[n];
                                }
                            }
                            spouse[last_added].erase(it2);

                            break;
                        }
                    }
                }
                else
                {
                    //detect other spouse nodes
                    n_conds = 0;
                    for (n = 0; n < max_max_cond_size; ++n)
                    {
                        cond[n] = -1;
                    }
                    int spouse_end = spouse[last_added].size();
                    cond[n_conds] = spouse[last_added][spouse_end - 1];
                    n_conds++;
                    if (n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = last_added;
                        n_conds++;
                    }
                    if (compute_dep(spouse[last_added][k], target, cond) <= (double)(-1.0))
                    {

                        for (vector<int>::iterator it2 = spouse[last_added].begin(); it2 < spouse[last_added].end(); it2++)
                        {
                            if (*it2 == spouse[last_added][k])
                            {
                                if (sep_tag[*it2] == 0)
                                {
                                    for (n = 0; n < max_max_cond_size; ++n)
                                    {
                                        sep[*it2][n] = cond[n];
                                    }
                                }
                                spouse[last_added].erase(it2);
                                break;
                            }
                        }
                    }
                }
            }
        }

        //spouse delete spouse
        for (vector<int>::iterator it = spouse[last_added].begin(); it < spouse[last_added].end(); ++it)
        {
            sp_dep_rank[last_added].push_back(*it);
        }

        spouse[last_added].clear(); //SP(T){Y} blanking

        sps_length = sp_dep_rank[last_added].size();
        for (j = 0; j < sps_length; ++j)
        {
            vector<int>::iterator it = sp_dep_rank[last_added].begin();
            spouse[last_added].push_back(*it);
            sp_dep_rank[last_added].erase(it); //add the most dependent spouse from the CSP to the SP

            sp_length = spouse[last_added].size();
            for (k = sp_length - 1; k >= 0; k--)
            {
                if (k == sp_length - 1)
                { //First detect the added sposee node, if it is deleted directly, break
                    Z.clear();
                    for (m = 0; m < k; ++m)
                    {
                        Z.push_back(spouse[last_added][m]);
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m < max_max_cond_size)
                                    {
                                        cond[m] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[last_added][k], last_added, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;
                                    k = -1;
                                    vector<int>::iterator it2 = spouse[last_added].end() - 1;

                                    if (sep_tag[*it2] == 0)
                                    {
                                        for (n = 0; n < max_max_cond_size; ++n)
                                        {
                                            sep[*it2][n] = cond[n];
                                        }
                                    }
                                    spouse[last_added].erase(it2);
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
                else
                { //detect other spouse nodes
                    Z.clear();
                    for (vector<int>::iterator it = spouse[last_added].begin(); it < spouse[last_added].end() - 1; ++it)
                    { //note -1
                        if (*it != spouse[last_added][k])
                        {
                            Z.push_back(*it);
                        }
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    vector<int>::iterator it2 = spouse[last_added].end() - 1;
                    cond[n_conds] = *it2;
                    n_conds++;

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size + 1 <= max_max_cond_size && cond_size < k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m + 1 < max_max_cond_size)
                                    {
                                        cond[m + 1] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[last_added][k], last_added, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;

                                    for (vector<int>::iterator it2 = spouse[last_added].begin(); it2 < spouse[last_added].end(); it2++)
                                    {
                                        if (*it2 == spouse[last_added][k])
                                        {
                                            if (sep_tag[*it2] == 0)
                                            {
                                                for (n = 0; n < max_max_cond_size; ++n)
                                                {
                                                    sep[*it2][n] = cond[n];
                                                }
                                            }
                                            spouse[last_added].erase(it2);
                                            break;
                                        }
                                    }
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
            }
        }

        //pc+spouse delete spouse
        for (vector<int>::iterator it = spouse[last_added].begin(); it < spouse[last_added].end(); ++it)
        {
            sp_dep_rank[last_added].push_back(*it);
        }

        spouse[last_added].clear(); //SP(T){Y} blanking

        sps_length = sp_dep_rank[last_added].size();
        for (j = 0; j < sps_length; ++j)
        {
            vector<int>::iterator it = sp_dep_rank[last_added].begin();
            spouse[last_added].push_back(*it);
            sp_dep_rank[last_added].erase(it); //add the most dependent spouse from the CSP to the SP

            sp_length = spouse[last_added].size();
            for (k = sp_length - 1; k >= 0; k--)
            {
                if (k == sp_length - 1)
                { //first detect the added sposee node, if it is deleted directly, break
                    Z.clear();
                    for (m = 0; m < k; ++m)
                    {
                        Z.push_back(spouse[last_added][m]);
                    }
                    int count = 0;
                    for (m = 0; m < n_vars; ++m)
                    {
                        if (pc[m] == 1 && m != last_added)
                        {
                            count++;
                            Z.push_back(m);
                        }
                    }
                    if (count < 1)
                    {
                        continue;
                    }

                    //start removing duplicate elements
                    std::sort(Z.begin(), Z.end());
                    vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                    Z.erase(end_unique, Z.end());

                    for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                    {
                        if (*it == spouse[last_added][k])
                        {
                            it = Z.erase(it);
                        }
                        else
                        {
                            it++;
                        }
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    cond[n_conds] = last_added;
                    n_conds++;

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size + 1 <= max_max_cond_size && cond_size <= k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m + 1 < max_max_cond_size)
                                    {
                                        cond[m + 1] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[last_added][k], target, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;
                                    k = -1;
                                    vector<int>::iterator it2 = spouse[last_added].end() - 1;

                                    if (sep_tag[*it2] == 0)
                                    {
                                        for (n = 0; n < max_max_cond_size; ++n)
                                        {
                                            sep[*it2][n] = cond[n];
                                        }
                                    }
                                    spouse[last_added].erase(it2);
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
                else
                { //detect other spouse nodes
                    Z.clear();
                    for (vector<int>::iterator it = spouse[last_added].begin(); it < spouse[last_added].end() - 1; ++it)
                    { //note -1
                        if (*it != spouse[last_added][k])
                        {
                            Z.push_back(*it);
                        }
                    }
                    int count = 0;
                    for (m = 0; m < n_vars; ++m)
                    {
                        if (pc[m] == 1 && m != last_added)
                        {
                            count++;
                            Z.push_back(m);
                        }
                    }
                    if (count < 1)
                    {
                        continue;
                    }

                    //start removing duplicate elements
                    std::sort(Z.begin(), Z.end());
                    vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                    Z.erase(end_unique, Z.end());

                    for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                    {
                        if (*it == spouse[last_added][k])
                        {
                            it = Z.erase(it);
                        }
                        else
                        {
                            it++;
                        }
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    cond[n_conds] = last_added;
                    n_conds++;
                    if (n_conds < max_max_cond_size)
                    {
                        vector<int>::iterator it2 = spouse[last_added].end() - 1;
                        cond[n_conds] = *it2;
                        n_conds++;
                    }

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size + 2 <= max_max_cond_size && cond_size < k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m + 2 < max_max_cond_size)
                                    {
                                        cond[m + 2] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[last_added][k], target, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;

                                    for (vector<int>::iterator it2 = spouse[last_added].begin(); it2 < spouse[last_added].end(); it2++)
                                    {
                                        if (*it2 == spouse[last_added][k])
                                        {
                                            if (sep_tag[*it2] == 0)
                                            {
                                                for (n = 0; n < max_max_cond_size; ++n)
                                                {
                                                    sep[*it2][n] = cond[n];
                                                }
                                            }
                                            spouse[last_added].erase(it2);
                                            break;
                                        }
                                    }
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
            }
        }

        //pc+spouse delete pc
        int pc_length = pc_dep_rank.size();
        for (j = pc_length - 1; j >= 0; j--)
        {
            if (j == pc_length - 1)
            {
                Z.clear();

                for (k = 0; k < j; ++k)
                {
                    Z.push_back(pc_dep_rank[k]);
                    for (vector<int>::iterator it = spouse[pc_dep_rank[k]].begin(); it < spouse[pc_dep_rank[k]].end(); it++)
                    {
                        Z.push_back(*it);
                    }
                }

                //start removing duplicate elements
                std::sort(Z.begin(), Z.end());
                vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                Z.erase(end_unique, Z.end());

                for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                {
                    if (*it == pc_dep_rank[j])
                    {
                        it = Z.erase(it);
                    }
                    else
                    {
                        it++;
                    }
                }

                n_codes = Z.size();
                code = new int[n_codes];

                for (m = 0; m < n_codes; ++m)
                {
                    code[m] = Z[m];
                }

                n_conds = 0;
                for (m = 0; m < max_max_cond_size; ++m)
                {
                    cond[m] = -1;
                }

                for (cond_size = 0; cond_size <= n_codes; cond_size++)
                {
                    if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                    {
                        cond_index = new int[cond_size];
                        for (m = 0; m < cond_size; m++)
                            cond_index[m] = m;

                        do
                        {
                            stop = 0;

                            for (m = 0; m < cond_size; m++)
                            {
                                if (m < max_max_cond_size)
                                {
                                    cond[m] = code[cond_index[m]];
                                }
                            }

                            if (compute_dep(pc_dep_rank[j], target, cond) <= (double)(-1.0))
                            {
                                stop = 1;
                                cond_size = n_codes + 1;
                                j = -1;
                                vector<int>::iterator it2 = pc_dep_rank.end() - 1;

                                if (sep_tag[*it2] == 0)
                                {
                                    for (n = 0; n < max_max_cond_size; ++n)
                                    {
                                        sep[*it2][n] = cond[n];
                                    }
                                }
                                pc[*it2] = -1;
                                spouse[*it2].clear();
                                pc_dep_rank.erase(it2);
                            }

                            if (stop == 0)
                                stop = next_cond_index(n_codes, cond_size, cond_index);
                        } while (stop == 0);

                        delete[] cond_index;
                    }
                }
                delete[] code;
            }
            else
            {
                Z.clear();

                for (vector<int>::iterator it = pc_dep_rank.begin(); it < pc_dep_rank.end() - 1; ++it)
                { //note -1
                    if (*it != pc_dep_rank[j])
                    {
                        Z.push_back(*it);
                        for (vector<int>::iterator it2 = spouse[*it].begin(); it2 < spouse[*it].end(); it2++)
                        {
                            Z.push_back(*it2);
                        }
                    }
                }

                //start removing duplicate elements
                std::sort(Z.begin(), Z.end());
                vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                Z.erase(end_unique, Z.end());

                for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                {
                    if (*it == pc_dep_rank[j])
                    {
                        it = Z.erase(it);
                    }
                    else
                    {
                        it++;
                    }
                }

                n_codes = Z.size();
                code = new int[n_codes];

                for (m = 0; m < n_codes; ++m)
                {
                    code[m] = Z[m];
                }

                n_conds = 0;
                for (m = 0; m < max_max_cond_size; ++m)
                {
                    cond[m] = -1;
                }
                for (cond_size = 0; cond_size <= n_codes; cond_size++)
                {
                    if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                    {
                        cond_index = new int[cond_size];
                        for (m = 0; m < cond_size; m++)
                            cond_index[m] = m;

                        do
                        {
                            stop = 0;

                            for (m = 0; m < cond_size; m++)
                            {
                                if (m < max_max_cond_size)
                                {
                                    cond[m] = code[cond_index[m]];
                                }
                            }
                            if (compute_dep(pc_dep_rank[j], target, cond) <= (double)(-1.0))
                            {
                                stop = 1;
                                cond_size = n_codes + 1;

                                for (vector<int>::iterator it2 = pc_dep_rank.begin(); it2 < pc_dep_rank.end(); it2++)
                                {
                                    if (*it2 == pc_dep_rank[j])
                                    {
                                        if (sep_tag[*it2] == 0)
                                        {
                                            for (n = 0; n < max_max_cond_size; ++n)
                                            {
                                                sep[*it2][n] = cond[n];
                                            }
                                        }
                                        pc[*it2] = -1;
                                        spouse[*it2].clear();
                                        pc_dep_rank.erase(it2);
                                        break;
                                    }
                                }
                            }

                            if (stop == 0)
                                stop = next_cond_index(n_codes, cond_size, cond_index);
                        } while (stop == 0);

                        delete[] cond_index;
                    }
                }
                delete[] code;
            }
        }
    }
    for (i = 0; i < n_vars; ++i)
    {
        mb[i] = 0;
    }

    for (vector<int>::iterator it = pc_dep_rank.begin(); it < pc_dep_rank.end(); ++it)
    {
        mb[*it] = 1;
        for (vector<int>::iterator it2 = spouse[*it].begin(); it2 < spouse[*it].end(); ++it2)
        {
            mb[*it2] = 1;
        }
    }

    report_mb(target, mb);

    delete[] rank;
    delete[] pc;
    delete[] mb;
    delete[] sep2;
    delete[] cond;
    delete[] sep_tag;
    delete[] dep;
    for (i = 0; i < n_vars; ++i)
    {
        delete[] sep[i];
    }
    delete[] sep;

    for (i = 0; i < n_vars; ++i)
    {
        sp_dep_rank[i].clear();
        spouse[i].clear();
    }
    sp_dep_rank.clear();
    spouse.clear();
    Z.clear();
    pre_sps.clear();
    pc_dep_rank.clear();
}

/////////////////////////////////////

void EEMB(int target)
{
    int i, j, k, m, n, in_cond, n_conds, last_added, n_ranks, n_codes, cond_size, stop;
    int *rank, *pc, *mb, *sep2, *cond, *code, *cond_index, *IND;
    int **sep;
    double *dep, **dep2;
    double aux;
    std::vector<vector<int> > sp_dep_rank(n_vars), spouse(n_vars);
    //sp_dep_rank stores T about the sposee set of a node, and these spose nodes are sorted by dependency -- CSP.
    //spouse --SP
    std::vector<int> Z;
    std::vector<int> pre_sps;     //store the original sorted sps
    std::vector<int> pc_dep_rank; //store CPC in order of dependency size
    std::vector<int> pre_cpc;

    dep = new double[n_vars];
    pc = new int[n_vars];
    mb = new int[n_vars];
    sep2 = new int[max_max_cond_size];
    cond = new int[max_max_cond_size];
    IND = new int[n_vars];

    dep2 = new double *[n_vars];
    sep = new int *[n_vars];
    for (i = 0; i < n_vars; ++i)
    {
        sep[i] = new int[max_max_cond_size];
        dep2[i] = new double[n_vars];
    }

    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
    }
    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
        {
            sep[i][j] = -1;
        }

    for (i = 0; i < n_vars; i++)
        for (j = 0; j < n_vars; j++)
        {
            dep2[i][j] = (double)0.0;
        }
    for (i = 0; i < n_vars; i++)
        pc[i] = 0;

    pc[target] = -1;

    for (i = 0; i < n_vars; i++)
    {
        dep[i] = (double)0.0;
        sp_dep_rank[i].clear();
        spouse[i].clear();
        IND[i] = 1;
    }
    IND[target] = 0;

    last_added = -1;
    n_ranks = 0;
    pc_dep_rank.clear();
    pre_cpc.clear();

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 0)
        {
            dep[i] = min_dep(i, target, -1, pc, sep2);

            if (dep[i] <= (double)-1.0)
            {
                pc[i] = -1;
                for (j = 0; j < max_max_cond_size; j++)
                    sep[i][j] = sep2[j];
            }
            if (dep[i] >= (double)1.0)
            {
                IND[i] = 0;
                n_ranks++;
            }
        }
    rank = new int[n_ranks];

    //under the empty set condition, the nodes with the T dependency greater than 0 are sorted and loaded into the rank array.
    j = 0;
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 0 && j < n_ranks)
        {
            rank[j] = i;
            for (k = j; k > 0; k--)
            {
                if (dep[rank[k]] > dep[rank[k - 1]])
                {
                    rank[k] = rank[k] + rank[k - 1];
                    rank[k - 1] = rank[k] - rank[k - 1];
                    rank[k] = rank[k] - rank[k - 1];
                }
            }
            j++;
        }
    }

    for (i = 0; i < n_ranks; i++) //n_ranks is the length of cpc in the EEMB algorithm.
    {
        pc[rank[i]] = 1;
        last_added = rank[i];
        //crop

        //the node that is added from the rank after cutting, because the dependency of the node behind the rank is smaller, it will be cropped.
        pc[last_added] = 0;
        if (min_dep(last_added, target, -1, pc, sep2) <= (double)(-1.0))
        {
            for (k = 0; k < max_max_cond_size; k++)
                sep[last_added][k] = sep2[k];
            pc[last_added] = -1;
            IND[last_added] = 1;
            for (j = 0; j < n_vars; j++)
            {
                if (pc[j] == 1)
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[last_added][k];

                        if (cond[k] == j)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }
                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = j;

                        dep2[j][last_added] = compute_dep(last_added, target, cond);
                    }
                }
            }
            continue; //if the node just added from rank is directly cropped, the subsequent for loop will not be done because there is no new node.
            //In the case of joining, the current pc is already cropped.
        }
        else
        {
            pc[last_added] = 1;
            pc_dep_rank.push_back(last_added);
        }

        for (j = 0; j < n_vars; j++)
        {
            if (pc[j] == 1 && j != last_added)
            {
                pc[j] = 0;

                aux = min_dep(j, target, last_added, pc, sep2);

                pc[j] = 1;

                if (aux <= (double)(-1.0)) //find the pc node with less than 0 dependency and delete it immediately, which is different from the cutting phase of Get_PC and MMPC.
                {
                    for (k = 0; k < max_max_cond_size; k++)
                        sep[j][k] = sep2[k];
                    pc[j] = -1;
                    IND[j] = 1;
                    for (k = 0; k < n_vars; k++)
                    {
                        if (pc[k] == 1)
                        {
                            in_cond = 0;
                            n_conds = 0;
                            for (m = 0; m < max_max_cond_size; m++)
                            {
                                cond[m] = sep[j][m];

                                if (cond[m] == k)
                                    in_cond = 1;

                                if (cond[m] != -1)
                                    n_conds++;
                            }
                            if (in_cond == 0 && n_conds < max_max_cond_size)
                            {
                                cond[n_conds] = k;

                                dep2[k][j] = compute_dep(j, target, cond);
                            }
                        }
                    }
                    for (vector<int>::iterator it2 = pc_dep_rank.begin(); it2 < pc_dep_rank.end();)
                    {
                        if (*it2 == j)
                        {
                            it2 = pc_dep_rank.erase(it2);
                        }
                        else
                        {
                            it2++;
                        }
                    }
                }
            }
        }

        //for a node that is newly added to the PC, immediately find its spouse.

        //spY
        for (j = 0; j < n_vars; ++j)
        {
            if (IND[j] == 1)
            { //superset spouse --- sps
                in_cond = 0;
                n_conds = 0;
                for (k = 0; k < max_max_cond_size; k++)
                {
                    cond[k] = sep[j][k];

                    if (cond[k] == last_added)
                        in_cond = 1;

                    if (cond[k] != -1)
                        n_conds++;
                }
                if (in_cond == 0 && n_conds < max_max_cond_size)
                {
                    cond[n_conds] = last_added;

                    dep2[last_added][j] = compute_dep(j, target, cond);
                }
            }
        }
    }

    for (vector<int>::iterator iter = pc_dep_rank.begin(); iter != pc_dep_rank.end(); iter++)
    {
        pre_sps.clear();
        double max_dep;
        int max_dep_index;
        for (j = 0; j < n_vars; ++j)
        {
            max_dep = 0.0;
            max_dep_index = -1;
            for (k = 0; k < n_vars; ++k)
            {
                if (dep2[*iter][k] > max_dep)
                {
                    max_dep_index = k;
                    max_dep = dep2[*iter][k];
                }
            }
            if (max_dep_index == -1)
            {
                break;
            }
            else
            {
                pre_sps.push_back(max_dep_index);
                dep2[*iter][max_dep_index] = (double)0.0;
            }
        }

        //1pc+1spouse or 1pc+0spouse delete spouse
        for (vector<int>::iterator it = pre_sps.begin(); it < pre_sps.end(); ++it)
        {
            sp_dep_rank[*iter].push_back(*it);
        }

        int sps_length, sp_length;
        sps_length = sp_dep_rank[*iter].size();
        for (j = 0; j < sps_length; ++j)
        {
            vector<int>::iterator it = sp_dep_rank[*iter].begin();
            spouse[*iter].push_back(*it);
            sp_dep_rank[*iter].erase(it); //add the most dependent spouse from the CSP to the SP

            sp_length = spouse[*iter].size();
            for (k = sp_length - 1; k >= 0; k--)
            {
                if (k == sp_length - 1)
                {
                    //First detect the spose node added later
                    int tag = 0;
                    for (m = 0; m < k; ++m)
                    {
                        tag = 1;
                        n_conds = 0;
                        for (n = 0; n < max_max_cond_size; ++n)
                        {
                            cond[n] = -1;
                        }
                        cond[n_conds] = spouse[*iter][m];
                        n_conds++;
                        if (n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = *iter;
                            n_conds++;
                        }
                        if (compute_dep(spouse[*iter][k], target, cond) <= (double)(-1.0))
                        {
                            vector<int>::iterator it2 = spouse[*iter].end() - 1;

                            spouse[*iter].erase(it2);

                            k = -1;
                            break;
                        }
                    }
                    if (tag == 0)
                    { //SP(T){Y}\{X} is empty
                        n_conds = 0;
                        for (n = 0; n < max_max_cond_size; ++n)
                        {
                            cond[n] = -1;
                        }
                        cond[n_conds] = *iter;
                        n_conds++;

                        if (compute_dep(spouse[*iter][k], target, cond) <= (double)(-1.0))
                        {
                            vector<int>::iterator it2 = spouse[*iter].end() - 1;

                            spouse[*iter].erase(it2);

                            break;
                        }
                    }
                }
                else
                {
                    //detect other spouse nodes
                    n_conds = 0;
                    for (n = 0; n < max_max_cond_size; ++n)
                    {
                        cond[n] = -1;
                    }
                    int spouse_end = spouse[*iter].size();
                    cond[n_conds] = spouse[*iter][spouse_end - 1];
                    n_conds++;
                    if (n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = *iter;
                        n_conds++;
                    }
                    if (compute_dep(spouse[*iter][k], target, cond) <= (double)(-1.0))
                    {

                        for (vector<int>::iterator it2 = spouse[*iter].begin(); it2 < spouse[*iter].end(); it2++)
                        {
                            if (*it2 == spouse[*iter][k])
                            {

                                spouse[*iter].erase(it2);
                                break;
                            }
                        }
                    }
                }
            }
        }

        //spouse delete spouse
        for (vector<int>::iterator it = spouse[*iter].begin(); it < spouse[*iter].end(); ++it)
        {
            sp_dep_rank[*iter].push_back(*it);
        }

        spouse[*iter].clear(); //SP(T){Y} blanking

        sps_length = sp_dep_rank[*iter].size();
        for (j = 0; j < sps_length; ++j)
        {
            vector<int>::iterator it = sp_dep_rank[*iter].begin();
            spouse[*iter].push_back(*it);
            sp_dep_rank[*iter].erase(it); //add the most dependent spouse from the CSP to the SP

            sp_length = spouse[*iter].size();
            for (k = sp_length - 1; k >= 0; k--)
            {
                if (k == sp_length - 1)
                { //First detect the added sposee node, if it is deleted directly, break
                    Z.clear();
                    for (m = 0; m < k; ++m)
                    {
                        Z.push_back(spouse[*iter][m]);
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m < max_max_cond_size)
                                    {
                                        cond[m] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[*iter][k], *iter, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;
                                    k = -1;
                                    vector<int>::iterator it2 = spouse[*iter].end() - 1;

                                    spouse[*iter].erase(it2);
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
                else
                { //detect other spouse nodes
                    Z.clear();
                    for (vector<int>::iterator it = spouse[*iter].begin(); it < spouse[*iter].end() - 1; ++it)
                    { //note -1
                        if (*it != spouse[*iter][k])
                        {
                            Z.push_back(*it);
                        }
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    vector<int>::iterator it2 = spouse[*iter].end() - 1;
                    cond[n_conds] = *it2;
                    n_conds++;

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size + 1 <= max_max_cond_size && cond_size < k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m + 1 < max_max_cond_size)
                                    {
                                        cond[m + 1] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[*iter][k], *iter, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;

                                    for (vector<int>::iterator it2 = spouse[*iter].begin(); it2 < spouse[*iter].end(); it2++)
                                    {
                                        if (*it2 == spouse[*iter][k])
                                        {

                                            spouse[*iter].erase(it2);
                                            break;
                                        }
                                    }
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
            }
        }

        //pc+spouse delete spouse
        for (vector<int>::iterator it = spouse[*iter].begin(); it < spouse[*iter].end(); ++it)
        {
            sp_dep_rank[*iter].push_back(*it);
        }

        spouse[*iter].clear(); //SP(T){Y} blanking

        sps_length = sp_dep_rank[*iter].size();
        for (j = 0; j < sps_length; ++j)
        {
            vector<int>::iterator it = sp_dep_rank[*iter].begin();
            spouse[*iter].push_back(*it);
            sp_dep_rank[*iter].erase(it); //add the most dependent spouse from the CSP to the SP

            sp_length = spouse[*iter].size();
            for (k = sp_length - 1; k >= 0; k--)
            {
                if (k == sp_length - 1)
                { //First detect the added sposee node, if it is deleted directly, break
                    Z.clear();
                    for (m = 0; m < k; ++m)
                    {
                        Z.push_back(spouse[*iter][m]);
                    }
                    int count = 0;
                    for (m = 0; m < n_vars; ++m)
                    {
                        if (pc[m] == 1 && m != *iter)
                        {
                            count++;
                            Z.push_back(m);
                        }
                    }
                    if (count < 1)
                    {
                        continue;
                    }

                    //start removing duplicate elements
                    std::sort(Z.begin(), Z.end());
                    vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                    Z.erase(end_unique, Z.end());

                    for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                    {
                        if (*it == spouse[*iter][k])
                        {
                            it = Z.erase(it);
                        }
                        else
                        {
                            it++;
                        }
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    cond[n_conds] = *iter;
                    n_conds++;

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size + 1 <= max_max_cond_size && cond_size <= k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m + 1 < max_max_cond_size)
                                    {
                                        cond[m + 1] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[*iter][k], target, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;
                                    k = -1;
                                    vector<int>::iterator it2 = spouse[*iter].end() - 1;

                                    spouse[*iter].erase(it2);
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
                else
                { //detect other spouse nodes
                    Z.clear();
                    for (vector<int>::iterator it = spouse[*iter].begin(); it < spouse[*iter].end() - 1; ++it)
                    { //note -1
                        if (*it != spouse[*iter][k])
                        {
                            Z.push_back(*it);
                        }
                    }
                    int count = 0;
                    for (m = 0; m < n_vars; ++m)
                    {
                        if (pc[m] == 1 && m != *iter)
                        {
                            count++;
                            Z.push_back(m);
                        }
                    }
                    if (count < 1)
                    {
                        continue;
                    }

                    //start removing duplicate elements
                    std::sort(Z.begin(), Z.end());
                    vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                    Z.erase(end_unique, Z.end());

                    for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                    {
                        if (*it == spouse[*iter][k])
                        {
                            it = Z.erase(it);
                        }
                        else
                        {
                            it++;
                        }
                    }

                    n_codes = Z.size();
                    code = new int[n_codes];

                    for (m = 0; m < n_codes; ++m)
                    {
                        code[m] = Z[m];
                    }

                    n_conds = 0;
                    for (m = 0; m < max_max_cond_size; ++m)
                    {
                        cond[m] = -1;
                    }

                    cond[n_conds] = *iter;
                    n_conds++;
                    if (n_conds < max_max_cond_size)
                    {
                        vector<int>::iterator it2 = spouse[*iter].end() - 1;
                        cond[n_conds] = *it2;
                        n_conds++;
                    }

                    for (cond_size = 0; cond_size <= n_codes; cond_size++)
                    {
                        if (cond_size + 2 <= max_max_cond_size && cond_size < k_conditon)
                        {
                            cond_index = new int[cond_size];
                            for (m = 0; m < cond_size; m++)
                                cond_index[m] = m;

                            do
                            {
                                stop = 0;

                                for (m = 0; m < cond_size; m++)
                                {
                                    if (m + 2 < max_max_cond_size)
                                    {
                                        cond[m + 2] = code[cond_index[m]];
                                    }
                                }
                                if (compute_dep(spouse[*iter][k], target, cond) <= (double)(-1.0))
                                {
                                    stop = 1;
                                    cond_size = n_codes + 1;

                                    for (vector<int>::iterator it2 = spouse[*iter].begin(); it2 < spouse[*iter].end(); it2++)
                                    {
                                        if (*it2 == spouse[*iter][k])
                                        {

                                            spouse[*iter].erase(it2);
                                            break;
                                        }
                                    }
                                }

                                if (stop == 0)
                                    stop = next_cond_index(n_codes, cond_size, cond_index);
                            } while (stop == 0);

                            delete[] cond_index;
                        }
                    }
                    delete[] code;
                }
            }
        }
    }

    for (vector<int>::iterator iter = pc_dep_rank.begin(); iter != pc_dep_rank.end(); iter++)
    {
        pre_cpc.push_back(*iter);
    }
    pc_dep_rank.clear();
    for (vector<int>::iterator iter = pre_cpc.begin(); iter != pre_cpc.end(); iter++)
    {
        pc_dep_rank.push_back(*iter);
        int pc_length = pc_dep_rank.size();
        for (j = pc_length - 1; j >= 0; j--)
        {
            if (j == pc_length - 1)
            {
                Z.clear();

                for (k = 0; k < j; ++k)
                {
                    Z.push_back(pc_dep_rank[k]);
                    for (vector<int>::iterator it = spouse[pc_dep_rank[k]].begin(); it < spouse[pc_dep_rank[k]].end(); it++)
                    {
                        Z.push_back(*it);
                    }
                }

                //start removing duplicate elements
                std::sort(Z.begin(), Z.end());
                vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                Z.erase(end_unique, Z.end());

                for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                {
                    if (*it == pc_dep_rank[j])
                    {
                        it = Z.erase(it);
                    }
                    else
                    {
                        it++;
                    }
                }

                n_codes = Z.size();
                code = new int[n_codes];

                for (m = 0; m < n_codes; ++m)
                {
                    code[m] = Z[m];
                }

                n_conds = 0;
                for (m = 0; m < max_max_cond_size; ++m)
                {
                    cond[m] = -1;
                }

                for (cond_size = 0; cond_size <= n_codes; cond_size++)
                {
                    if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                    {
                        cond_index = new int[cond_size];
                        for (m = 0; m < cond_size; m++)
                            cond_index[m] = m;

                        do
                        {
                            stop = 0;

                            for (m = 0; m < cond_size; m++)
                            {
                                if (m < max_max_cond_size)
                                {
                                    cond[m] = code[cond_index[m]];
                                }
                            }

                            if (compute_dep(pc_dep_rank[j], target, cond) <= (double)(-1.0))
                            {
                                stop = 1;
                                cond_size = n_codes + 1;
                                j = -1;
                                vector<int>::iterator it2 = pc_dep_rank.end() - 1;

                                pc[*it2] = -1;
                                spouse[*it2].clear();
                                pc_dep_rank.erase(it2);
                            }

                            if (stop == 0)
                                stop = next_cond_index(n_codes, cond_size, cond_index);
                        } while (stop == 0);

                        delete[] cond_index;
                    }
                }
                delete[] code;
            }
            else
            {
                Z.clear();

                for (vector<int>::iterator it = pc_dep_rank.begin(); it < pc_dep_rank.end() - 1; ++it)
                { //note -1
                    if (*it != pc_dep_rank[j])
                    {
                        Z.push_back(*it);
                        for (vector<int>::iterator it2 = spouse[*it].begin(); it2 < spouse[*it].end(); it2++)
                        {
                            Z.push_back(*it2);
                        }
                    }
                }

                //start removing duplicate elements
                std::sort(Z.begin(), Z.end());
                vector<int>::iterator end_unique = std::unique(Z.begin(), Z.end());
                Z.erase(end_unique, Z.end());

                for (vector<int>::iterator it = Z.begin(); it < Z.end();)
                {
                    if (*it == pc_dep_rank[j])
                    {
                        it = Z.erase(it);
                    }
                    else
                    {
                        it++;
                    }
                }

                n_codes = Z.size();
                code = new int[n_codes];

                for (m = 0; m < n_codes; ++m)
                {
                    code[m] = Z[m];
                }

                n_conds = 0;
                for (m = 0; m < max_max_cond_size; ++m)
                {
                    cond[m] = -1;
                }
                for (cond_size = 0; cond_size <= n_codes; cond_size++)
                {
                    if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                    {
                        cond_index = new int[cond_size];
                        for (m = 0; m < cond_size; m++)
                            cond_index[m] = m;

                        do
                        {
                            stop = 0;

                            for (m = 0; m < cond_size; m++)
                            {
                                if (m < max_max_cond_size)
                                {
                                    cond[m] = code[cond_index[m]];
                                }
                            }
                            if (compute_dep(pc_dep_rank[j], target, cond) <= (double)(-1.0))
                            {
                                stop = 1;
                                cond_size = n_codes + 1;

                                for (vector<int>::iterator it2 = pc_dep_rank.begin(); it2 < pc_dep_rank.end(); it2++)
                                {
                                    if (*it2 == pc_dep_rank[j])
                                    {

                                        pc[*it2] = -1;
                                        spouse[*it2].clear();
                                        pc_dep_rank.erase(it2);
                                        break;
                                    }
                                }
                            }

                            if (stop == 0)
                                stop = next_cond_index(n_codes, cond_size, cond_index);
                        } while (stop == 0);

                        delete[] cond_index;
                    }
                }
                delete[] code;
            }
        }
    }

    for (i = 0; i < n_vars; ++i)
    {
        mb[i] = 0;
    }

    for (vector<int>::iterator it = pc_dep_rank.begin(); it < pc_dep_rank.end(); ++it)
    {
        mb[*it] = 1;
        for (vector<int>::iterator it2 = spouse[*it].begin(); it2 < spouse[*it].end(); ++it2)
        {
            mb[*it2] = 1;
        }
    }

    report_mb(target, mb);

    delete[] rank;
    delete[] pc;
    delete[] mb;
    delete[] sep2;
    delete[] cond;
    delete[] dep;
    for (i = 0; i < n_vars; ++i)
    {
        delete[] sep[i];
    }
    delete[] sep;

    for (i = 0; i < n_vars; ++i)
    {
        sp_dep_rank[i].clear();
        spouse[i].clear();
    }
    sp_dep_rank.clear();
    spouse.clear();
    Z.clear();
    pre_sps.clear();
    pc_dep_rank.clear();
    pre_cpc.clear();
}

/////////////////////////////////////

void FBED(int target)
{
    int i, j, k, stop1, tag, n_conds, n_Rs, aux, K, K_cur;
    int *mb, *cond, *R;
    double *dep;

    mb = new int[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    R = new int[n_vars];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    for (i = 0; i < n_vars; ++i)
    {
        R[i] = 0;
    }

    dep = new double[n_vars];

    K = 1;
    K_cur = 0;

    //start of growth phase
    do
    {
        stop1 = 1; //stop1 records whether mb has changed

        if (n_conds < max_max_cond_size)
        {
            n_Rs = 0;
            for (i = 0; i < n_vars; ++i)
            {
                if (mb[i] == 0)
                {
                    R[i] = 1;
                    n_Rs++;
                }
            }

            tag = 1;
            while (n_Rs > 0 && tag == 1)
            {
                tag = 0; //record a single round of growth phase, whether there is node and T dependent under the condition of cond
                if (n_conds < max_max_cond_size)
                {
                    for (i = 0; i < n_vars; i++)
                        dep[i] = (double)0.0;

                    for (i = 0; i < n_vars; i++)
                    {
                        if (R[i] == 1)
                        {
                            dep[i] = compute_dep(i, target, cond);

                            if (dep[i] >= (double)1.0)
                            {
                                tag = 1;
                                stop1 = 0;
                            }
                        }
                    }

                    if (tag == 1)
                    {
                        aux = k_greedy(dep);
                        mb[aux] = 1;
                        cond[n_conds] = aux;
                        n_conds++;
                        for (i = 0; i < n_vars; ++i)
                        {
                            if (i == aux || dep[i] <= (double)(-1.0))
                            {
                                R[i] = 0;
                                n_Rs--;
                            }
                        }
                    }
                }
            }
        }

        K_cur++;

    } while (K_cur <= K && stop1 == 0); //end of growth phase

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_vars; i++)
    {
        if (mb[i] == 1)
        {
            for (j = 0; j < n_conds; j++)
                if (cond[j] == i)
                {
                    for (k = j; k < n_conds - 1; k++)
                        cond[k] = cond[k + 1];
                    cond[n_conds - 1] = -1;

                    j = n_conds; //end loop
                }

            dep[i] = compute_dep(i, target, cond);

            if (dep[i] <= (double)(-1.0))
            {
                n_conds--;
                mb[i] = 0;
            }
            else
            {
                cond[n_conds - 1] = i;
            }
        }
    }

    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
    }
    report_mb(target, mb);

    delete[] mb;
    delete[] cond;
    delete[] dep;
}

/////////////////////////////////////

void MBOR(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, in_cond, n_conds;
    int *D, *pcs, *mbs, *pc, *mb, *pc2, *mb2, *cond;
    int **sep, **sep2;

    pcs = new int[n_vars];
    mbs = new int[n_vars];
    pc = new int[n_vars];
    mb = new int[n_vars];
    pc2 = new int[n_vars];
    mb2 = new int[n_vars];
    D = new int[n_vars];
    cond = new int[max_max_cond_size];
    sep = new int *[n_vars];
    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
        sep2[i] = new int[max_max_cond_size];
    }

    //Stage 1
    PCSuperSet(target, pcs, sep);

    for (i = 0; i < n_vars; i++)
    {
        mbs[i] = pcs[i];
    }

    MBSuperSet(target, mbs, pcs, sep);

    for (i = 0; i < n_vars; i++)
    {
        if (mbs[i] == 1 || i == target)
            D[i] = 1;
        else
            D[i] = -1;
    }

    //Stage 2
    MBtoPC(target, D, pc, mb, sep);
    for (i = 0; i < n_vars; i++)
    {
        if (pcs[i] == 1 && pc[i] != 1)
        {
            MBtoPC(i, D, pc2, mb2, sep2);
            if (pc2[target] == 1)
            {
                pc[i] = 1;
            }
        }
    }

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
    }
    //Stage 3
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            MBtoPC(i, D, pc2, mb2, sep2);

            for (j = 0; j < n_vars; j++)
            {
                if (pc2[j] == 1 && pc[j] != 1 && j != target && (mb[j] == 0 || isLearnDAG))
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        bool _tag = false;
                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            mb[j] = 1;

                            list<Family>::iterator sfit;
                            for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                            {
                                if (sfit->spouse == j)
                                {
                                    sfit->children.push_back(i);
                                    _tag = true;
                                }
                            }
                            if (_tag == false)
                            {
                                list<int> commonChildren;
                                commonChildren.push_back(i);
                                families[target].push_back(Family(j, commonChildren));
                            }
                        }
                    }
                }
            }
        }
    }
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            mb[i] = 1;
        }
    }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }

    delete[] pc;
    delete[] mb;
    delete[] pcs;
    delete[] mbs;
    delete[] pc2;
    delete[] mb2;
    delete[] cond;
    delete[] D;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] sep2[i];
    }
    delete[] sep;
    delete[] sep2;
}

/////////////////////////////////////

void IPC_MB(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, in_cond, n_conds;
    int *CanADJ, *pc, *pc2, *mb, *cond;
    int **sep, **sep2;

    pc = new int[n_vars];
    pc2 = new int[n_vars];
    mb = new int[n_vars];
    CanADJ = new int[n_vars];
    cond = new int[max_max_cond_size];

    sep = new int *[n_vars];
    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
        sep2[i] = new int[max_max_cond_size];
    }

    recognize_pc(target, CanADJ, pc, sep);

    for (i = 0; i < n_vars; i++)
    {
        mb[i] = pc[i];
    }

    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            recognize_pc(i, CanADJ, pc2, sep2);
            if (pc2[target] != 1)
            {
                mb[i] = 0;
                pc[i] = 0;

                for (int var = 0; var < max_max_cond_size; ++var)
                {
                    sep[i][var] = sep2[target][var];
                }
                continue;
            }
            for (j = 0; j < n_vars; j++)
            {
                if (pc2[j] == 1 && pc[j] == 0 && j != target && (mb[j] == 0 || isLearnDAG))
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        bool _tag = false;
                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            mb[j] = 1;

                            list<Family>::iterator sfit;
                            for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                            {
                                if (sfit->spouse == j)
                                {
                                    sfit->children.push_back(i);
                                    _tag = true;
                                }
                            }
                            if (_tag == false)
                            {
                                list<int> commonChildren;
                                commonChildren.push_back(i);
                                families[target].push_back(Family(j, commonChildren));
                            }
                        }
                    }
                }
            }
        }
    }

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }

    delete[] CanADJ;
    delete[] mb;
    delete[] pc;
    delete[] pc2;
    delete[] cond;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] sep2[i];
    }
    delete[] sep;
    delete[] sep2;
}

/////////////////////////////////////

void STMB(int target, vector<list<Family> > &families, vector<list<int> > &neighs)
{
    int i, j, k, m, in_cond, n_conds, n_pc, cond_size, stop, flag;
    int *CanADJ, *pc, *mb, *remove, *cond, *code, *cond_index, *spouse_tag;
    //*spouse_tag is used to mark whether a node's spouse has been added to the cond to prevent it from being added multiple times.
    int **sep, **spouse;
    double aux;

    pc = new int[n_vars];
    mb = new int[n_vars];
    CanADJ = new int[n_vars];
    remove = new int[n_vars];
    //node to be removed:remove[i]=1;
    cond = new int[max_max_cond_size];
    spouse_tag = new int[n_vars];
    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
    }
    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
    }

    spouse = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        spouse[i] = new int[n_vars];
    }
    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }

    //step 1: ﬁnd the PC set
    recognize_pc(target, CanADJ, pc, sep);

    //step 2: ﬁnd spouses and remove non-child descendants
    for (i = 0; i < n_vars; i++)
    {
        for (j = 0; j < n_vars; j++)
        {
            spouse[i][j] = 0;
        }
    }
    for (i = 0; i < n_vars; i++)
    {
        remove[i] = 0;
    }

    n_pc = 0;
    for (k = 0; k < n_vars; k++)
        if (pc[k] == 1)
            n_pc++;
    code = new int[n_pc];
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            for (j = 0; j < n_vars; j++)
            {
                if (pc[j] != 1 && j != target)
                {
                    in_cond = 0;
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];

                        if (cond[k] == i)
                            in_cond = 1;

                        if (cond[k] != -1)
                            n_conds++;
                    }

                    if (in_cond == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = i;

                        if (compute_dep(j, target, cond) >= (double)1.0)
                        {
                            flag = 0;
                            m = 0;
                            for (k = 0; k < max_max_cond_size; k++)
                            {
                                cond[k] = -1;
                            }
                            for (k = 0; k < n_vars; k++)
                                if ((pc[k] == 1 && k != i) || k == j)
                                {
                                    code[m] = k;
                                    m++;
                                }
                            for (cond_size = 0; cond_size <= n_pc; cond_size++)
                            {
                                if (cond_size <= max_max_cond_size && cond_size <= k_conditon)
                                {
                                    cond_index = new int[cond_size];
                                    for (k = 0; k < cond_size; k++)
                                        cond_index[k] = k;

                                    do
                                    {
                                        stop = 0;

                                        for (k = 0; k < cond_size; k++)
                                        {
                                            if (k < max_max_cond_size)
                                            {
                                                cond[k] = code[cond_index[k]];
                                            }
                                        }

                                        aux = compute_dep(i, target, cond);

                                        if (aux <= (double)(-1.0))
                                        {
                                            remove[i] = 1;

                                            stop = 1;
                                            cond_size = n_pc + 1;
                                            j = n_vars;
                                            flag = 1;
                                        }

                                        if (stop == 0)
                                            stop = next_cond_index(n_pc, cond_size, cond_index);
                                    } while (stop == 0);

                                    delete[] cond_index;
                                }
                            }
                            if (flag == 0)
                            {
                                spouse[i][j] = 1;
                            }
                        }
                    }
                }
            }
        }
    }
    delete[] code;

    for (i = 0; i < n_vars; i++)
    {
        if (remove[i] == 1)
        {
            pc[i] = 0;
            for (j = 0; j < n_vars; j++)
            {
                spouse[i][j] = 0;
            }
        }
    }

    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            for (j = 0; j < n_vars; j++)
            {
                if (spouse[i][j] == 1)
                {
                    n_conds = 0;
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = -1;
                    }

                    for (k = 0; k < n_vars; k++)
                    {
                        if (pc[k] == 1 && n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = k;
                            n_conds++;
                        }
                    }
                    for (k = 0; k < n_vars; k++)
                    {
                        if (spouse[i][k] == 1 && k != j && n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = k;
                            n_conds++;
                        }
                    }

                    if (compute_dep(j, target, cond) <= (double)(-1.0))
                    {
                        spouse[i][j] = 0;

                        for (k = 0; k < n_vars; k++)
                        {
                            spouse[k][j] = 0;
                        }
                    }
                }
            }
        }
    }
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            for (j = 0; j < n_vars; j++)
            {
                spouse_tag[j] = 0;
            }
            n_conds = 0;
            for (j = 0; j < max_max_cond_size; j++)
            {
                cond[j] = -1;
            }
            for (j = 0; j < n_vars; j++)
            {
                if (spouse[i][j] == 1 && n_conds < max_max_cond_size)
                {
                    cond[n_conds] = j;
                    spouse_tag[j] = 1;
                    n_conds++;
                }
            }
            for (j = 0; j < n_vars; j++)
            {
                if (pc[j] == 1 && j != i)
                {
                    if (spouse_tag[j] == 0 && n_conds < max_max_cond_size)
                    {
                        cond[n_conds] = j;
                        spouse_tag[j] = 1;
                        n_conds++;
                    }
                    for (k = 0; k < n_vars; k++)
                    {
                        if (spouse[j][k] == 1 && spouse_tag[k] == 0 && n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = k;
                            spouse_tag[k] = 1;
                            n_conds++;
                        }
                    }
                }
            }
            if (compute_dep(i, target, cond) <= (double)(-1.0))
            {
                pc[i] = 0;
                for (j = 0; j < n_vars; j++)
                {
                    spouse[i][j] = 0;
                }
            }
        }
    }

    pc[target] = 0;
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            mb[i] = 1;

            for (j = 0; j < n_vars; j++)
            {
                bool _tag = false;
                if (spouse[i][j] == 1)
                {
                    mb[j] = 1;

                    list<Family>::iterator sfit;
                    for (sfit = families[target].begin(); sfit != families[target].end(); ++sfit)
                    {
                        if (sfit->spouse == j)
                        {
                            sfit->children.push_back(i);
                            _tag = true;
                        }
                    }
                    if (_tag == false)
                    {
                        list<int> commonChildren;
                        commonChildren.push_back(i);
                        families[target].push_back(Family(j, commonChildren));
                    }
                }
            }
        }
    }

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_mb(target, mb);
    }
    delete[] CanADJ;
    delete[] pc;
    delete[] mb;
    delete[] remove;
    delete[] cond;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
        delete[] spouse[i];
    }
    delete[] sep;
    delete[] spouse;
}

/////////////////////////////////////

void CCMB(int target)
{
    int **pc_matrix, ***sep, **mb;
    pc_matrix = new int *[n_vars];
    sep = new int **[n_vars];
    mb = new int *[n_vars];
    for (int i = 0; i < n_vars; i++)
    {
        pc_matrix[i] = new int[n_vars];
        sep[i] = new int *[n_vars];
        for (int j = 0; j < n_vars; j++)
            sep[i][j] = new int[max_max_cond_size];
        mb[i] = new int[n_vars];
    }

    for (int i = 0; i < n_vars; i++)
    {
        pc_superset(i, pc_matrix[i], sep[i]);
    }

    for (int i = 0; i < n_vars; i++)
    {
        for (int j = 0; j < n_vars; j++)
        {
            if (pc_matrix[i][j] == 1)
            {
                pc_matrix[j][i] = 1;
            }
        }
    }

    for (int i = 0; i < n_vars; i++)
        for (int j = 0; j < n_vars; j++)
            mb[i][j] = pc_matrix[i][j];

    int in_cond, n_conds;
    int *cond;
    cond = new int[max_max_cond_size];
    for (int i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    for (int i = 0; i < n_vars; i++)
    {
        for (int j = 0; j < n_vars; j++)
        {
            if (pc_matrix[i][j] == 1)
            {
                for (int k = i + 1; k < n_vars; k++)
                {
                    if (pc_matrix[j][k] == 1 && pc_matrix[i][k] == 0 && k != i && mb[i][k] == 0)
                    {
                        in_cond = 0;
                        n_conds = 0;
                        for (int kk = 0; kk < max_max_cond_size; kk++)
                        {
                            cond[kk] = sep[i][k][kk];

                            if (cond[kk] == j)
                                in_cond = 1;

                            if (cond[kk] != -1)
                                n_conds++;
                        }

                        if (in_cond == 0 && n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = j;

                            if (compute_dep(k, i, cond) >= (double)1.0)
                            {
                                mb[i][k] = 1;
                                mb[k][i] = 1;
                            }
                        }
                    }
                }
            }
        }
    }

    report_mb(target, mb[target]);

    for (int i = 0; i < n_vars; i++)
    {
        delete[] pc_matrix[i];
        for (int j = 0; j < n_vars; j++)
            delete[] sep[i][j];
        delete[] sep[i];
        delete[] mb[i];
    }
    delete[] pc_matrix;
    delete[] sep;
    delete[] mb;
}

/////////////////////////////////////

void CCMB_all()
{
    int **pc_matrix, ***sep, **mb;
    pc_matrix = new int *[n_vars];
    sep = new int **[n_vars];
    mb = new int *[n_vars];
    for (int i = 0; i < n_vars; i++)
    {
        pc_matrix[i] = new int[n_vars];
        sep[i] = new int *[n_vars];
        for (int j = 0; j < n_vars; j++)
            sep[i][j] = new int[max_max_cond_size];
        mb[i] = new int[n_vars];
    }

    for (int i = 0; i < n_vars; i++)
    {
        pc_superset(i, pc_matrix[i], sep[i]);
    }

    for (int i = 0; i < n_vars; i++)
    {
        for (int j = 0; j < n_vars; j++)
        {
            if (pc_matrix[i][j] == 1)
            {
                pc_matrix[j][i] = 1;
            }
        }
    }

    for (int i = 0; i < n_vars; i++)
        for (int j = 0; j < n_vars; j++)
            mb[i][j] = pc_matrix[i][j];

    int in_cond, n_conds;
    int *cond;
    cond = new int[max_max_cond_size];
    for (int i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    for (int i = 0; i < n_vars; i++)
    {
        for (int j = 0; j < n_vars; j++)
        {
            if (pc_matrix[i][j] == 1)
            {
                for (int k = i + 1; k < n_vars; k++)
                {
                    if (pc_matrix[j][k] == 1 && pc_matrix[i][k] == 0 && k != i && mb[i][k] == 0)
                    {
                        in_cond = 0;
                        n_conds = 0;
                        for (int kk = 0; kk < max_max_cond_size; kk++)
                        {
                            cond[kk] = sep[i][k][kk];

                            if (cond[kk] == j)
                                in_cond = 1;

                            if (cond[kk] != -1)
                                n_conds++;
                        }

                        if (in_cond == 0 && n_conds < max_max_cond_size)
                        {
                            cond[n_conds] = j;

                            if (compute_dep(k, i, cond) >= (double)1.0)
                            {
                                mb[i][k] = 1;
                                mb[k][i] = 1;
                            }
                        }
                    }
                }
            }
        }
    }

    for (int i = 0; i < n_vars; i++)
        report_mb(i, mb[i]);

    for (int i = 0; i < n_vars; i++)
    {
        delete[] pc_matrix[i];
        for (int j = 0; j < n_vars; j++)
            delete[] sep[i][j];
        delete[] sep[i];
        delete[] mb[i];
    }
    delete[] pc_matrix;
    delete[] sep;
    delete[] mb;
}

/////////////////////////////////////

void GSMB(int target)
{
    int i, j, k, stop, n_conds;
    int *mb, *cond;
    double dep;

    mb = new int[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;
    do
    {
        stop = 1;
        if (n_conds < max_max_cond_size)
        {
            dep = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep = compute_dep(i, target, cond);

                    if (dep >= (double)1.0)
                    {
                        stop = 0;
                        mb[i] = 1;
                        cond[n_conds] = i;
                        n_conds++;
                        break;
                    }
                }
            }
        }
    } while (stop == 0);
    //the end of growth.

    for (i = 0; i < n_vars; i++)
    {
        if (mb[i] == 1)
        {
            for (j = 0; j < n_conds; j++)
                if (cond[j] == i)
                {
                    for (k = j; k < n_conds - 1; k++)
                        cond[k] = cond[k + 1];
                    cond[n_conds - 1] = -1;

                    j = n_conds; //end loop
                }

            dep = compute_dep(i, target, cond);

            //cond[n_conds - 1] = i;

            if (dep <= (double)(-1.0))
            {
                n_conds--;
                mb[i] = 0;
            }
            else
            {
                cond[n_conds - 1] = i;
            }
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
    }
    report_mb(target, mb);

    delete[] mb;
    delete[] cond;
}

/////////////////////////////////////
/////////////////////////////////////

void PC_simple(int target, vector<list<int> > &neighs)
{
    int i;
    int *CanADJ, *pc;
    int **sep;

    pc = new int[n_vars];
    CanADJ = new int[n_vars];
    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }
    recognize_pc(target, CanADJ, pc, sep);

    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_pc(target, pc);
    }

    delete[] pc;
    delete[] CanADJ;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
    }
    delete[] sep;
}

/////////////////////////////////////

void MMPC(int target, vector<list<int> > &neighs)
{
    int i;
    int *pc;
    int **sep;

    pc = new int[n_vars];

    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }

    pc_superset(target, pc, sep);

    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] != 1)
        {
            pc[i] = 0;
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_pc(target, pc);
    }

    delete[] pc;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
    }
    delete[] sep;
}

/////////////////////////////////////

void Hiton_PC(int target, vector<list<int> > &neighs)
{
    int i;
    int *pc;
    int **sep;

    pc = new int[n_vars];
    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }

    hiton_pc_set(target, pc, sep);

    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] != 1)
        {
            pc[i] = 0;
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_pc(target, pc);
    }

    delete[] pc;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
    }
    delete[] sep;
}

/////////////////////////////////////

void Semi_Hiton_PC(int target, vector<list<int> > &neighs)
{
    int i;
    int *pc;
    int **sep;

    pc = new int[n_vars];
    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }

    semi_hiton_pc_set(target, pc, sep);

    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] != 1)
        {
            pc[i] = 0;
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_pc(target, pc);
    }

    delete[] pc;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
    }
    delete[] sep;
}

/////////////////////////////////////

void Get_PC(int target, vector<list<int> > &neighs)
{
    int i;
    int *pc;
    int **sep;

    pc = new int[n_vars];
    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }

    pc_set(target, pc, sep);

    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] != 1)
        {
            pc[i] = 0;
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_pc(target, pc);
    }

    delete[] pc;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
    }
    delete[] sep;
}

/////////////////////////////////////

void MBTOPC(int target, vector<list<int> > &neighs)
{
    int **sep;
    int i;
    int *D, *pcs, *mbs, *pc, *mb;

    sep = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        sep[i] = new int[max_max_cond_size];
    }
    pcs = new int[n_vars];
    mbs = new int[n_vars];
    pc = new int[n_vars];
    mb = new int[n_vars];
    D = new int[n_vars];

    //stage 1
    PCSuperSet(target, pcs, sep);

    for (i = 0; i < n_vars; i++)
    {
        mbs[i] = pcs[i];
    }

    MBSuperSet(target, mbs, pcs, sep);

    for (i = 0; i < n_vars; i++)
    {
        if (mbs[i] == 1 || i == target)
            D[i] = 1;
        else
            D[i] = -1;
    }

    //stage 2
    MBtoPC(target, D, pc, mb, sep);
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] != 1)
        {
            pc[i] = 0;
        }
    }
    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            neighs[target].push_back(var);
        }
    }

    if (!isLearnDAG)
    {
        report_pc(target, pc);
    }

    delete[] pc;
    delete[] mb;
    delete[] pcs;
    delete[] mbs;
    delete[] D;
    for (i = 0; i < n_vars; i++)
    {
        delete[] sep[i];
    }
    delete[] sep;
}

/////////////////////////////////////
/////////////////////////////////////

void hiton_pc_set(int target, int *pc, int **sep)
{
    int i, j, k, last_added, n_ranks;
    int *sep2, *rank;
    double *dep;

    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
            sep[i][j] = -1;

    if (pc_iscomputed[target] == true)
    {
        for (i = 0; i < n_vars; i++)
            pc[i] = 0;

        for (vector<int>::iterator it = pc_cache[target].begin(); it < pc_cache[target].end(); ++it)
            pc[*it] = 1;

        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep[i][j] = sep_cache[target][i][j];
            }
        }

        return;
    }

    sep2 = new int[max_max_cond_size];

    dep = new double[n_vars];

    for (i = 0; i < n_vars; i++)
        pc[i] = 0;

    pc[target] = -1;

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    last_added = -1;
    n_ranks = 0;

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 0)
        {
            dep[i] = min_dep(i, target, -1, pc, sep2);

            if (dep[i] <= (double)-1.0)
            {
                pc[i] = -1;
                for (j = 0; j < max_max_cond_size; j++)
                    sep[i][j] = sep2[j];
            }
            if (dep[i] >= (double)1.0)
            {
                n_ranks++;
            }
        }
    rank = new int[n_ranks];

    //under the empty set condition, the nodes with the T dependency greater than 0 are sorted and loaded into the rank array.
    j = 0;
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 0 && j < n_ranks)
        {
            rank[j] = i;
            for (k = j; k > 0; k--)
            {
                if (dep[rank[k]] > dep[rank[k - 1]])
                {
                    rank[k] = rank[k] + rank[k - 1];
                    rank[k - 1] = rank[k] - rank[k - 1];
                    rank[k] = rank[k] - rank[k - 1];
                }
            }
            j++;
        }
    }

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_ranks; i++)
    {
        pc[rank[i]] = 1;
        last_added = rank[i];
        //crop

        //the node that is added from the rank after cutting, because the dependency of the node behind the rank is smaller, it will be cropped.
        pc[last_added] = 0;
        if (min_dep(last_added, target, -1, pc, sep2) <= (double)(-1.0))
        {
            for (k = 0; k < max_max_cond_size; k++)
                sep[last_added][k] = sep2[k];
            pc[last_added] = -1;
            continue; //if the node just added from rank is directly cropped, the subsequent for loop will not be done because there is no new node.
            //in the case of joining, the current pc is already cropped.
        }
        else
        {
            pc[last_added] = 1;
        }

        for (j = 0; j < n_vars; j++)
        {
            if (pc[j] == 1 && j != last_added)
            {
                pc[j] = 0;

                dep[j] = min_dep(j, target, last_added, pc, sep2);

                pc[j] = 1;

                if (dep[j] <= (double)(-1.0)) //Find the pc node with less than 0 dependency and delete it immediately, which is different from the cutting phase of Get_PC and MMPC.
                {
                    for (k = 0; k < max_max_cond_size; k++)
                        sep[j][k] = sep2[k];
                    pc[j] = -1;
                }
            }
        }
    }

    if (isLearnDAG)
    {
        pc_iscomputed[target] = true;
        for (int var = 0; var < n_vars; ++var)
        {
            if (pc[var] == 1)
            {
                pc_cache[target].push_back(var);
            }
        }
        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep_cache[target][i][j] = sep[i][j];
            }
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == -1)
            pc[i] = 0;

    delete[] sep2;
    delete[] dep;
    delete[] rank;
}

/////////////////////////////////////

void semi_hiton_pc_set(int target, int *pc, int **sep)
{
    int i, j, k, last_added, n_ranks;
    int *sep2, *rank;
    double *dep;

    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
            sep[i][j] = -1;

    if (pc_iscomputed[target] == true)
    {
        for (i = 0; i < n_vars; i++)
            pc[i] = 0;

        for (vector<int>::iterator it = pc_cache[target].begin(); it < pc_cache[target].end(); ++it)
            pc[*it] = 1;

        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep[i][j] = sep_cache[target][i][j];
            }
        }

        return;
    }

    sep2 = new int[max_max_cond_size];

    dep = new double[n_vars];

    for (i = 0; i < n_vars; i++)
        pc[i] = 0;

    pc[target] = -1;

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    last_added = -1;
    n_ranks = 0;

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 0)
        {
            dep[i] = min_dep(i, target, -1, pc, sep2);

            if (dep[i] <= (double)-1.0)
            {
                pc[i] = -1;
                for (j = 0; j < max_max_cond_size; j++)
                    sep[i][j] = sep2[j];
            }
            if (dep[i] >= (double)1.0)
            {
                n_ranks++;
            }
        }
    rank = new int[n_ranks];

    //under the empty set condition, the nodes with the T dependency greater than 0 are sorted and loaded into the rank array.
    j = 0;
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 0 && j < n_ranks)
        {
            rank[j] = i;
            for (k = j; k > 0; k--)
            {
                if (dep[rank[k]] > dep[rank[k - 1]])
                {
                    rank[k] = rank[k] + rank[k - 1];
                    rank[k - 1] = rank[k] - rank[k - 1];
                    rank[k] = rank[k] - rank[k - 1];
                }
            }
            j++;
        }
    }

    for (i = 0; i < n_vars; i++)
        dep[i] = (double)0.0;

    for (i = 0; i < n_ranks; i++)
    {
        pc[rank[i]] = 1;
        last_added = rank[i];
        //cropping (in two cases)

        //if OPEN is not empty (this layer is not empty before the end of the loop)
        pc[last_added] = 0;

        dep[last_added] = min_dep(last_added, target, -1, pc, sep2);

        pc[last_added] = 1;

        if (dep[last_added] <= (double)(-1.0))
        {
            for (k = 0; k < max_max_cond_size; k++)
                sep[last_added][k] = sep2[k];
            pc[last_added] = -1;
        }
    }
    //if OPEN is an empty set, and the nodes of the rank array have all been inserted into TCP
    for (j = 0; j < n_vars; j++)
    {
        //nodes subscripted as last_added must not be cut off
        //Because the last check before the OPEN is empty is the last_added node.
        if (pc[j] == 1 && j != last_added)
        {
            pc[j] = 0;

            dep[j] = min_dep(j, target, -1, pc, sep2); //the third parameter here must be -1 instead of last_added

            pc[j] = 1;

            if (dep[j] <= (double)(-1.0))
            {
                for (k = 0; k < max_max_cond_size; k++)
                    sep[j][k] = sep2[k];
                pc[j] = -1;
            }
        }
    }

    if (isLearnDAG)
    {
        pc_iscomputed[target] = true;
        for (int var = 0; var < n_vars; ++var)
        {
            if (pc[var] == 1)
            {
                pc_cache[target].push_back(var);
            }
        }
        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep_cache[target][i][j] = sep[i][j];
            }
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == -1)
            pc[i] = 0;

    delete[] sep2;
    delete[] dep;
    delete[] rank;
}

/////////////////////////////////////

void pc_set(int target, int *pc, int **sep)

//AlgorithmPC(target).
//do symmetry check on PC
{
    int i, j;
    int *pc2;
    int **sep2;

    //printf("\n\n pc_set with target %d",target);

    pc2 = new int[n_vars];

    sep2 = new int *[n_vars];
    for (i = 0; i < n_vars; i++)
        sep2[i] = new int[max_max_cond_size];

    pc_superset2(target, pc, sep);

    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1)
        {
            pc_superset2(i, pc2, sep2);

            if (pc2[target] == 0)
            {
                pc[i] = 0;

                for (j = 0; j < max_max_cond_size; j++)
                    sep[i][j] = sep2[target][j];
            }
        }

    delete[] pc2;
    for (i = 0; i < n_vars; i++)
        delete[] sep2[i];
    delete[] sep2;
}

/////////////////////////////////////

void pc_superset(int target, int *pc, int **sep)

//AlgorithmPCD(target).
//unified cutting after PC growth
{
    int i, j, last_added, stop;
    int *sep2;
    double *dep, *cache_dep;

    //printf("\n\n pc_superset with target %d",target);

    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
            sep[i][j] = -1;

    if (pc_iscomputed[target] == true)
    {
        for (i = 0; i < n_vars; i++)
            pc[i] = 0;

        for (vector<int>::iterator it = pc_cache[target].begin(); it < pc_cache[target].end(); ++it)
            pc[*it] = 1;

        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep[i][j] = sep_cache[target][i][j];
            }
        }

        return;
    }

    sep2 = new int[max_max_cond_size];

    dep = new double[n_vars];

    cache_dep = new double[n_vars];
    for (i = 0; i < n_vars; i++)
        cache_dep[i] = (double)0.0;

    for (i = 0; i < n_vars; i++)
        pc[i] = 0;

    pc[target] = -1;

    last_added = -1;

    do
    {
        stop = 1;

        for (i = 0; i < n_vars; i++)
            dep[i] = (double)0.0;

        for (i = 0; i < n_vars; i++)
            if (pc[i] == 0)
            {
                dep[i] = min_dep(i, target, last_added, pc, sep2);

                if (dep[i] == (double)0.0)
                    dep[i] = cache_dep[i];
                else
                {
                    if (cache_dep[i] == (double)0.0 || dep[i] < cache_dep[i])
                    {
                        cache_dep[i] = dep[i];

                        if (dep[i] <= (double)(-1.0))
                            for (j = 0; j < max_max_cond_size; j++)
                                sep[i][j] = sep2[j];
                    }
                    else
                        dep[i] = cache_dep[i];
                }
            }

        for (i = 0; i < n_vars; i++)
            if (dep[i] <= (double)(-1.0))
                pc[i] = -1;
            else if (dep[i] >= (double)1.0)
                stop = 0;

        if (stop == 0)
        {
            last_added = k_greedy(dep);

            pc[last_added] = 1;

            //printf("\n Adding %d with dependence %.2f",last_added,dep[last_added]);
        }
        else
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
                if (pc[i] == 1 && i != last_added) //the last node added will not be cut.
                {
                    pc[i] = 0;

                    dep[i] = min_dep(i, target, last_added, pc, sep2);

                    pc[i] = 1;

                    if (dep[i] <= (double)(-1.0))
                        for (j = 0; j < max_max_cond_size; j++)
                            sep[i][j] = sep2[j];
                }

            for (i = 0; i < n_vars; i++)
                if (pc[i] == 1 && i != last_added && dep[i] <= (double)(-1.0))
                {
                    pc[i] = -1;

                    stop = 0;

                    //printf("\n Removing %d",i);
                }
        }
    } while (stop == 0);

    if (isLearnDAG)
    {
        pc_iscomputed[target] = true;
        for (int var = 0; var < n_vars; ++var)
        {
            if (pc[var] == 1)
            {
                pc_cache[target].push_back(var);
            }
        }
        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep_cache[target][i][j] = sep[i][j];
            }
        }
    }

    for (i = 0; i < n_vars; i++)
        if (pc[i] == -1)
            pc[i] = 0;

    delete[] sep2;
    delete[] dep;
    delete[] cache_dep;
}

/////////////////////////////////////

void pc_superset2(int target, int *pc, int **sep)

//AlgorithmPCD(target).
//PC grows immediately and crops
{
    int i, j, last_added, stop;
    int *sep2;
    double *dep, *cache_dep;

    //printf("\n\n pc_superset with target %d",target);

    if (pc_iscomputed[target] == true)
    {
        for (i = 0; i < n_vars; i++)
            pc[i] = 0;

        for (vector<int>::iterator it = pc_cache[target].begin(); it < pc_cache[target].end(); ++it)
            pc[*it] = 1;

        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep[i][j] = sep_cache[target][i][j];
            }
        }

        return;
    }

    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
            sep[i][j] = -1;

    sep2 = new int[max_max_cond_size];

    dep = new double[n_vars];

    cache_dep = new double[n_vars];
    for (i = 0; i < n_vars; i++)
        cache_dep[i] = (double)0.0;

    for (i = 0; i < n_vars; i++)
        pc[i] = 0;

    pc[target] = -1;

    last_added = -1;

    do
    {
        stop = 1;

        for (i = 0; i < n_vars; i++)
            dep[i] = (double)0.0;

        for (i = 0; i < n_vars; i++)
            if (pc[i] == 0)
            {
                dep[i] = min_dep(i, target, last_added, pc, sep2);

                if (dep[i] == (double)0.0)
                    dep[i] = cache_dep[i];
                else
                {
                    if (cache_dep[i] == (double)0.0 || dep[i] < cache_dep[i])
                    {
                        cache_dep[i] = dep[i];

                        if (dep[i] <= (double)(-1.0))
                            for (j = 0; j < max_max_cond_size; j++)
                                sep[i][j] = sep2[j];
                    }
                    else
                        dep[i] = cache_dep[i];
                }
            }

        for (i = 0; i < n_vars; i++)
            if (dep[i] <= (double)(-1.0))
                pc[i] = -1;
            else if (dep[i] >= (double)1.0)
                stop = 0;

        if (stop == 0)
        {
            last_added = k_greedy(dep);

            pc[last_added] = 1;

            //printf("\n Adding %d with dependence %.2f",last_added,dep[last_added]);
        }
        else
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
                if (pc[i] == 1 && i != last_added)
                {
                    pc[i] = 0;

                    dep[i] = min_dep(i, target, last_added, pc, sep2);

                    pc[i] = 1;

                    if (dep[i] <= (double)(-1.0))
                        for (j = 0; j < max_max_cond_size; j++)
                            sep[i][j] = sep2[j];
                }

            for (i = 0; i < n_vars; i++)
                if (pc[i] == 1 && i != last_added && dep[i] <= (double)(-1.0))
                {
                    pc[i] = -1;

                    stop = 0;

                    //printf("\n Removing %d",i);
                }
        }
    } while (stop == 0);

    pc_iscomputed[target] = true;
    for (int var = 0; var < n_vars; ++var)
    {
        if (pc[var] == 1)
        {
            pc_cache[target].push_back(var);
        }
    }
    for (i = 0; i < n_vars; ++i)
    {
        for (j = 0; j < max_max_cond_size; ++j)
        {
            sep_cache[target][i][j] = sep[i][j];
        }
    }
    for (i = 0; i < n_vars; i++)
        if (pc[i] == -1)
            pc[i] = 0;

    delete[] sep2;
    delete[] dep;
    delete[] cache_dep;
}

/////////////////////////////////////

void PCSuperSet(int target, int *pcs, int **sep)
{
    int i, j, k;
    int *cond;
    double dep;

    cond = new int[max_max_cond_size];
    dep = (double)0.0;
    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
    }
    for (i = 0; i < n_vars; i++)
        for (j = 0; j < max_max_cond_size; j++)
            sep[i][j] = -1;

    for (i = 0; i < n_vars; i++)
    {
        if (i != target)
        {
            pcs[i] = 1;
        }
    }
    pcs[target] = -1;

    //Phase I: Remove X if T ⊥ X
    for (i = 0; i < n_vars; i++)
    {
        if (pcs[i] == 1)
        {
            dep = compute_dep(i, target, cond);

            if (dep <= (double)(-1.0))
            {
                pcs[i] = -1;

                for (j = 0; j < max_max_cond_size; j++)
                {
                    sep[i][j] = cond[j];
                }
            }
        }
    }

    //Phase II:Remove X if T ⊥X|Y
    for (i = 0; i < n_vars; i++)
    {
        if (pcs[i] == 1)
        {
            for (j = 0; j < n_vars; j++)
            {
                if (pcs[j] == 1 && j != i)
                {
                    cond[0] = j;

                    dep = compute_dep(i, target, cond);

                    if (dep <= (double)(-1.0))
                    {
                        pcs[i] = -1;

                        for (k = 0; k < max_max_cond_size; k++)
                        {
                            sep[i][k] = cond[k];
                        }
                        j = n_vars;
                    }

                    cond[0] = -1;
                }
            }
        }
    }

    delete[] cond;
}

/////////////////////////////////////

void MBSuperSet(int target, int *mbs, int *pcs, int **sep)
{
    int i, j, k, n_conds, n_sps;
    int *cond, *sps;
    double dep;

    cond = new int[max_max_cond_size];
    sps = new int[n_vars];
    n_conds = 0;

    dep = (double)0.0;

    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
    }

    for (i = 0; i < n_vars; i++)
    {
        if (pcs[i] == 1)
        {
            n_sps = 0;
            for (j = 0; j < n_vars; j++)
            {
                sps[j] = -1;
            }

            for (j = 0; j < n_vars; j++)
            {
                if (pcs[j] == -1 && j != target)
                {
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = sep[j][k];
                        if (cond[k] != -1)
                            n_conds++;
                    }
                    cond[n_conds] = i;
                    dep = compute_dep(j, target, cond);
                    if (dep >= (double)1.0)
                    {
                        sps[j] = 1;
                        n_sps++;
                    }
                    for (k = 0; k < max_max_cond_size; k++)
                    {
                        cond[k] = -1;
                    }
                    n_conds = 0;
                }
            }

            for (j = 0; j < n_vars; j++)
            {
                if (sps[j] == 1)
                {
                    for (k = 0; k < n_vars; k++)
                    {
                        if (sps[k] == 1 && k != j)
                        {
                            cond[0] = i;
                            cond[1] = k;
                            dep = compute_dep(j, target, cond);
                            if (dep <= (double)(-1.0))
                            {
                                sps[j] = -1;
                                n_sps--;
                                k = n_vars;
                            }
                        }
                    }
                }
            }
            cond[0] = -1;
            cond[1] = -1;
            if (n_sps > 0)
            {
                for (j = 0; j < n_vars; j++)
                {
                    if (sps[j] == 1)
                    {
                        mbs[j] = 1;
                    }
                }
            }
        }
    }
    delete[] cond;
    delete[] sps;
}

/////////////////////////////////////

void MBtoPC(int target, int *D, int *pc, int *mb, int **sep)
{
    //Inter_IAMB
    int i, j, k, stop, n_conds, aux, n_sets, cond_size;
    int *cond, *code, *cond_index, *indepent_tag, *removals;
    double *dep;
    //*indepent_tag is used to mark whether the minimum condition set that makes the node
    //and T independent during the execution of the Inter_IAMB algorithm is stored in **sep.
    //If it is stored, then the larger condition set that makes the node and T independent will not be used.
    for (i = 0; i < n_vars; i++)
    {
        if (D[i] == 1) //node data other than D is not considered
            mb[i] = 0;
        else
            mb[i] = -1;
    }
    mb[target] = -1;

    n_conds = 0;
    n_sets = 0;
    cond = new int[max_max_cond_size + 1];
    for (i = 0; i < max_max_cond_size + 1; i++)
        cond[i] = -1;

    dep = new double[n_vars];
    indepent_tag = new int[n_vars];
    removals = new int[n_vars];
    for (i = 0; i < n_vars; i++)
    {
        indepent_tag[i] = 0;
        removals[i] = 0;
    }

    do
    {
        stop = 1;

        if (n_conds <= max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                    {
                        stop = 0;
                    }
                    else
                    {
                        if (indepent_tag[i] == 0)
                        {
                            for (j = 0; j < max_max_cond_size; j++)
                                sep[i][j] = cond[j];

                            indepent_tag[i] = 1;
                        }
                    }
                }
            }
        }

        if (stop == 0)
        {
            aux = k_greedy(dep);
            mb[aux] = 1;
            cond[n_conds] = aux;
            n_conds++;
            //the end of growth.

            //start to cut, if there is no node to join in the growth phase, there is no need to cut it.
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 1 && removals[i] < 10)
                {
                    for (j = 0; j < n_conds; j++)
                        if (cond[j] == i)
                        {
                            for (k = j; k < n_conds - 1; k++)
                                cond[k] = cond[k + 1];
                            cond[n_conds - 1] = -1;

                            j = n_conds; //end loop
                        }

                    dep[i] = compute_dep(i, target, cond);

                    //cond[n_conds - 1] = i;

                    if (dep[i] <= (double)(-1.0))
                    {
                        n_conds--;
                        mb[i] = 0;
                        removals[i]++; //To avoid endless loop.
                    }
                    else
                    {
                        cond[n_conds - 1] = i;
                    }
                }
            }
        }

    } while (stop == 0);
    //Inter_IAMB run finished

    for (i = 0; i < n_vars; i++)
    {
        pc[i] = mb[i];
        if (mb[i] == 1)
        {
            n_sets++;
        }
    }
    n_sets--;

    if (n_sets >= 0)
    {
        code = new int[n_sets];

        for (i = 0; i < n_vars; i++)
        {
            if (mb[i] == 1)
            {
                k = 0;
                for (j = 0; j < n_vars; j++)
                {
                    if (mb[j] == 1 && j != i)
                    {
                        code[k] = j;
                        k++;
                    }
                }
                for (j = 0; j < max_max_cond_size; j++)
                {
                    cond[j] = -1;
                }
                for (cond_size = 0; cond_size <= n_sets; cond_size++)
                {
                    cond_index = new int[cond_size];
                    for (k = 0; k < cond_size; k++)
                        cond_index[k] = k;

                    do
                    {
                        stop = 0;

                        for (k = 0; k < cond_size; k++)
                            cond[k] = code[cond_index[k]];

                        if (compute_dep(i, target, cond) <= (double)(-1.0))
                        {
                            pc[i] = 0;
                            if (indepent_tag[i] == 0)
                            {
                                for (k = 0; k < max_max_cond_size; k++)
                                    sep[i][k] = cond[k];
                            }

                            stop = 1;
                            cond_size = n_sets + 1;
                        }

                        if (stop == 0)
                            stop = next_cond_index(n_sets, cond_size, cond_index);
                    } while (stop == 0);

                    delete[] cond_index;
                }
            }
        }
        delete[] code;
    }
    delete[] cond;
    delete[] dep;
    delete[] indepent_tag;
}

/////////////////////////////////////

void TIE_MB_induc_alg_X(int target, vector<int> &_mb, const vector<int> &illegal_var)
{
    int i, j, k, stop, n_conds, aux;
    int *mb, *cond, *removals;
    double *dep;

    mb = new int[n_vars];
    removals = new int[n_vars];

    for (i = 0; i < n_vars; i++)
    {
        mb[i] = 0;
        removals[i] = 0;
    }
    for (vector<int>::const_iterator iter = illegal_var.begin(); iter < illegal_var.end(); iter++)
    {
        mb[*iter] = -1;
    }
    mb[target] = -1;

    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    dep = new double[n_vars];

    do
    {
        stop = 1;

        if (n_conds < max_max_cond_size)
        {
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 0)
                {
                    dep[i] = compute_dep(i, target, cond);

                    if (dep[i] >= (double)1.0)
                    {
                        stop = 0;
                    }
                }
            }
        }

        if (stop == 0)
        {
            aux = k_greedy(dep);
            mb[aux] = 1;
            cond[n_conds] = aux;
            n_conds++;
            //the end of growth.

            //start to cut, if there is no node to join in the growth phase, there is no need to make a cut.
            for (i = 0; i < n_vars; i++)
                dep[i] = (double)0.0;

            for (i = 0; i < n_vars; i++)
            {
                if (mb[i] == 1 && removals[i] < 10)
                {
                    for (j = 0; j < n_conds; j++)
                        if (cond[j] == i)
                        {
                            for (k = j; k < n_conds - 1; k++)
                                cond[k] = cond[k + 1];
                            cond[n_conds - 1] = -1;

                            j = n_conds; //end loop
                        }

                    dep[i] = compute_dep(i, target, cond);

                    //cond[n_conds - 1] = i;

                    if (dep[i] <= (double)(-1.0))
                    {
                        n_conds--;
                        mb[i] = 0;
                        removals[i]++; //To avoid endless loop.
                    }
                    else
                    {
                        cond[n_conds - 1] = i;
                    }
                }
            }
        }

    } while (stop == 0);

    for (int var = 0; var < n_vars; ++var)
    {
        if (mb[var] == -1)
        {
            mb[var] = 0;
        }
        if (mb[var] == 1)
        {
            _mb.push_back(var);
        }
    }

    delete[] mb;
    delete[] cond;
    delete[] dep;
}

/////////////////////////////////////

bool criterion_Z(int target, const vector<int> &mb_old, const vector<int> &mb_new)
{
    vector<int> aux; //store nodes that belong to mb_old but do not belong to mb_new
    int *cond;
    double dep;
    int i, n_conds;
    aux.clear();
    n_conds = 0;
    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
        cond[i] = -1;

    for (vector<int>::const_iterator iter = mb_new.begin(); iter < mb_new.end(); iter++)
    {
        if (n_conds < max_max_cond_size)
        {
            cond[n_conds] = *iter;
            n_conds++;
        }
    }

    for (vector<int>::const_iterator iter1 = mb_old.begin(); iter1 < mb_old.end(); iter1++)
    {
        bool tag = false;
        for (vector<int>::const_iterator iter2 = mb_new.begin(); iter2 < mb_new.end(); iter2++)
        {
            if (*iter1 == *iter2)
            {
                tag = true;
                break;
            }
        }
        if (!tag)
        {
            aux.push_back(*iter1);
        }
    }

    //if under the condition of mb_new, each node in T and aux is independent, return true, otherwise false
    for (vector<int>::iterator iter = aux.begin(); iter < aux.end(); iter++)
    {
        dep = compute_dep(*iter, target, cond);
        if (dep >= (double)1.0 || dep == (double)0.0)
        {
            delete cond;
            return false;
        }
    }
    delete cond;
    return true;
}

/////////////////////////////////////

int isSubset(vector<int> v1, vector<int> v2)
{ //returns 1 if v2 is a subset of v1, otherwise returns 0
    int i = 0, j = 0;
    int m = v1.size();
    int n = v2.size();
    if (m < n)
    {
        return 0;
    }
    std::sort(v1.begin(), v1.end());
    std::sort(v2.begin(), v2.end());
    while (i < n && j < m)
    {
        if (v1[j] < v2[i])
        {
            j++;
        }
        else if (v1[j] == v2[i])
        {
            j++;
            i++;
        }
        else if (v1[j] > v2[i])
        {
            return 0;
        }
    }
    if (i < n)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

/////////////////////////////////////

void set_plus(vector<int> v1, list<vector<int> > &v2, vector<int> v3)
{
    //the algorithm finds all the elements that are not in v1 from v3, adds them to v1, makes v1 length +1, and puts these newly generated v1+1 length sets into v2.
    for (vector<int>::iterator iter = v3.begin(); iter < v3.end(); iter++)
    {
        bool tag = false;
        for (vector<int>::iterator iter2 = v1.begin(); iter2 < v1.end(); iter2++)
        {
            if (*iter == *iter2)
            {
                tag = true; //this element is in v1
                break;
            }
        }
        if (!tag)
        {
            v1.push_back(*iter);
            v2.push_back(v1);
            vector<int>::iterator iter3 = v1.end() - 1;
            v1.erase(iter3);
        }
    }
}

/////////////////////////////////////

void recognize_pc(int target, int *CanADJ, int *pc, int **sep)
{
    int i, j, k, n_NonPC, cutSetSize, stop, n_pc;
    int *NonPC, *code, *cond_index, *cond;
    double aux;
    if (pc_iscomputed[target] == true)
    {
        for (i = 0; i < n_vars; i++)
            pc[i] = 0;

        for (vector<int>::iterator it = pc_cache[target].begin(); it < pc_cache[target].end(); ++it)
            pc[*it] = 1;

        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep[i][j] = sep_cache[target][i][j];
            }
        }

        return;
    }
    for (i = 0; i < n_vars; i++)
    {
        CanADJ[i] = 1;
    }
    CanADJ[target] = -1;

    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
    }

    n_pc = 0;
    for (i = 0; i < n_vars; i++)
    {
        if (CanADJ[i] == 1)
        {
            n_pc++;
        }
    }
    cutSetSize = 0;
    NonPC = new int[n_vars];
    do
    {
        for (i = 0; i < n_vars; i++)
        {
            NonPC[i] = 0;
        }
        n_NonPC = 0;

        code = new int[n_pc - 1];
        for (i = 0; i < n_vars; i++)
        {
            if (CanADJ[i] == 1)
            {
                k = 0;
                for (j = 0; j < n_vars; j++)
                {
                    if (CanADJ[j] == 1 && j != i)
                    {
                        code[k] = j;
                        k++;
                    }
                }

                cond_index = new int[cutSetSize];
                for (j = 0; j < cutSetSize; j++)
                    cond_index[j] = j;

                do
                {
                    stop = 0;

                    for (j = 0; j < cutSetSize; j++)
                        cond[j] = code[cond_index[j]];

                    aux = compute_dep(i, target, cond);

                    if (aux <= (double)(-1.0))
                    {
                        NonPC[i] = 1;
                        n_NonPC++;
                        for (j = 0; j < max_max_cond_size; j++)
                        {
                            sep[i][j] = cond[j];
                        }
                        stop = 1;
                    }

                    if (stop == 0)
                        stop = next_cond_index(n_pc - 1, cutSetSize, cond_index);
                } while (stop == 0);

                delete[] cond_index;
            }
        }
        delete[] code;
        if (n_NonPC > 0)
        {
            for (i = 0; i < n_vars; i++)
            {
                if (NonPC[i] == 1)
                {
                    CanADJ[i] = 0;
                    n_pc--;
                }
            }
        }
        if (cutSetSize == k_conditon)
        {
            break;
        }
        cutSetSize++;

    } while (n_pc > cutSetSize);

    for (i = 0; i < n_vars; i++)
    {
        pc[i] = CanADJ[i];
    }

    if (isLearnDAG)
    {
        pc_iscomputed[target] = true;
        for (int var = 0; var < n_vars; ++var)
        {
            if (pc[var] == 1)
            {
                pc_cache[target].push_back(var);
            }
        }
        for (i = 0; i < n_vars; ++i)
        {
            for (j = 0; j < max_max_cond_size; ++j)
            {
                sep_cache[target][i][j] = sep[i][j];
            }
        }
    }

    delete[] NonPC;
    delete[] cond;
}

/////////////////////////////////////

double min_dep(int var, int target, int compulsory, int *pc, int *sep)
//It computes the minimum of the depence measure between var and target conditioned on
//subsets of pc[x1] st compulsory is always included (-1=no compulsory). Note that only
//those subsets of pc[x1] that have a size no larger than max_cond_size are considered.
//It returns the minimum dependence [-inf,-1] for H0 (the smaller the more independent),
//[1,+inf] for H1 (the higher the more dependent), or 0 for not enough data (see N_CASES_PER_DF),
//and sep[-1i].
{
    int i, j, n_pc, stop, cond_size, max_cond_size;
    double dep, aux;
    int *cond, *code, *cond_index;

    cond = new int[max_max_cond_size];
    for (i = 0; i < max_max_cond_size; i++)
    {
        cond[i] = -1;
        sep[i] = -1;
    }

    n_pc = 0;
    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1 && i != compulsory)
            n_pc++;

    max_cond_size = max_max_cond_size;
    if (compulsory != -1)
        max_cond_size--;
    if (max_cond_size > n_pc)
        max_cond_size = n_pc;

    if (k_conditon != -1)
    {
        if (compulsory != -1)
        {
            if (max_cond_size >= k_conditon)
            {
                max_cond_size = k_conditon - 1;
            }
        }
        else
        {
            if (max_cond_size > k_conditon)
            {
                max_cond_size = k_conditon;
            }
        }
    }

    code = new int[n_pc];
    j = 0;
    for (i = 0; i < n_vars; i++)
        if (pc[i] == 1 && i != compulsory)
        {
            code[j] = i;

            j++;
        }

    dep = (double)0.0;
    for (cond_size = 0; cond_size <= max_cond_size; cond_size++)
    {
        cond_index = new int[cond_size];
        for (i = 0; i < cond_size; i++)
            cond_index[i] = i;

        do
        {
            stop = 0;

            for (i = 0; i < cond_size; i++)
                cond[i] = code[cond_index[i]];
            if (compulsory != -1)
                cond[cond_size] = compulsory;

            aux = compute_dep(var, target, cond);

            if (aux != (double)0.0 && (dep == (double)0.0 || aux < dep))
            {
                dep = aux;

                if (dep <= (double)(-1.0))
                {
                    for (i = 0; i < max_max_cond_size; i++)
                        sep[i] = cond[i];

                    stop = 1;
                    cond_size = max_cond_size + 1; //end loop early
                }
            }

            if (stop == 0)
                stop = next_cond_index(n_pc, cond_size, cond_index);
        } while (stop == 0);

        delete[] cond_index;
    }

    delete[] code;
    delete[] cond;

    return dep;
}

/////////////////////////////////////

int next_cond_index(int n_pc, int cond_size, int *cond_index)
//Non-recursive subset function
{
    int i, j, stop;

    stop = 1;
    for (i = cond_size - 1; i >= 0; i--)
    {
        if (cond_index[i] < n_pc + i - cond_size)
        {
            cond_index[i]++;

            if (i < cond_size - 1)
                for (j = i + 1; j < cond_size; j++)
                    cond_index[j] = cond_index[j - 1] + 1;

            stop = 0;
            i = -1;
        }
    }

    return stop;
}

/////////////////////////////////////

double compute_dep(int var, int target, int *cond)
//Fisher-z test, the returned value <=-1 means that var and target are independent under cond,
//and the return value >=1 means that var and target are dependent on cond.
{
    double pvalue, stat, dep;
    int n_conds;
    int *PcorMb;

    n_conds = 0;
    for (int var = 0; var < max_max_cond_size; ++var)
    {
        if (cond[var] != -1)
        {
            n_conds++;
        }
        else
        {
            break;
        }
    }

    average_n_Fisher_z++;

    PcorMb = new int[n_vars];

    for (int var = 0; var < n_vars; ++var)
    {
        PcorMb[var] = 0;
    }
    for (int var = 0; var < max_max_cond_size; ++var)
    {
        if (cond[var] != -1)
        {
            PcorMb[cond[var]] = 1;
        }
    }

    stat = fabs(statistic(var, target, PcorMb));

    pvalue = (double)1 - normalp(stat, (double)0, (double)1 / (double)(n_cases - 3 - n_conds));

    if (pvalue <= alpha / (double)2)
    {
        dep = (1 - pvalue) * (double)1000 + (double)1;
    }
    else
    {
        dep = -(pvalue * (double)1000) - (double)1;
    }
    return dep;
}

/////////////////////////////////////

double statistic(int var, int target, int *cond)
{
    int i, j, k, l, n_conds, x, y;
    double stat, **sigma2;

    n_conds = 0;
    for (i = 0; i < n_vars; i++)
        n_conds += (int)cond[i];

    sigma2 = new double *[n_conds + 2];
    for (i = 0; i < n_conds + 2; i++)
        sigma2[i] = new double[n_conds + 2];

    k = 0;
    for (i = 0; i < n_vars; i++)
        if (i == var || i == target || cond[i] == 1)
        {
            if (i == var)
                x = k;

            l = 0;
            for (j = 0; j <= i; j++)
                if (j == var || j == target || cond[j] == 1)
                {
                    if (j == target)
                        y = l;

                    sigma2[k][l] = sigma[i][j];
                    sigma2[l][k] = sigma[j][i];
                    l++;
                }
            k++;
        }

    stat = inverse(sigma2, n_conds + 2, x, y);

    if (stat == (double)1)
        stat = (double)INT_MAX;
    else
    {
        stat = (double)0.5 * log(((double)1 + stat) / ((double)1 - stat));
    }

    for (i = 0; i < n_conds + 2; i++)
        delete[] sigma2[i];
    delete[] sigma2;

    return stat;
}

/////////////////////////////////////

double inverse(double **a, int n, int x, int y)
//I have adapted the code for zero-offset by substracting 1 from the original index every time an array is accessed.
{
    int i, j, k;
    double *p, sum, **b, **c, sigma_xy, sigma_xx, sigma_yy;

    p = new double[n];

    if (choldc(a, n, p) == 0)
    {
        printf("\n\n No Cholesky decomposition (%d). \n\n", n);
        exit(0);
    }

    for (i = 1; i <= n; i++)
    {
        if (p[i - 1] == 0.0)
        {
            a[i - 1][i - 1] = 0.0;
        }
        else
        {
            a[i - 1][i - 1] = (double)1 / p[i - 1];
        }

        for (j = i + 1; j <= n; j++)
        {
            sum = (double)0;
            for (k = i; k < j; k++)
                sum -= a[j - 1][k - 1] * a[k - 1][i - 1];

            if (p[j - 1] == 0.0)
            {
                a[j - 1][i - 1] = 0.0;
            }
            else
            {
                a[j - 1][i - 1] = sum / p[j - 1];
            }
        }
    }

    if (-1 < x && x < n_vars && -1 < y && y < n_vars)
    {
        sigma_xy = (double)0;
        sigma_xx = (double)0;
        sigma_yy = (double)0;
        for (i = max(x, y); i < n; i++)
            sigma_xy += a[i][x] * a[i][y];
        for (i = x; i < n; i++)
            sigma_xx += a[i][x] * a[i][x];
        for (i = y; i < n; i++)
            sigma_yy += a[i][y] * a[i][y];

        delete[] p;

        if (sigma_xy == (double)0)
            return (double)0;
        else
            return -sigma_xy / sqrt(sigma_xx * sigma_yy);
    }
    else
    {
        for (i = 0; i < n; i++)
            for (j = i + 1; j < n; j++)
                a[i][j] = (double)0;

        b = new double *[n];
        for (i = 0; i < n; i++)
            b[i] = new double[n];

        c = new double *[n];
        for (i = 0; i < n; i++)
            c[i] = new double[n];

        transpose(a, n, n, b);
        matmat(b, n, n, a, n, c);

        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                a[i][j] = c[i][j];

        delete[] p;
        for (i = 0; i < n; i++)
            delete[] b[i];
        delete[] b;
        for (i = 0; i < n; i++)
            delete[] c[i];
        delete[] c;

        return (double)1;
    }
}

/////////////////////////////////////

bool choldc(double **a, int n, double p[])
//Cholesky decomposition.
//Adapted from Numerical Recipes.
//Note that the algorithm works for one-offset arrays, i.e. a and p must be [1..n][1..n] and [1..n]. See pp. 18-19 in the 1992's book.
//I have adapted the code for zero-offset by substracting 1 from the original index every time an array is accessed.
{
    int i, j, k;
    double sum;

    for (i = 1; i <= n; i++)
    {
        for (j = i; j <= n; j++)
        {
            for (sum = a[i - 1][j - 1], k = i - 1; k >= 1; k--)
                sum -= a[i - 1][k - 1] * a[j - 1][k - 1];

            if (i == j)
            {
                if (sum <= (double)0)
                    sum = 0.0; //return 0;

                p[i - 1] = sqrt(sum);
            }
            else
                a[j - 1][i - 1] = sum / p[i - 1];
        }
    }

    return 1;
}

/////////////////////////////////////

int k_greedy(double *dep)
//k-greedy (maximization) over the nodes with dep[] >= 1.0.
//It returns the index of the maximum.
{
    int i, j, k, n_cands, n_cands_left, max;
    int *cand;

    n_cands = 0;
    for (i = 0; i < n_vars; i++)
        if (dep[i] >= (double)1.0)
            n_cands++;

    cand = new int[n_cands];

    j = 0;
    for (i = 0; i < n_vars; i++)
        if (dep[i] >= (double)1.0)
        {
            cand[j] = i;

            j++;
        }

    n_cands_left = n_cands;

    n_cands = (int)((double)n_cands * k_tradeoff);
    if (n_cands < 1)
        n_cands = 1;

    for (i = 0; i < n_cands; i++)
    {
        j = rand() % n_cands_left;

        if (i == 0 || dep[cand[j]] >= dep[max])
        {
            if (i != 0 && dep[cand[j]] == dep[max])
            {
                if (max > cand[j])
                {
                    max = cand[j];
                }
            }
            else
            {
                max = cand[j];
            }
        }

        for (k = j; k < n_cands_left - 1; k++)
            cand[k] = cand[k + 1];

        n_cands_left--;
    }

    delete[] cand;

    return max;
}

/////////////////////////////////////

void report_mb(int target, int *mb)
{
    std::fstream file;
    int i, j, in_mb, tp, fp, fn;
    double Precision, Recall, Distance, F1;

    average_perform_time = average_perform_time + ((double)(clock() - clock_init) / CLOCKS_PER_SEC);

    if (1)
    {
        tp = 0;
        fp = 0;
        fn = 0;
        //tp+fp=the algorithm runs the obtained MB
        //tp+fn=MB in real network
        for (i = 0; i < n_vars; i++)
        {
            if (i != target)
            {
                in_mb = 0;

                if (net[i][target] == 1 || net[target][i] == 1)
                    in_mb = 1;
                else
                {
                    for (j = 0; j < n_vars; j++)
                        if (j != target && j != i)
                        {
                            if (net[target][j] == 1 && net[i][j] == 1) //spouse
                            {
                                in_mb = 1;
                            }
                        }
                }

                if (mb[i] == 1 && in_mb == 1)
                    tp++; //found the correct number of MB nodes
                else
                {
                    if (mb[i] == 1 && in_mb == 0)
                        fp++; //found redundant MB nodes
                    else if (mb[i] == 0 && in_mb == 1)
                        fn++; //number of undiscovered MB nodes
                }
            }
        }

        //calculate precision (value range [0,1])
        if (tp == 0 && fp == 0)
        {
            if (tp == 0 && fp == 0 && fn == 0)
            {
                Precision = (double)1.0;
            }
            else
            {
                Precision = (double)0.0;
            }
        }
        else
        {
            Precision = (double)tp / (double)(tp + fp);
        }

        //calculate recall (value range [0,1])
        if (tp == 0 && fn == 0)
        {
            if (tp == 0 && fn == 0 && fp == 0)
            {
                Recall = (double)1.0;
            }
            else
            {
                Recall = (double)0.0;
            }
        }
        else
        {
            Recall = (double)tp / (double)(tp + fn);
        }

        //calculate distance (value range [0,√2])
        Distance = sqrt(pow((double)1.0 - Precision, (double)2.0) + pow((double)1.0 - Recall, (double)2.0));

        //calculate F1
        if (Precision == 0 && Recall == 0)
        {
            F1 = (double)0.0;
        }
        else
        {
            F1 = (double)2.0 * Precision * Recall / (Precision + Recall);
        }
    }

    average_Precision = average_Precision + Precision;
    average_Recall = average_Recall + Recall;
    average_F1 = average_F1 + F1;
    average_Distance = average_Distance + Distance;

    //write to text
    file.open(mb_write_in_file_path, std::ios::out | std::ios::app); //read from memory into disk and open file in append mode
    if (!file)
    {
        std::cout << "error" << std::endl;
        return;
    }
    file << target << "  ";
    for (i = 0; i < n_vars; i++)
    {
        if (mb[i] == 1)
        {
            file << i << " ";
        }
    }
    file << std::endl;
    file.close();
}

/////////////////////////////////////

void report_pc(int target, int *pc)
{
    std::fstream file;
    int i, in_pc, tp, fp, fn;
    double Precision, Recall, Distance, F1;

    average_perform_time = average_perform_time + ((double)(clock() - clock_init) / CLOCKS_PER_SEC);

    if (1)
    {
        tp = 0;
        fp = 0;
        fn = 0;
        //tp+fp=the algorithm runs the obtained PC
        //tp+fn=PC in real network
        for (i = 0; i < n_vars; i++)
        {
            if (i != target)
            {
                in_pc = 0;

                if (net[i][target] == 1 || net[target][i] == 1)
                {
                    in_pc = 1;
                }
                if (pc[i] == 1 && in_pc == 1)
                    tp++; //Found the correct number of PC nodes
                else
                {
                    if (pc[i] == 1 && in_pc == 0)
                        fp++; //found redundant PC nodes
                    else if (pc[i] == 0 && in_pc == 1)
                        fn++; //number of undiscovered PC nodes
                }
            }
        }

        //calculate precision (value range [0,1])
        if (tp == 0 && fp == 0)
        {
            if (tp == 0 && fp == 0 && fn == 0)
            {
                Precision = (double)1.0;
            }
            else
            {
                Precision = (double)0.0;
            }
        }
        else
        {
            Precision = (double)tp / (double)(tp + fp);
        }

        //calculate recall (value range [0,1])
        if (tp == 0 && fn == 0)
        {
            if (tp == 0 && fn == 0 && fp == 0)
            {
                Recall = (double)1.0;
            }
            else
            {
                Recall = (double)0.0;
            }
        }
        else
        {
            Recall = (double)tp / (double)(tp + fn);
        }

        //calculate distance (value range [0,√2])
        Distance = sqrt(pow((double)1.0 - Precision, (double)2.0) + pow((double)1.0 - Recall, (double)2.0));

        //calculate F1
        if (Precision == 0 && Recall == 0)
        {
            F1 = (double)0.0;
        }
        else
        {
            F1 = (double)2.0 * Precision * Recall / (Precision + Recall);
        }
    }

    average_Precision = average_Precision + Precision;
    average_Recall = average_Recall + Recall;
    average_F1 = average_F1 + F1;
    average_Distance = average_Distance + Distance;

    //write to text
    file.open(pc_write_in_file_path, std::ios::out | std::ios::app); //read from memory into disk and open file in append mode
    if (!file)
    {
        std::cout << "error" << std::endl;
        return;
    }
    file << target << "  ";
    for (i = 0; i < n_vars; i++)
    {
        if (pc[i] == 1)
        {
            file << i << " ";
        }
    }
    file << std::endl;
    file.close();
}

/////////////////////////////////////

void report_DAG(SquareMat<bool> &adjMat)
{
    average_perform_time = (double)(clock() - clock_init) / CLOCKS_PER_SEC;

    int **dag, **C;
    int count, tag;
    vector<int> x;
    vector<int> y;
    vector<int> y_index;
    std::fstream file;
    count = 0;
    undirected = 0;
    reverse = 0;
    miss = 0;
    extra = 0;
    x.clear();
    y.clear();
    y_index.clear();
    dag = new int *[n_vars];
    for (int i = 0; i < n_vars; i++)
        dag[i] = new int[n_vars];

    C = new int *[n_vars];
    for (int i = 0; i < n_vars; i++)
        C[i] = new int[n_vars];

    for (int var1 = 0; var1 < n_vars; ++var1)
    {
        for (int var2 = 0; var2 < n_vars; ++var2)
        {
            if (adjMat(var1, var2) == true)
            {
                dag[var1][var2] = 1;
            }
            else
            {
                dag[var1][var2] = 0;
            }
        }
    }

    for (int var1 = 0; var1 < n_vars; ++var1)
    {
        for (int var2 = 0; var2 < n_vars; ++var2)
        {
            C[var1][var2] = net[var1][var2] - dag[var1][var2];
        }
    }

    //SHD;
    for (int var2 = 0; var2 < n_vars; ++var2)
    {
        for (int var1 = 0; var1 < n_vars; ++var1)
        {
            if (C[var1][var2] != 0)
            {
                count++;
                x.push_back(var1);
                y.push_back(var2);
            }
        }
    }
    SHD = (double)count;
    for (int i = 0; i < count; ++i)
    {
        y_index.clear();
        for (int j = 0; j < count; ++j)
        {
            if (y[j] == x[i])
            {
                y_index.push_back(j);
            }
        }
        if (!y_index.empty())
        {
            for (int k = 0; k < y_index.size(); ++k)
            {
                if (x[y_index[k]] == y[i])
                {
                    SHD -= 0.5;
                }
            }
        }
    }

    //undirected,reverse,miss,extra;
    for (int i = 0; i < x.size(); ++i)
    {
        if (x[i] == -1)
        {
            continue;
        }
        tag = 0;
        y_index.clear();
        for (int j = 0; j < y.size(); ++j)
        {
            if (y[j] == x[i])
            {
                y_index.push_back(j);
            }
        }
        if (!y_index.empty())
        {
            for (int k = 0; k < y_index.size(); ++k)
            {
                if (x[y_index[k]] == y[i])
                {
                    tag = 1;
                    if (net[x[i]][y[i]] == net[x[y_index[k]]][y[y_index[k]]])
                    {
                        extra += 1;
                    }
                    else
                    {
                        reverse += 1;
                    }
                    x[y_index[k]] = -1;
                    y[y_index[k]] = -1;
                    break;
                }
            }
        }
        if (tag == 0)
        {
            if (net[y[i]][x[i]] == 0)
            {
                if (net[x[i]][y[i]] == 1)
                {
                    miss += 1;
                }
                else
                {
                    extra += 1;
                }
            }
            else
            {
                undirected += 1;
            }
        }
    }

    file.open(DAG_write_in_file_path, std::ios::out | std::ios::app); //read from memory into disk and open file in append mode
    if (!file)
    {
        std::cout << "error" << std::endl;
        return;
    }
    for (int var1 = 0; var1 < n_vars; ++var1)
    {
        for (int var2 = 0; var2 < n_vars; ++var2)
        {
            if (var2 != 0)
            {
                file << " ";
            }
            file << adjMat(var1, var2);
        }
        file << std::endl;
    }
    file.close();
}

/////////////////////////////////////

void Constrain_DAG(const vector<list<int> > &neighs, const vector<list<Family> > &families, SquareMat<bool> &adjMat)
{

    adjMat.setAll(false);

    SquareMat<bool> pathMat(n_vars);
    pathMat.setAll(false);
    for (int i = 0; i < n_vars; ++i)
        pathMat(i, i) = true;

    // build skeleton using OR rule
    for (int i = 0; i < n_vars; ++i)
    {
        for (list<int>::const_iterator nit = neighs[i].begin(); nit != neighs[i].end(); ++nit)
        {
            adjMat(i, *nit) = true;
            adjMat(*nit, i) = true;
        }
    }

    queue<Arc> directed;

    // direct arcs in v-structures
    for (int i = 0; i < n_vars; ++i)
    {
        for (list<Family>::const_iterator fit = families[i].begin(); fit != families[i].end(); ++fit)
        {
            int j = fit->spouse;
            for (list<int>::const_iterator cit = fit->children.begin(); cit != fit->children.end(); ++cit)
            {
                int k = *cit;
                // direct, if forms an undirected v-structure
                if (!adjMat(i, j) && !adjMat(j, i) &&
                    adjMat(i, k) && adjMat(k, i) &&
                    adjMat(j, k) && adjMat(k, j))
                {
                    directArc(i, k, adjMat, pathMat, directed);
                    directArc(j, k, adjMat, pathMat, directed);
                    for (int l = 0; l < n_vars; ++l)
                    {
                        // i -> k <- j,  i -- l -- j,  l -- k
                        if (adjMat(i, l) && adjMat(l, i) && adjMat(j, l) && adjMat(l, j) && adjMat(k, l) && adjMat(l, k))
                            directArc(l, k, adjMat, pathMat, directed);
                    }
                }
            }
        }
    }

    // direct rest of the arcs
    while (true)
    {
        // if no rules left, direct a random undirected arc
        if (directed.empty())
            for (int i = 0; i < n_vars; ++i)
                for (int j = 0; j < n_vars; ++j)
                    if (adjMat(i, j) && adjMat(j, i))
                    {
                        directArc(i, j, adjMat, pathMat, directed);
                        goto breakLoops;
                    }
    breakLoops:

        // no more arcs to direct?
        if (directed.empty())
            break;

        // direct arcs implied by previously directed
        while (!directed.empty())
        {
            Arc arc = directed.front();
            int i = arc.head;
            int j = arc.tail;
            directed.pop();

            for (int k = 0; k < n_vars; ++k)
            {
                if (k == i || k == j)
                    continue;
                // i -> j -- k
                if (adjMat(j, k) && adjMat(k, j) && !adjMat(i, k) && !adjMat(k, i))
                    directArc(j, k, adjMat, pathMat, directed);
                // i -> j -> k,  i -- k
                if (adjMat(j, k) && !adjMat(k, j) && adjMat(i, k) && adjMat(k, i))
                    directArc(i, k, adjMat, pathMat, directed);
                // k -> i -> j -> k,  k -- j
                if (adjMat(k, i) && !adjMat(i, k) && adjMat(k, j) && adjMat(j, k))
                    directArc(k, j, adjMat, pathMat, directed);
            }
        }
    }
}

/////////////////////////////////////

void Score_DAG(const vector<list<int> > &neighs, const Data &data, SquareMat<bool> &adjMat, const ScoreFun *scoreFun)
{
    SquareMat<bool> allowedMat(n_vars);
    buildSkeletonDAG(neighs, allowedMat);

    // build ADTree
    DataColumns dataColumns(data);
    //ADTree adTree(dataColumns, globalADTreeMinCount, globalADTreeMaxDepth, globalMaxParents + 1);
    ADTree adTree(dataColumns, 100, 2);

    // greedy search
    adjMat.setAll(false);
    //greedyBestDAG(data, allowedMat, scoreFun, maxHistoryLength, maxBadSteps, adjMat);

    greedyBestDAG(adTree, allowedMat, scoreFun, 100, 15, adjMat);
}

/////////////////////////////////////

void directArc(int i, int j, SquareMat<bool> &adjMat, SquareMat<bool> &pathMat, queue<Arc> &directed)
{
    //printf("direcArc: %d -> %d\n", i, j);
    assert(adjMat(i, j));
    int n = adjMat.getNumNodes();
    adjMat(j, i) = false;
    directed.push(Arc(i, j));
    pathMat(i, j) = true;
    for (int k = 0; k < n; ++k)
        if (pathMat(k, i))
            for (int l = 0; l < n; ++l)
                if (pathMat(j, l))
                {
                    assert(!pathMat(l, k));
                    pathMat(k, l) = true;
                    if (adjMat(l, k))
                    {
                        assert(adjMat(k, l));
                        adjMat(l, k) = false;
                        directed.push(Arc(k, l));
                    }
                }
}

/////////////////////////////////////

void buildSkeletonDAG(const vector<list<int> > &neighs, SquareMat<bool> &adjMat)
{
    int nVars = neighs.size();
    adjMat.setAll(false);
    // build  allowed skeleton using OR rule
    for (int i = 0; i < nVars; ++i)
    {
        for (list<int>::const_iterator nit = neighs[i].begin(); nit != neighs[i].end(); ++nit)
        {
            adjMat(i, *nit) = true;
            adjMat(*nit, i) = true;
        }
    }
}
