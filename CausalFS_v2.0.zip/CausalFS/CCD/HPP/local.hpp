#include <list>


#ifndef LOCAL_HPP
#define LOCAL_HPP

using std::list;

struct Family {
    int spouse;
    list<int> children;
    Family(int s, const list<int>& ch) { spouse = s; children = ch; }
};


#endif // LOCAL_H
