#!/bin/bash
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_GSMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_GSMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_GSMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_GSMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_IAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_IAMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_IAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_IAMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_KIAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_KIAMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_KIAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_KIAMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_Inter_IAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_Inter_IAMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_Inter_IAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_Inter_IAMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_Fast_IAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_Fast_IAMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_Fast_IAMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_Fast_IAMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_LRH_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_LRH_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_LRH_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_LRH_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_MMMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_MMMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_MMMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_MMMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_PCMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_PCMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_PCMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_PCMB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_HITON_MB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_HITON_MB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_HITON_MB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_HITON_MB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_Semi_HITON_MB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_Semi_HITON_MB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_Semi_HITON_MB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_Semi_HITON_MB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_MBOR_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.01_MBOR_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_MBOR_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/child_0.05_MBOR_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_IPC_MB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_IPC_MB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_IPC_MB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_IPC_MB_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_STMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_STMB_5000.out
sleep 3s
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_STMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_STMB_5000.out
sleep 3s







./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_GSMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_GSMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_GSMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_GSMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_IAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_IAMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_IAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_IAMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_KIAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_KIAMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_KIAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_KIAMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Inter_IAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Inter_IAMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Inter_IAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Inter_IAMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Fast_IAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Fast_IAMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Fast_IAMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Fast_IAMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_LRH_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_LRH_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_LRH_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_LRH_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MMMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MMMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MMMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MMMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_PCMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_PCMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_PCMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_PCMB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_HITON_MB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_HITON_MB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_HITON_MB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_HITON_MB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Semi_HITON_MB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Semi_HITON_MB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Semi_HITON_MB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Semi_HITON_MB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MBOR_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MBOR_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MBOR_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBOR all "" ""
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MBOR_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_IPC_MB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_IPC_MB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_IPC_MB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_IPC_MB_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_STMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_STMB_5000.out
sleep 3s
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_STMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_STMB_5000.out








./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_GSMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_GSMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_GSMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_GSMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_IAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_IAMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_IAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_IAMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_KIAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_KIAMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_KIAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_KIAMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Inter_IAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Inter_IAMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Inter_IAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Inter_IAMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Fast_IAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Fast_IAMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Fast_IAMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Fast_IAMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_LRH_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_LRH_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_LRH_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_LRH_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MMMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MMMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MMMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MMMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_PCMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_PCMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_PCMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_PCMB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_HITON_MB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_HITON_MB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_HITON_MB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_HITON_MB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Semi_HITON_MB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Semi_HITON_MB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Semi_HITON_MB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Semi_HITON_MB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MBOR_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MBOR_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MBOR_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MBOR_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_IPC_MB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_IPC_MB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_IPC_MB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_IPC_MB_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_STMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_STMB_5000.out
sleep 3s
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_STMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_STMB_5000.out
sleep 3s







./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_GSMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_GSMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_GSMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 GSMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_GSMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_IAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_IAMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_IAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_IAMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_KIAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_KIAMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_KIAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 KIAMB all 0.5 ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_KIAMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Inter_IAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Inter_IAMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Inter_IAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 Inter_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Inter_IAMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Fast_IAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Fast_IAMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Fast_IAMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 Fast_IAMB all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Fast_IAMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_LRH_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.01_LRH_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_LRH_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 LRH all "" ""
mv ./indicator1/indicator.out ./indicator1/gene_0.05_LRH_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MMMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MMMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MMMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MMMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MMMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_PCMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_PCMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_PCMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 PCMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_PCMB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_HITON_MB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_HITON_MB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_HITON_MB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_HITON_MB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Semi_HITON_MB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Semi_HITON_MB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Semi_HITON_MB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Semi_HITON_MB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MBOR_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MBOR_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MBOR_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MBOR all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MBOR_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_IPC_MB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_IPC_MB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_IPC_MB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 IPC_MB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_IPC_MB_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_STMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_STMB_5000.out
sleep 3s
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_STMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 STMB all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_STMB_5000.out
sleep 3s
