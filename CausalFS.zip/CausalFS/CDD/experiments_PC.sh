#!/bin/bash
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_PC_simple_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_PC_simple_5000.out
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_PC_simple_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_PC_simple_5000.out


./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_MMPC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_MMPC_5000.out
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_MMPC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_MMPC_5000.out


./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_HITON_PC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_HITON_PC_5000.out
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_HITON_PC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_HITON_PC_5000.out


./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_Semi_HITON_PC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_Semi_HITON_PC_5000.out
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_Semi_HITON_PC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_Semi_HITON_PC_5000.out


./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_GetPC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_GetPC_5000.out
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_GetPC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_GetPC_5000.out


./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_MBtoPC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.01_MBtoPC_5000.out
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_MBtoPC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/child_0.05_MBtoPC_5000.out









./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_PC_simple_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_PC_simple_5000.out
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_PC_simple_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_PC_simple_5000.out


./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MMPC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MMPC_5000.out
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MMPC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MMPC_5000.out


./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_HITON_PC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_HITON_PC_5000.out
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_HITON_PC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_HITON_PC_5000.out


./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Semi_HITON_PC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_Semi_HITON_PC_5000.out
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Semi_HITON_PC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_Semi_HITON_PC_5000.out


./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_GetPC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_GetPC_5000.out
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_GetPC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_GetPC_5000.out


./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MBtoPC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.01_MBtoPC_5000.out
./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MBtoPC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/alarm_0.05_MBtoPC_5000.out








./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_PC_simple_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_PC_simple_5000.out
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_PC_simple_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_PC_simple_5000.out


./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MMPC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MMPC_5000.out
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MMPC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MMPC_5000.out


./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_HITON_PC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_HITON_PC_5000.out
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_HITON_PC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_HITON_PC_5000.out


./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Semi_HITON_PC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_Semi_HITON_PC_5000.out
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Semi_HITON_PC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_Semi_HITON_PC_5000.out


./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_GetPC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_GetPC_5000.out
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_GetPC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_GetPC_5000.out


./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MBtoPC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.01_MBtoPC_5000.out
./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MBtoPC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/pigs_0.05_MBtoPC_5000.out










./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_PC_simple_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_PC_simple_5000.out
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_PC_simple_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 PC_simple all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_PC_simple_5000.out


./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MMPC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MMPC_5000.out
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MMPC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MMPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MMPC_5000.out


./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_HITON_PC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_HITON_PC_5000.out
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_HITON_PC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_HITON_PC_5000.out


./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Semi_HITON_PC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_Semi_HITON_PC_5000.out
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Semi_HITON_PC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 Semi_HITON_PC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_Semi_HITON_PC_5000.out


./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_GetPC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_GetPC_5000.out
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_GetPC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 GetPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_GetPC_5000.out


./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MBtoPC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.01 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.01_MBtoPC_5000.out
./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MBtoPC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt 0.05 MBtoPC all "" 3
mv ./indicator1/indicator.out ./indicator1/gene_0.05_MBtoPC_5000.out









