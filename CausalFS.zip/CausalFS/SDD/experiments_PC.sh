#!/bin/bash
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/child_SLL-PC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt SLL-PC all
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/child_SLL-PC_5000.out

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/child_S2TMB-PC_500.out
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt S2TMB-PC all
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/child_S2TMB-PC_5000.out











./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/alarm_SLL-PC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/alarm_SLL-PC_5000.out

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/alarm_S2TMB-PC_500.out
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/alarm_S2TMB-PC_5000.out








./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/pigs_SLL-PC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt SLL-PC all
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/pigs_SLL-PC_5000.out

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/pigs_S2TMB-PC_500.out
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/pigs_S2TMB-PC_5000.out






./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/gene_SLL-PC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt SLL-PC all
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt SLL-PC all
mv ./indicator1/indicator.out ./indicator1/gene_SLL-PC_5000.out

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/gene_S2TMB-PC_500.out
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt S2TMB-PC all
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt S2TMB-PC all
mv ./indicator1/indicator.out ./indicator1/gene_S2TMB-PC_5000.out
