﻿//Xianjie Guo, Kui Yu
//10/10/2019
///////////////////////////////////////////////////////////////////////////////
////////////////////////////////////includes///////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <cstdio>
#include <string>
#include <vector>
#include <list>
#include <queue>

#include "common.hpp"
#include "lognum.hpp"
#include "logger.hpp"
#include "timer.hpp"
#include "data.hpp"
//#include "stacksubset.hpp"
#include "scores.hpp"
#include "adtree.hpp"
#include "bestdagdp.hpp"
#include "tetrad.hpp"
#include "local.hpp"
#include "greedy.hpp"
#include <boost/program_options.hpp>

using namespace std;


///////////////////////////////////////////////////////////////////////////////
////////////////////////////////global definitions/////////////////////////////
///////////////////////////////////////////////////////////////////////////////

struct Arc {
    int head;
    int tail;
    Arc(int h, int t) { head = h; tail = t; }
};

const char *data_file_path,*net_file_path,*mb_write_in_file_path, *pc_write_in_file_path,*DAG_write_in_file_path;

double average_Precision, average_Recall, average_F1, average_Distance;//average value of four indicators of all nodes in the network (under one sample)

double Total_time;

double SHD,_undirected,_reverse,_miss,_extra;//five indicators of structural learning in the network (under one sample)

int nVariables,n_cases;//number of network nodes and sample cases

int globalADTreeMaxDepth=2;//set maximum depth for ADNode before resorting to leaf lists

int globalADTreeMinCount=100;//set minimum count for ADNode before resorting to leaf lists

int maxHistoryLength=100;//set maximum history length for global greedy search

int maxBadSteps=15;//set maximum number of steps without improvement for global greedy search

int **net;

Timer timer;


///////////////////////////////////////////////////////////////////////////////
///////////////////////////////functions' prototypes///////////////////////////
///////////////////////////////////////////////////////////////////////////////

void sll_pc(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets);
void sll_mb(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets);
void sll_c(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets);
void sll_s(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets,const ScoreFun* scoreFun);
void s2tmb_pc(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets);
void s2tmb_mb(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets);
void s2tmb_c(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets);
void s2tmb_s(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets,const ScoreFun* scoreFun);

///////////////////////////////////////////////////////////////////////////////

void getCanSP(const vector<list<int> >& neighs, const SquareMat<bool>& nMat, vector<list<int> >& nneighs, vector<int> targets);
void neighListsToMat(const vector<list<int> >& neighs, SquareMat<bool>& neighMat);
void neighMatToLists(const SquareMat<bool>& neighMat, vector<list<int> >& neighs);
void fixNeighSymmetryAnd(SquareMat<bool>& neighMat);
void fixNeighSymmetryOr(SquareMat<bool>& neighMat);
void getNeighsNeighs(const vector<list<int> >& neighs, const SquareMat<bool>& nMat, vector<list<int> >& nneighs);
void directArc(int i, int j, SquareMat<bool>& adjMat, SquareMat<bool>& pathMat, queue<Arc>& directed);
void buildDAG(const vector<list<int> >& neighs, const vector<list<Family> >& families, SquareMat<bool>& adjMat);
void buildSkeletonDAG(const vector<list<int> >& neighs, SquareMat<bool>& adjMat);
void report_pc(const vector<int>& targets,const SquareMat<bool>& neighMat);
void report_mb(const vector<int>& targets,int **MB);
void report_DAG(SquareMat<bool>& adjMat);

///////////////////////////////////////////////////////////////////////////////
////////////////////////////////functions' body////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////

int main(int argc, char *argv[])
{
    char *algorithm;
    vector<int> targets;
    int i, j, k;
    std::fstream _file;

    int localMaxIndegree=5;
    int localExactMaxNodes=20;
    double equivalentSampleSize=1.0;
    string tetradcmdLocation="./tetradcmd.jar";

    int localADTreeMinCount=100;//set minimum count for ADNode before resorting to leaf lists
    int localADTreeMaxDepth=5;//set maximum depth for ADNode before resorting to leaf lists

    average_Precision = (double)0.0;
    average_Recall = (double)0.0;
    average_F1 = (double)0.0;
    average_Distance = (double)0.0;


    if (argc!=5) {
        cout<<"Please enter five parameters！"<<endl;
        fflush(stdout);
        exit(0);
    }

    data_file_path=argv[1];
    net_file_path =argv[2];
    mb_write_in_file_path = "mb/mb.out";
    pc_write_in_file_path = "pc/pc.out";
    DAG_write_in_file_path="DAG/DAG.out";
    algorithm=argv[3];

    if (strcmp(algorithm,"SLL-PC")&&strcmp(algorithm,"SLL")&&strcmp(algorithm,"SLL-CSL")
            &&strcmp(algorithm,"SLL-SSL")&&strcmp(algorithm,"S2TMB-PC")&&strcmp(algorithm,"S2TMB")
            &&strcmp(algorithm,"S2TMB-CSL")&&strcmp(algorithm,"S2TMB-SSL"))
    {
        cout<<"Error: invalid algorithm name"<<endl;
        fflush(stdout);
        exit(0);
    }
    Data data;
    std::istream inStream(0);
    std::ifstream inFile;
    inFile.open(data_file_path);
    inStream.rdbuf(inFile.rdbuf());
    data.read(inStream);
    if (inFile.is_open())
        inFile.close();

    nVariables = data.nVariables;
    n_cases=data.nSamples;

    std::cout<<"algorithm:"<<algorithm<<"  "<<"n_cases:"<<n_cases<<"  "<<"nVariables:"<<nVariables<<std::endl;

    if (!strcmp(argv[4],"all")||!strcmp(argv[4],"")) {
        for (int var = 0; var < nVariables; ++var) {
             targets.push_back(var);
        }
    }
    else
    {
        const char *sep = ",";
        char *p;
        p = strtok(argv[4], sep);
           while(p){
               targets.push_back(atoi(p));
               p = strtok(NULL, sep);
           }
    }

    net = new int*[nVariables];
    for (i = 0; i < nVariables; i++)
        net[i] = new int[nVariables];
    std::ifstream fileStream;
    int *cache;
    char aux;
    //read the network adjacency matrix text data to **net
    fileStream.open(net_file_path, std::ios::in);//ios::in indicates that the file is read read-only
    cache = new int[nVariables*nVariables];

    if (fileStream.fail())//file open failed
    {
        std::cout << "Network adjacency matrix data text failed to open" << std::endl;
        fflush(stdout);
        exit(0);
    }
    else//file exists
    {
        i = 0;
        while (fileStream.get(aux))
        {
            if (aux == '0' || aux == '1')
            {
                cache[i] = aux-'0';
                i++;
                if (i > nVariables*nVariables - 1)
                {
                    break;
                }
            }
        }
        if (i != nVariables * nVariables)
        {
            std::cout << "The adjacency matrix text data is incorrect!";
            fflush(stdout);
            exit(0);
        }
        k = 0;
        for (i = 0; i < nVariables; i++)
        {
            for (j = 0; j < nVariables; j++)
            {
                net[i][j] = cache[k];
                k++;
            }
        }
        fileStream.close();
    }

    SubnetFinder subnetFinder;
    subnetFinder.maxParents = localMaxIndegree;
    subnetFinder.adTreeMaxDepth = localADTreeMaxDepth;
    subnetFinder.adTreeMinCount = localADTreeMinCount;
    subnetFinder.equivalentSampleSize = equivalentSampleSize;
    subnetFinder.maxNodesDP = localExactMaxNodes;
    subnetFinder.tetradcmdLocation = tetradcmdLocation;
    bool fullSpouseCandidates = false;

    ScoreFun* scoreFun = new BDeuScore(equivalentSampleSize);
    subnetFinder.scoreFun = scoreFun;
    subnetFinder.reset();

    timer.start();
    if (!strcmp(algorithm,"SLL-PC")) {
       vector<int> tt;
       for (vector<int>::iterator it=targets.begin(); it < targets.end(); it++) {
           tt.clear();
           tt.push_back(*it);
           sll_pc(data,subnetFinder,tt);
       }
    }
    if (!strcmp(algorithm,"SLL")) {
        vector<int> tt;
        for (vector<int>::iterator it=targets.begin(); it < targets.end(); it++) {
            tt.clear();
            tt.push_back(*it);
            sll_mb(data,subnetFinder,tt);
        }
    }
    if (!strcmp(algorithm,"SLL-CSL")) {
       sll_c(data,subnetFinder,targets);
    }
    if (!strcmp(algorithm,"SLL-SSL")) {
       sll_s(data,subnetFinder,targets,scoreFun);
    }
    if (!strcmp(algorithm,"S2TMB-PC")) {
       s2tmb_pc(data,subnetFinder,targets);
    }
    if (!strcmp(algorithm,"S2TMB")) {
       s2tmb_mb(data,subnetFinder,targets);
    }
    if (!strcmp(algorithm,"S2TMB-CSL")) {
       s2tmb_c(data,subnetFinder,targets);
    }
    if (!strcmp(algorithm,"S2TMB-SSL")) {
       s2tmb_s(data,subnetFinder,targets,scoreFun);
    }


    if(algorithm[strlen(algorithm)-2]!='S')
    {
        if ((unsigned long)nVariables!=targets.size()) {
            Total_time = Total_time / (double)targets.size();

            average_Precision = average_Precision / (double)targets.size();
            average_Recall = average_Recall / (double)targets.size();
            average_F1= average_F1 / (double)targets.size();
            average_Distance = average_Distance / (double)targets.size();
        }else {
            Total_time = Total_time / (double)nVariables;

            average_Precision = average_Precision / (double)nVariables;
            average_Recall = average_Recall / (double)nVariables;
            average_F1= average_F1 / (double)nVariables;
            average_Distance = average_Distance / (double)nVariables;

        }
    }

    if (algorithm[strlen(algorithm)-2]!='S') {
        _file.open("indicator1/indicator.out", std::ios::out | std::ios::app);//read from memory into disk and open file in append mode
    }else {
        _file.open("indicator2/indicator.out", std::ios::out | std::ios::app);//read from memory into disk and open file in append mode
    }
    if (!_file)
    {
        std::cout << "error" << std::endl;
        fflush(stdout);
        return 0;
    }
    if (algorithm[strlen(algorithm)-2]=='S') {
        _file <<"SHD:"<< SHD <<std::endl;
        _file <<"undirected:"<< _undirected <<std::endl;
        _file <<"reverse:"<< _reverse <<std::endl;
        _file <<"miss:"<< _miss <<std::endl;
        _file <<"extra:"<< _extra <<std::endl;
    }
    else {
        _file <<"Precision:"<< average_Precision <<std::endl;
        _file <<"Recall:"<< average_Recall <<std::endl;
        _file <<"F1:"<< average_F1 <<std::endl;
        _file <<"Distance:"<< average_Distance <<std::endl;
    }
    _file <<"Time:"<< Total_time <<std::endl;
    _file << std::endl;
    _file.close();


    targets.clear();
    delete subnetFinder.scoreFun;

    return 0;
}




///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
void getCanSP(const vector<list<int> >& neighs, const SquareMat<bool>& nMat, vector<list<int> >& nneighs, vector<int> targets) {
    int nVars = neighs.size();
    for (int i = 0; i < targets.size(); ++i)
    {
        int t = targets[i];
        for (int j = 0; j < nVars; j++)
        {
            bool j_flag=false;
            if (j==t)
                continue;

            for (list<int>::const_iterator nit = neighs[t].begin(); nit != neighs[t].end(); ++nit)
            {
                if (j==(*nit))
                    j_flag=true;
            }
            if (j_flag)
                continue;
            nneighs[t].push_back(j);
        }
    }
}

///////////////////////////////////////////////////////////

void neighListsToMat(const vector<list<int> >& neighs, SquareMat<bool>& neighMat) {
    int nVars = neighs.size();
    neighMat.setAll(false);
    for (int i= 0; i < nVars; ++i)
        for (list<int>::const_iterator nit = neighs[i].begin(); nit != neighs[i].end(); ++nit)
            neighMat(i, *nit) = true;
}

///////////////////////////////////////////////////////////

void neighMatToLists(const SquareMat<bool>& neighMat, vector<list<int> >& neighs) {
    int nVars = neighMat.getNumNodes();
    for (int i = 0; i < nVars; ++i) {
        neighs[i].clear();
        for (int j = 0; j < nVars; ++j)
            if (neighMat(i,j))
                neighs[i].push_back(j);
    }
}

///////////////////////////////////////////////////////////

void fixNeighSymmetryAnd(SquareMat<bool>& neighMat) {
    int nVars = neighMat.getNumNodes();
    for (int i = 0; i < nVars; ++i)
        for (int j = 0; j < nVars; ++j)
            if (!neighMat(j, i))            //j' PC does't include i
                neighMat(i, j) = false;     //i' PC does't include j
}

///////////////////////////////////////////////////////////

void fixNeighSymmetryOr(SquareMat<bool>& neighMat) {
    int nVars = neighMat.getNumNodes();
    for (int i = 0; i < nVars; ++i)
        for (int j = 0; j < nVars; ++j)
            if (neighMat(j, i))
                neighMat(i, j) = true;
}

///////////////////////////////////////////////////////////

void getNeighsNeighs(const vector<list<int> >& neighs, const SquareMat<bool>& nMat, vector<list<int> >& nneighs) {
    int nVars = neighs.size();
    SquareMat<bool> nnMat(nVars);
    nnMat.setAll(false);
    for (int i = 0; i < nVars; ++i)
        for (list<int>::const_iterator nit = neighs[i].begin(); nit != neighs[i].end(); ++nit)
            for (list<int>::const_iterator nnit = neighs[*nit].begin(); nnit != neighs[*nit].end(); ++nnit)
                if (i != *nnit && !nMat(i, *nnit) && !nnMat(i, *nnit)) {
                    //nneighs[i].push_back(*nnit);
                    nnMat(i, *nnit) = true;
                }
    for (int i = 0; i < nVars; ++i)
        for (int j = 0; j < nVars; ++j)
            if (nnMat(i,j))
                nneighs[i].push_back(j);
}



/*
Directs arc i -> j and possible other arcs forced by acyclicity. Updates
parameters adjMat, pathMat and directed correspondingly.
*/
void directArc(int i, int j, SquareMat<bool>& adjMat, SquareMat<bool>& pathMat, queue<Arc>& directed) {
//printf("direcArc: %d -> %d\n", i, j);
    assert(adjMat(i,j));
    int n = adjMat.getNumNodes();
    adjMat(j,i) = false;
    directed.push(Arc(i,j));
    pathMat(i,j) = true;
    for (int k = 0; k < n; ++k)
        if (pathMat(k,i))
            for (int l = 0; l < n; ++l)
                if (pathMat(j,l)) {
                    assert(!pathMat(l,k));
                    pathMat(k,l) = true;
                    if (adjMat(l,k)) {
                        assert(adjMat(k,l));
                        adjMat(l,k) = false;
                        directed.push(Arc(k,l));
                    }
                }
}

///////////////////////////////////////////////////////////

void buildDAG(const vector<list<int> >& neighs, const vector<list<Family> >& families, SquareMat<bool>& adjMat) {
    int nVars = neighs.size();

    //SquareMat<bool> adjMat(nVars);
    adjMat.setAll(false);

    SquareMat<bool> pathMat(nVars);
    pathMat.setAll(false);
    for (int i = 0; i < nVars; ++i)
        pathMat(i, i) = true;

    // build skeleton using OR rule
    for (int i = 0; i < nVars; ++i) {
        for (list<int>::const_iterator nit = neighs[i].begin(); nit != neighs[i].end(); ++nit) {
            adjMat(i, *nit) = true;
            adjMat(*nit, i) = true;
        }
    }

    queue<Arc> directed;

    // direct arcs in v-structures
    for (int i = 0; i < nVars; ++i) {
        for (list<Family>::const_iterator fit = families[i].begin(); fit != families[i].end(); ++fit) {
            int j = fit->spouse;
            for (list<int>::const_iterator cit = fit->children.begin(); cit != fit->children.end(); ++cit) {
                int k = *cit;
                // direct, if forms an __undirected v-structure
                if (!adjMat(i,j) && !adjMat(j,i) &&
                        adjMat(i,k) && adjMat(k,i) &&
                        adjMat(j,k) && adjMat(k,j)) {
                    directArc(i, k, adjMat, pathMat, directed);
                    directArc(j, k, adjMat, pathMat, directed);
                    for (int l = 0; l < nVars; ++l) {
                        // i -> k <- j,  i -- l -- j,  l -- k
                        if (adjMat(i,l) && adjMat(l,i) && adjMat(j,l) && adjMat(l,j) && adjMat(k,l) && adjMat(l,k))
                            directArc(l, k, adjMat, pathMat, directed);
                    }
                }
            }
        }
    }

    // direct rest of the arcs
    while (true) {
        // if no rules left, direct a random __undirected arc
        if (directed.empty())
            for (int i = 0; i < nVars; ++i)
                for (int j = 0; j < nVars; ++j)
                    if (adjMat(i,j) && adjMat(j,i)) {
                        directArc(i, j, adjMat, pathMat, directed);
                        goto breakLoops;
                    }
        breakLoops:

        // no more arcs to direct?
        if (directed.empty())
            break;

        // direct arcs implied by previously directed
        while (!directed.empty()) {
            Arc arc = directed.front();
            int i = arc.head;
            int j = arc.tail;
            directed.pop();

            for (int k = 0; k < nVars; ++k) {
                if (k == i || k == j)
                    continue;
                // i -> j -- k
                if (adjMat(j,k) && adjMat(k,j) && !adjMat(i,k) && !adjMat(k,i))
                    directArc(j, k, adjMat, pathMat, directed);
                // i -> j -> k,  i -- k
                if (adjMat(j,k) && !adjMat(k,j) && adjMat(i,k) && adjMat(k,i))
                    directArc(i, k, adjMat, pathMat, directed);
                // k -> i -> j -> k,  k -- j
                if (adjMat(k,i) && !adjMat(i,k) && adjMat(k,j) && adjMat(j,k))
                    directArc(k, j, adjMat, pathMat, directed);
            }
        }
    }
}

///////////////////////////////////////////////////////////

void buildSkeletonDAG(const vector<list<int> >& neighs, SquareMat<bool>& adjMat) {
    int nVars = neighs.size();
    adjMat.setAll(false);
    // build  allowed skeleton using OR rule
    for (int i = 0; i < nVars; ++i) {
        for (list<int>::const_iterator nit = neighs[i].begin(); nit != neighs[i].end(); ++nit) {
            adjMat(i, *nit) = true;
            adjMat(*nit, i) = true;
        }
    }
}

///////////////////////////////////////////////////////////

void report_pc(const vector<int>& targets,const SquareMat<bool>& neighMat)
{
    int i, in_pc, tp, fp, fn;
    double Precision, Recall, Distance, F1;

    //tp+fp=the algorithm runs the obtained PC
    //tp+fn=PC in real network
    for (int var = 0; var < targets.size(); ++var) {
        tp = 0;
        fp = 0;
        fn = 0;
        for (i = 0; i < nVariables; i++)
        {
            if (i != targets[var])
            {
                in_pc = 0;

                if (net[i][targets[var]] == 1 || net[targets[var]][i] == 1)
                    in_pc = 1;

                if (neighMat(targets[var],i) == true && in_pc == 1)
                    tp++;//Found the correct number of PC nodes
                else
                {
                    if (neighMat(targets[var],i) == true && in_pc == 0)
                        fp++;//found redundant PC nodes
                    else
                        if (neighMat(targets[var],i) == false && in_pc == 1)
                            fn++;//number of undiscovered PC nodes
                }
            }
        }


        //calculate precision (value range [0,1])
        if (tp == 0 && fp == 0)
        {
            if (tp == 0 && fp == 0 && fn == 0)
            {
                Precision = (double)1.0;
            }
            else
            {
                Precision = (double)0.0;
            }
        }
        else
        {
            Precision = (double)tp / (double)(tp + fp);
        }


        //calculate recall (value range [0,1])
        if (tp == 0 && fn == 0)
        {
            if (tp == 0 && fn == 0 && fp == 0)
            {
                Recall = (double)1.0;
            }
            else
            {
                Recall = (double)0.0;
            }
        }
        else
        {
            Recall = (double)tp / (double)(tp + fn);
        }


        //calculate distance (value range [0,√2])
        Distance = sqrt(pow((double)1.0 - Precision, (double)2.0) + pow((double)1.0 - Recall, (double)2.0));

        //calculate F1
        if (Precision == 0 && Recall == 0)
        {
            F1 = (double)0.0;
        }
        else
        {
            F1 = (double)2.0*Precision*Recall / (Precision + Recall);
        }

        average_Precision = average_Precision + Precision;
        average_Recall = average_Recall + Recall;
        average_F1 = average_F1 + F1;
        average_Distance = average_Distance + Distance;

    }

}

///////////////////////////////////////////////////////////

void report_mb(const vector<int>& targets,int **MB)
{
    int i,j, in_mb, tp, fp, fn;
    double Precision, Recall, Distance, F1;

    //tp+fp=the algorithm runs the obtained MB
    //tp+fn=MB in real network
    for (int var = 0; var < targets.size(); ++var)
    {
        tp = 0;
        fp = 0;
        fn = 0;
        for (i = 0; i < nVariables; i++)
        {
            if (i != targets[var])
            {
                in_mb = 0;

                if (net[i][targets[var]] == 1 || net[targets[var]][i] == 1)
                    in_mb = 1;
                else
                {
                    for (j = 0; j < nVariables; j++)
                        if (j!=targets[var]&&j!=i) {
                            if (net[targets[var]][j] == 1 && net[i][j] == 1)//spouse
                                in_mb = 1;
                        }
                }


                if (MB[targets[var]][i] == 1 && in_mb == 1)
                    tp++;//found the correct number of MB nodes
                else
                {
                    if (MB[targets[var]][i] == 1 && in_mb == 0)
                        fp++;//found redundant MB nodes
                    else
                        if (MB[targets[var]][i] == 0 && in_mb == 1)
                            fn++;//number of undiscovered MB nodes
                }
            }
        }

        //calculate precision (value range [0,1])
        if (tp == 0 && fp == 0)
        {
            if (tp == 0 && fp == 0&&fn==0)
            {
                Precision = (double)1.0;
            }
            else
            {
                Precision = (double)0.0;
            }
        }
        else
        {
            Precision = (double)tp / (double)(tp + fp);
        }


        //calculate recall (value range [0,1])
        if (tp == 0 && fn == 0)
        {
            if (tp == 0 && fn == 0&&fp==0)
            {
                Recall = (double)1.0;
            }
            else
            {
                Recall = (double)0.0;
            }
        }
        else
        {
            Recall = (double)tp / (double)(tp + fn);
        }


        //calculate distance (value range [0,√2])
        Distance = sqrt(pow((double)1.0 - Precision, (double)2.0) + pow((double)1.0 - Recall, (double)2.0));

        //calculate F1
        if (Precision == 0 && Recall == 0)
        {
            F1 = (double)0.0;
        }
        else
        {
            F1 = (double)2.0*Precision*Recall / (Precision + Recall);
        }

        average_Precision = average_Precision + Precision;
        average_Recall = average_Recall + Recall;
        average_F1 = average_F1 + F1;
        average_Distance = average_Distance + Distance;
    }
    for (int var2= 0; var2 < nVariables; var2++)
    {
        delete[] MB[var2];
    }

}

///////////////////////////////////////////////////////////

void report_DAG(SquareMat<bool>& adjMat)
{
    int **dag,**C;
    int count,tag;
    vector<int> x;
    vector<int> y;
    vector<int> y_index;
    count=0;
    _undirected=0;
    _reverse=0;
    _miss=0;
    _extra=0;
    x.clear();
    y.clear();
    y_index.clear();
    dag = new int*[nVariables];
    for (int i = 0; i < nVariables; i++)
        dag[i] = new int[nVariables];

    C = new int*[nVariables];
    for (int i = 0; i < nVariables; i++)
        C[i] = new int[nVariables];

    for (int var1 = 0; var1 < nVariables; ++var1) {
        for (int var2 = 0; var2 < nVariables; ++var2) {
            if (adjMat(var1,var2)==true) {
                dag[var1][var2]=1;
            }
            else {
                dag[var1][var2]=0;
            }
        }
    }

    for (int var1 = 0; var1 < nVariables; ++var1) {
        for (int var2 = 0; var2 < nVariables; ++var2) {
            C[var1][var2]=net[var1][var2]-dag[var1][var2];
        }
    }

    //SHD;
    for (int var2 = 0; var2 < nVariables; ++var2) {
        for (int var1 = 0; var1 < nVariables; ++var1) {
            if (C[var1][var2]!=0) {
                count++;
                x.push_back(var1);
                y.push_back(var2);
            }
        }
    }
    SHD=(double)count;
    for (int i = 0; i < x.size(); ++i) {
        y_index.clear();
        for (int j = 0; j < y.size(); ++j) {
            if (y[j]==x[i]) {
                y_index.push_back(j);
            }
        }
        if (!y_index.empty()) {
            for (int k = 0; k < y_index.size(); ++k) {
                if (x[y_index[k]]==y[i]) {
                    SHD-=0.5;
                }
            }
        }
    }

    //_undirected,_reverse,_miss,_extra;
    for (int i = 0; i < x.size(); ++i) {
        if (x[i]==-1) {
            continue;
        }
        tag=0;
        y_index.clear();
        for (int j = 0; j < y.size(); ++j) {
            if (y[j]==x[i]) {
                y_index.push_back(j);
            }
        }
        if (!y_index.empty()) {
            for (int k = 0; k < y_index.size(); ++k) {
                if (x[y_index[k]]==y[i]) {
                    tag=1;
                    if (net[x[i]][y[i]]==net[x[y_index[k]]][y[y_index[k]]]) {
                        _extra+=1;
                    }
                    else {
                        _reverse+=1;
                    }
                    x[y_index[k]]=-1;
                    y[y_index[k]]=-1;
                    break;
                }
            }
        }
        if (tag==0) {
            if (net[y[i]][x[i]]==0) {
                if (net[x[i]][y[i]]==1) {
                    _miss+=1;
                }
                else {
                    _extra+=1;
                }
            }
            else {
                _undirected+=1;
            }
        }
    }
}

///////////////////////////////////////////////////////////

void sll_pc(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets)
{
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;

        if (!neighborsSearched[t])
            findPotentialNeighbors(data, t, subnetFinder, neighs[t], nonNeighs);
        neighborsSearched[t] = true;

        // run for neighbors too
        for (list<int>::iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit) {
            if (!neighborsSearched[*nit]) {
                findPotentialNeighbors(data, *nit, subnetFinder,
                        neighs[*nit], nonNeighs);
                neighborsSearched[*nit] = true;
                }
        }
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    //fixNeighSymmetry(neighs, neighMat);
    neighListsToMat(neighs, neighMat);
    fixNeighSymmetryAnd(neighMat);
    neighMatToLists(neighMat, neighs);

    Total_time = timer.elapsed();

    //Write PC lists...
    fstream pcFile;
    pcFile.open(pc_write_in_file_path, std::ios::out | std::ios::app);//从内存中读入磁盘中并且以追加的方式打开文件
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        pcFile << t << ": ";
        for (list<int>::const_iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit)
            pcFile << *nit << " ";
        pcFile << "\n";
    }
    pcFile.close();

    report_pc(targets,neighMat);
}

///////////////////////////////////////////////////////////

void sll_mb(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets)
{
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);
    int **MB;

    MB = new int*[nVariables];
    for (int var = 0; var < nVariables; var++)
    {
        MB[var] = new int[nVariables];
    }

    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;

        if (!neighborsSearched[t])
            findPotentialNeighbors(data, t, subnetFinder, neighs[t], nonNeighs);
        neighborsSearched[t] = true;

        // run for neighbors too
        for (list<int>::iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit) {
            if (!neighborsSearched[*nit]) {
                findPotentialNeighbors(data, *nit, subnetFinder,
                        neighs[*nit], nonNeighs);
                neighborsSearched[*nit] = true;

            // and also for neighbors of neighbors if needed
            for (list<int>::iterator nnit = neighs[*nit].begin();
                    nnit != neighs[*nit].end(); ++nnit)
                if (!neighborsSearched[*nnit]) {
                    findPotentialNeighbors(data, *nnit, subnetFinder,
                            neighs[*nnit], nonNeighs);
                    neighborsSearched[*nnit] = true;
                }
            }
        }
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    //fixNeighSymmetry(neighs, neighMat);
    neighListsToMat(neighs, neighMat);
    fixNeighSymmetryAnd(neighMat);
    neighMatToLists(neighMat, neighs);

    // neighbors of neighbors are potential spouses
    vector<list<int> > potSpouses(nVariables);
    getNeighsNeighs(neighs, neighMat, potSpouses);

    vector<int> spouseTargets;// = targets;
    vector<bool> isSpouseTarget(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        if (!isSpouseTarget[t]) {
            isSpouseTarget[t] = true;
            spouseTargets.push_back(t);
        }
        for (list<int>::const_iterator sit = potSpouses[t].begin();
                sit != potSpouses[t].end(); ++sit) {
            if (!isSpouseTarget[*sit]) {
                isSpouseTarget[*sit] = true;
                spouseTargets.push_back(*sit);
            }
        }
    }

    // find spouses for targets and neighbors of neighbors
    vector<list<Family> > families(nVariables);

    for (int i = 0; i < spouseTargets.size(); ++i) {
        int t = spouseTargets[i];
        findPotentialFamilies(data, t, subnetFinder, neighs[t], potSpouses[t],
                families[t]);
    }

    // fix symmetry
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        for (list<Family>::const_iterator fit = families[t].begin();
                fit != families[t].end(); ++fit) {
            bool found = false;
            int s = fit->spouse;
            list<Family>::iterator sfit;
            for (sfit = families[s].begin();
                    sfit != families[s].end(); ++sfit)
                if (t == sfit->spouse) {            //t == sfit->spouse
                    found = true;
                    break;
                }
            if (!found) {               //spouses' spouses does't include t
                families[s].push_back(Family(t, fit->children));
                sfit = families[s].end();
                --sfit;
            }
            for (list<int>::const_iterator cit = fit->children.begin();
                    cit != fit->children.end(); ++cit) {
                found = false;
                for (list<int>::const_iterator scit = sfit->children.begin();
                        scit != sfit->children.end(); ++scit)
                    if (*cit == *scit) {        //t's child == t's spouses's child
                        found = true;
                        break;
                    }
                if (!found)             //t and spouse does not have common child
                    sfit->children.push_back(*cit);
            }

        }
    }

    Total_time = timer.elapsed();

    for (int var1 = 0; var1 < nVariables; ++var1) {
        for (int var2 = 0; var2 < nVariables; ++var2) {
            MB[var1][var2]=0;
        }
    }
    //Write MB lists...
    fstream mbFile;
    mbFile.open(mb_write_in_file_path, std::ios::out | std::ios::app);//read from memory into disk and open file in append mode
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        mbFile << t << ": ";
        for (list<int>::const_iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit)
        {
            mbFile << *nit << " ";
            MB[t][*nit]=1;
        }
        for (list<Family>::const_iterator fit = families[t].begin();
                fit != families[t].end(); ++fit)
        {
            mbFile << fit->spouse << " ";
            MB[t][fit->spouse]=1;
        }
        mbFile << "\n";
    }
    mbFile.close();
    report_mb(targets,MB);
}

///////////////////////////////////////////////////////////

void sll_c(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets)
{
    SquareMat<bool> adjMat(nVariables);
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);

    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;

        if (!neighborsSearched[t])
            findPotentialNeighbors(data, t, subnetFinder, neighs[t], nonNeighs);
        neighborsSearched[t] = true;

        // run for neighbors too
        for (list<int>::iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit) {
            if (!neighborsSearched[*nit]) {
                findPotentialNeighbors(data, *nit, subnetFinder,
                        neighs[*nit], nonNeighs);
                neighborsSearched[*nit] = true;

            // and also for neighbors of neighbors if needed
            for (list<int>::iterator nnit = neighs[*nit].begin();
                    nnit != neighs[*nit].end(); ++nnit)
                if (!neighborsSearched[*nnit]) {
                    findPotentialNeighbors(data, *nnit, subnetFinder,
                            neighs[*nnit], nonNeighs);
                    neighborsSearched[*nnit] = true;
                }
            }
        }
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    //fixNeighSymmetry(neighs, neighMat);
    neighListsToMat(neighs, neighMat);
    fixNeighSymmetryAnd(neighMat);
    neighMatToLists(neighMat, neighs);

    // neighbors of neighbors are potential spouses
    vector<list<int> > potSpouses(nVariables);
    getNeighsNeighs(neighs, neighMat, potSpouses);

    vector<int> spouseTargets;// = targets;
    vector<bool> isSpouseTarget(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        if (!isSpouseTarget[t]) {
            isSpouseTarget[t] = true;
            spouseTargets.push_back(t);
        }
        for (list<int>::const_iterator sit = potSpouses[t].begin();
                sit != potSpouses[t].end(); ++sit) {
            if (!isSpouseTarget[*sit]) {
                isSpouseTarget[*sit] = true;
                spouseTargets.push_back(*sit);
            }
        }
    }

    // find spouses for targets and neighbors of neighbors
    vector<list<Family> > families(nVariables);

    for (int i = 0; i < spouseTargets.size(); ++i) {
        int t = spouseTargets[i];
        findPotentialFamilies(data, t, subnetFinder, neighs[t], potSpouses[t],
                families[t]);
    }

    // fix symmetry
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        for (list<Family>::const_iterator fit = families[t].begin();
                fit != families[t].end(); ++fit) {
            bool found = false;
            int s = fit->spouse;
            list<Family>::iterator sfit;
            for (sfit = families[s].begin();
                    sfit != families[s].end(); ++sfit)
                if (t == sfit->spouse) {            //t == sfit->spouse
                    found = true;
                    break;
                }
            if (!found) {               //spouses' spouses does't include t
                families[s].push_back(Family(t, fit->children));
                sfit = families[s].end();
                --sfit;
            }
            for (list<int>::const_iterator cit = fit->children.begin();
                    cit != fit->children.end(); ++cit) {
                found = false;
                for (list<int>::const_iterator scit = sfit->children.begin();
                        scit != sfit->children.end(); ++scit)
                    if (*cit == *scit) {        //t's child == t's spouses's child
                        found = true;
                        break;
                    }
                if (!found)             //t and spouse does not have common child
                    sfit->children.push_back(*cit);
            }

        }
    }

    buildDAG(neighs, families, adjMat);

    Total_time = timer.elapsed();

    ofstream dagFile(DAG_write_in_file_path);
    for (int i = 0; i < nVariables; ++i) {
        for (int j = 0; j < nVariables; ++j) {
            if (j != 0)
                dagFile << " ";
            dagFile << (adjMat(i,j) ? 1 : 0);
        }
        dagFile << "\n";
    }
    dagFile.close();
    report_DAG(adjMat);
}

///////////////////////////////////////////////////////////

void sll_s(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets,const ScoreFun* scoreFun)
{
    SquareMat<bool> adjMat(nVariables);
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;

        if (!neighborsSearched[t])
            findPotentialNeighbors(data, t, subnetFinder, neighs[t], nonNeighs);
        neighborsSearched[t] = true;

        // run for neighbors too
        for (list<int>::iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit) {
            if (!neighborsSearched[*nit]) {
                findPotentialNeighbors(data, *nit, subnetFinder,
                        neighs[*nit], nonNeighs);
                neighborsSearched[*nit] = true;
                }
        }
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    //fixNeighSymmetry(neighs, neighMat);
    neighListsToMat(neighs, neighMat);
    fixNeighSymmetryAnd(neighMat);
    neighMatToLists(neighMat, neighs);

    // build skeleton
    SquareMat<bool> allowedMat(nVariables);
    buildSkeletonDAG(neighs, allowedMat);

    // build ADTree
    DataColumns dataColumns(data);
    ADTree adTree(dataColumns, globalADTreeMinCount, globalADTreeMaxDepth);

    // greedy search
    adjMat.setAll(false);
    greedyBestDAG(adTree, allowedMat, scoreFun, maxHistoryLength, maxBadSteps, adjMat);

    Total_time = timer.elapsed();

    fflush(stdout);
    ofstream dagFile(DAG_write_in_file_path);
    for (int i = 0; i < nVariables; ++i) {
        for (int j = 0; j < nVariables; ++j) {
            if (j != 0)
                dagFile << " ";
            dagFile << (adjMat(i,j) ? 1 : 0);
        }
        dagFile << "\n";
    }
    dagFile.close();
    report_DAG(adjMat);
}

///////////////////////////////////////////////////////////

void s2tmb_pc(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets)
{
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);

    int ScorePCTest=0;

    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;
        if (!neighborsSearched[t])
            findPotentialNeighbors2(data, t, subnetFinder, neighs[t], nonNeighs, ScorePCTest);
        neighborsSearched[t] = true;
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    neighListsToMat(neighs, neighMat);
    neighMatToLists(neighMat, neighs);

    // neighbors of neighbors are potential spouses
    vector<list<int> > potSpouses(nVariables);

    getCanSP(neighs, neighMat, potSpouses, targets);

    vector<int> spouseTargets;// = targets;
    vector<bool> isSpouseTarget(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        if (!isSpouseTarget[t]) {
            isSpouseTarget[t] = true;
            spouseTargets.push_back(t);
        }
    }

    // find spouses for targets and neighbors of neighbors
    vector<list<Family> > families(nVariables);

    int ScoreSPTest=0;

    for (int i = 0; i < spouseTargets.size(); ++i) {
        int t = spouseTargets[i];

        findPotentialFamilies2(data, t, subnetFinder, neighs[t], potSpouses[t], families[t], ScoreSPTest);
    }

    Total_time = timer.elapsed();

    // output neigbors
    fstream pcFile;
    pcFile.open(pc_write_in_file_path, std::ios::out | std::ios::app);//read from memory into disk and open file in append mode
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        pcFile << t << ": ";
        for (list<int>::const_iterator nit = neighs[t].begin();
                nit != neighs[t].end(); ++nit)
        {
            pcFile << *nit << " ";
        }
        pcFile << "\n";
    }
    pcFile.close();

    report_pc(targets,neighMat);
}

///////////////////////////////////////////////////////////

void s2tmb_mb(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets)
{
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);
    int **MB;

    MB = new int*[nVariables];
    for (int var = 0; var < nVariables; var++)
    {
        MB[var] = new int[nVariables];
    }

    int ScorePCTest=0;

    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;
        if (!neighborsSearched[t])
            findPotentialNeighbors2(data, t, subnetFinder, neighs[t], nonNeighs, ScorePCTest);
        neighborsSearched[t] = true;
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    neighListsToMat(neighs, neighMat);
    neighMatToLists(neighMat, neighs);

    // neighbors of neighbors are potential spouses
    vector<list<int> > potSpouses(nVariables);

    getCanSP(neighs, neighMat, potSpouses, targets);

    vector<int> spouseTargets;// = targets;
    vector<bool> isSpouseTarget(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        if (!isSpouseTarget[t]) {
            isSpouseTarget[t] = true;
            spouseTargets.push_back(t);
        }
    }

    // find spouses for targets and neighbors of neighbors
    vector<list<Family> > families(nVariables);

    int ScoreSPTest=0;

    for (int i = 0; i < spouseTargets.size(); ++i) {
        int t = spouseTargets[i];

        findPotentialFamilies2(data, t, subnetFinder, neighs[t], potSpouses[t], families[t], ScoreSPTest);
    }

    Total_time = timer.elapsed();

    for (int var1 = 0; var1 < nVariables; ++var1) {
        for (int var2 = 0; var2 < nVariables; ++var2) {
            MB[var1][var2]=0;
        }
    }
    //Write MB lists...
    fstream mbFile;
    mbFile.open(mb_write_in_file_path, std::ios::out | std::ios::app);//Read from memory into disk and open file in append mode
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
            mbFile << t << ": ";
            for (list<int>::const_iterator nit = neighs[t].begin();
                    nit != neighs[t].end(); ++nit)
            {
                mbFile << *nit << " ";
                MB[t][*nit]=1;
            }
            for (list<Family>::const_iterator fit = families[t].begin();
                    fit != families[t].end(); ++fit)
            {
                mbFile << fit->spouse << " ";
                MB[t][fit->spouse]=1;
            }
        mbFile << "\n";
    }
    mbFile.close();
    report_mb(targets,MB);

}

///////////////////////////////////////////////////////////

void s2tmb_c(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets)
{
    SquareMat<bool> adjMat(nVariables);
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);

    int ScorePCTest=0;

    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;
        if (!neighborsSearched[t])
            findPotentialNeighbors2(data, t, subnetFinder, neighs[t], nonNeighs, ScorePCTest);
        neighborsSearched[t] = true;
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    neighListsToMat(neighs, neighMat);
    neighMatToLists(neighMat, neighs);

    // neighbors of neighbors are potential spouses
    vector<list<int> > potSpouses(nVariables);

    getCanSP(neighs, neighMat, potSpouses, targets);

    vector<int> spouseTargets;// = targets;
    vector<bool> isSpouseTarget(nVariables);
    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        if (!isSpouseTarget[t]) {
            isSpouseTarget[t] = true;
            spouseTargets.push_back(t);
        }
    }

    // find spouses for targets and neighbors of neighbors
    vector<list<Family> > families(nVariables);

    int ScoreSPTest=0;

    for (int i = 0; i < spouseTargets.size(); ++i) {
        int t = spouseTargets[i];

        findPotentialFamilies2(data, t, subnetFinder, neighs[t], potSpouses[t], families[t], ScoreSPTest);
    }

    buildDAG(neighs, families, adjMat);

    Total_time = timer.elapsed();

    ofstream dagFile(DAG_write_in_file_path);
    for (int i = 0; i < nVariables; ++i) {
        for (int j = 0; j < nVariables; ++j) {
            if (j != 0)
                dagFile << " ";
            dagFile << (adjMat(i,j) ? 1 : 0);
        }
        dagFile << "\n";
    }
    dagFile.close();
    report_DAG(adjMat);
}

///////////////////////////////////////////////////////////

void s2tmb_s(const Data& data,SubnetFinder& subnetFinder,const vector<int>& targets,const ScoreFun* scoreFun)
{
    SquareMat<bool> adjMat(nVariables);
    vector<bool> neighborsSearched(nVariables);
    vector<list<int> > neighs(nVariables);

    int ScorePCTest=0;

    for (int i = 0; i < targets.size(); ++i) {
        int t = targets[i];
        list<int> nonNeighs;
        if (!neighborsSearched[t])
            findPotentialNeighbors2(data, t, subnetFinder, neighs[t], nonNeighs, ScorePCTest);
        neighborsSearched[t] = true;
    }

    subnetFinder.maxNumADNodes = 0;

    // symmetry correction
    SquareMat<bool> neighMat(nVariables);
    neighListsToMat(neighs, neighMat);
    neighMatToLists(neighMat, neighs);

    // build skeleton
    SquareMat<bool> allowedMat(nVariables);
    buildSkeletonDAG(neighs, allowedMat);

    // build ADTree
    DataColumns dataColumns(data);
    ADTree adTree(dataColumns, globalADTreeMinCount, globalADTreeMaxDepth);

    // greedy search
    adjMat.setAll(false);
    greedyBestDAG(adTree, allowedMat, scoreFun, maxHistoryLength, maxBadSteps, adjMat);

    Total_time = timer.elapsed();

    ofstream dagFile(DAG_write_in_file_path);
    for (int i = 0; i < nVariables; ++i) {
        for (int j = 0; j < nVariables; ++j) {
            if (j != 0)
                dagFile << " ";
            dagFile << (adjMat(i,j) ? 1 : 0);
        }
        dagFile << "\n";
    }
    dagFile.close();
    report_DAG(adjMat);
}
