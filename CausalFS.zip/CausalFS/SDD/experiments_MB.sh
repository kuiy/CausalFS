#!/bin/bash
./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/child_SLL_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt SLL all
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/child_SLL_5000.out
sleep 3s

./main data/child_data/Child_s500_v1.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s500_v2.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s500_v3.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s500_v4.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s500_v5.txt data/child_data/Child_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/child_S2TMB_500.out
sleep 3s
./main data/child_data/Child_s5000_v1.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s5000_v2.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s5000_v3.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s5000_v4.txt data/child_data/Child_graph.txt S2TMB all
./main data/child_data/Child_s5000_v5.txt data/child_data/Child_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/child_S2TMB_5000.out
sleep 3s











./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/alarm_SLL_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt SLL all
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/alarm_SLL_5000.out
sleep 3s

./main data/alarm_data/Alarm1_s500_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s500_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s500_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s500_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s500_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/alarm_S2TMB_500.out
sleep 3s
./main data/alarm_data/Alarm1_s5000_v1.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s5000_v2.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s5000_v3.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s5000_v4.txt data/alarm_data/Alarm1_graph.txt S2TMB all
./main data/alarm_data/Alarm1_s5000_v5.txt data/alarm_data/Alarm1_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/alarm_S2TMB_5000.out
sleep 3s








./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/pigs_SLL_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt SLL all
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/pigs_SLL_5000.out
sleep 3s

./main data/pigs_data/Pigs_s500_v1.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s500_v2.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s500_v3.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s500_v4.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s500_v5.txt data/pigs_data/Pigs_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/pigs_S2TMB_500.out
sleep 3s
./main data/pigs_data/Pigs_s5000_v1.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s5000_v2.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s5000_v3.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s5000_v4.txt data/pigs_data/Pigs_graph.txt S2TMB all
./main data/pigs_data/Pigs_s5000_v5.txt data/pigs_data/Pigs_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/pigs_S2TMB_5000.out
sleep 3s






./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/gene_SLL_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt SLL all
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt SLL all
mv ./indicator1/indicator.out ./indicator1/gene_SLL_5000.out
sleep 3s

./main data/gene_data/Gene_s500_v1.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s500_v2.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s500_v3.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s500_v4.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s500_v5.txt data/gene_data/Gene_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/gene_S2TMB_500.out
sleep 3s
./main data/gene_data/Gene_s5000_v1.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s5000_v2.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s5000_v3.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s5000_v4.txt data/gene_data/Gene_graph.txt S2TMB all
./main data/gene_data/Gene_s5000_v5.txt data/gene_data/Gene_graph.txt S2TMB all
mv ./indicator1/indicator.out ./indicator1/gene_S2TMB_5000.out
sleep 3s
